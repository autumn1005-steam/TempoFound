"""Create a randomly initialized TempoFound checkpoint for scratch baselines."""

import argparse
import os
import random

import numpy as np
import pandas as pd
import torch

from foundation_model import TemporalGraphFoundationModel


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--processed_dir", default="./processed")
    parser.add_argument("--output", required=True)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--shared_dim", type=int, default=256)
    parser.add_argument("--time_dim", type=int, default=128)
    parser.add_argument("--num_layers", type=int, default=2)
    parser.add_argument("--n_head", type=int, default=4)
    parser.add_argument("--drop_out", type=float, default=0.1)
    parser.add_argument("--num_neighbors", type=int, default=20)
    parser.add_argument("--backbone", choices=["tgat", "graphmixer"], default="tgat")
    args = parser.parse_args()

    set_seed(args.seed)

    csv_path = os.path.join(args.processed_dir, f"ml_{args.dataset}.csv")
    edge_path = os.path.join(args.processed_dir, f"ml_{args.dataset}.npy")
    node_path = os.path.join(args.processed_dir, f"ml_{args.dataset}_node.npy")

    df = pd.read_csv(csv_path)
    e_feat = np.load(edge_path)
    n_feat = np.load(node_path)
    max_idx = int(max(df.u.max(), df.i.max()))

    dataset_config = {
        "name": args.dataset,
        "raw_node_dim": int(n_feat.shape[1]),
        "raw_edge_dim": int(e_feat.shape[1]),
        "n_nodes": max_idx,
        "n_edges": int(len(e_feat) - 1),
    }

    model = TemporalGraphFoundationModel(
        dataset_configs=[dataset_config],
        shared_dim=args.shared_dim,
        time_dim=args.time_dim,
        num_layers=args.num_layers,
        n_head=args.n_head,
        drop_out=args.drop_out,
        num_neighbors=args.num_neighbors,
        backbone=args.backbone,
    )

    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    model.save_pretrained(args.output)
    print(f"scratch checkpoint saved: {args.output}")


if __name__ == "__main__":
    main()
