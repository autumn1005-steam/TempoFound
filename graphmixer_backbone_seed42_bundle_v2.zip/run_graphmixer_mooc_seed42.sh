#!/usr/bin/env bash
set -euo pipefail

PYTHON="${PYTHON:-python}"
GPU="${GPU:-0}"
SEED="${SEED:-42}"
RUN_DIR="server_runs/graphmixer_mooc_seed${SEED}"
LOG_DIR="${RUN_DIR}/logs"
RESULT_DIR="${RUN_DIR}/results"
STATUS="${RUN_DIR}/status.tsv"

mkdir -p "${LOG_DIR}" "${RESULT_DIR}" saved_models saved_checkpoints
[[ -f "${STATUS}" ]] || printf 'config\tstage\tstatus\texit_code\tseconds\n' > "${STATUS}"

declare -A SOURCES=(
  [selected]="wikipedia reddit"
  [all]="wikipedia reddit uci enron"
)

already_ok() {
  local config="$1" stage="$2"
  awk -F '\t' -v c="${config}" -v s="${stage}" \
    '$1==c && $2==s && $3=="OK" {ok=1} END {exit !ok}' "${STATUS}"
}

record() {
  printf '%s\t%s\t%s\t%s\t%s\n' "$1" "$2" "$3" "$4" "$5" >> "${STATUS}"
}

for config in selected all; do
  prefix="graphmixer_${config}_target_mooc_seed${SEED}"
  checkpoint="saved_models/${prefix}_pretrained.pth"
  result_csv="${RESULT_DIR}/${config}.csv"

  read -r -a datasets <<< "${SOURCES[$config]}"

  if ! already_ok "${config}" pretrain || [[ ! -s "${checkpoint}" ]]; then
    echo "===== GRAPHMIXER PRETRAIN ${config}; sources=${SOURCES[$config]} ====="
    start=$(date +%s)
    set +e
    "${PYTHON}" pretrain_foundation.py \
      --datasets "${datasets[@]}" \
      --backbone graphmixer \
      --epochs 25 --bs 512 --shared_dim 128 --time_dim 64 \
      --num_layers 2 --num_neighbors 10 --n_head 2 \
      --lr 0.0005 --drop_out 0.1 --eval_every 5 \
      --limit_batches 100000 --total_batches_per_epoch 160 \
      --gpu "${GPU}" --seed "${SEED}" --prefix "${prefix}" \
      --domain_weighting uniform \
      > "${LOG_DIR}/${config}_pretrain.log" 2>&1
    rc=$?
    set -e
    seconds=$(( $(date +%s) - start ))
    if [[ ${rc} -ne 0 || ! -s "${checkpoint}" ]]; then
      record "${config}" pretrain FAILED "${rc}" "${seconds}"
      echo "FAILED GraphMixer pretrain ${config}; see ${LOG_DIR}/${config}_pretrain.log" >&2
      exit 1
    fi
    record "${config}" pretrain OK 0 "${seconds}"
  fi

  if ! already_ok "${config}" eval || [[ ! -s "${result_csv}" ]]; then
    echo "===== GRAPHMIXER FE LP ${config} -> MOOC ====="
    start=$(date +%s)
    set +e
    "${PYTHON}" finetune_foundation.py \
      --task link_prediction --dataset mooc --mode fe \
      --pretrained_path "${checkpoint}" --epochs 20 \
      --gpu "${GPU}" --bs 512 --seed "${SEED}" \
      --prefix "${prefix}_fe_lp" --results_csv "${result_csv}" \
      > "${LOG_DIR}/${config}_eval.log" 2>&1
    rc=$?
    set -e
    seconds=$(( $(date +%s) - start ))
    if [[ ${rc} -ne 0 || ! -s "${result_csv}" ]]; then
      record "${config}" eval FAILED "${rc}" "${seconds}"
      echo "FAILED GraphMixer eval ${config}; see ${LOG_DIR}/${config}_eval.log" >&2
      exit 1
    fi
    record "${config}" eval OK 0 "${seconds}"
  fi
  echo "OK GraphMixer ${config}"
done

"${PYTHON}" analyze_graphmixer_mooc.py \
  --results_dir "${RESULT_DIR}" \
  --output "${RUN_DIR}/comparison.csv"

echo "GraphMixer MOOC seed-${SEED} comparison finished."
