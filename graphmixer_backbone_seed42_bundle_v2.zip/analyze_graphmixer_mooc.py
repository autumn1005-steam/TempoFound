import argparse
from pathlib import Path

import pandas as pd


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results_dir", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    rows = []
    for config in ("selected", "all"):
        path = Path(args.results_dir) / f"{config}.csv"
        frame = pd.read_csv(path)
        row = frame.iloc[-1].copy()
        row["config"] = config
        rows.append(row)

    result = pd.DataFrame(rows)
    result = result[["config", "seed", "test_AP", "test_AUC", "epochs", "pretrained"]]
    all_ap = float(result.loc[result.config.eq("all"), "test_AP"].iloc[0])
    result["AP_minus_all"] = result["test_AP"] - all_ap
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(args.output, index=False)
    print(result.round(4).to_string(index=False))


if __name__ == "__main__":
    main()
