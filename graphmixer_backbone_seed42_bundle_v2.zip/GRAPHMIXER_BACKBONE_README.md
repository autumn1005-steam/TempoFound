# GraphMixer-style cross-backbone check

This bundle adds a fixed-history token/channel mixing encoder. Existing TGAT
commands remain unchanged because `--backbone` defaults to `tgat`.

The first controlled check uses MOOC as an unseen target and compares:

- `selected`: Wikipedia + Reddit source pre-training.
- `all`: Wikipedia + Reddit + UCI + Enron source pre-training.

Both use the same pre-training budget and frozen-encoder adaptation protocol.
Seed 42 is required before launching a full multi-seed replication.
