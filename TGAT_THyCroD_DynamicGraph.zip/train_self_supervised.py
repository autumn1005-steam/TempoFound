"""Compatibility entrypoint for TGAT/T-HyCroD self-supervised link prediction.

The original repository names the link prediction training script
``learn_edge.py``. This wrapper preserves that implementation and exposes the
expected ``train_self_supervised.py`` entrypoint without duplicating the data
split, negative sampler, or evaluator.
"""

import runpy


if __name__ == "__main__":
    runpy.run_module("learn_edge", run_name="__main__")
