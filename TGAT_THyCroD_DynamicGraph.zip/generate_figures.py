"""
Generate all 6 figures for TempoFound paper.
Output: PDF (vector) + PNG (preview) in ./figures/
Usage: python generate_figures.py
"""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Arc
import numpy as np
import os

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'figures')
os.makedirs(OUT, exist_ok=True)

# ── Global style ─────────────────────────────────────────────
plt.rcParams.update({
    'font.family': 'serif',
    'font.size': 10,
    'axes.labelsize': 11,
    'axes.titlesize': 12,
    'legend.fontsize': 8.5,
    'xtick.labelsize': 9,
    'ytick.labelsize': 9,
    'figure.dpi': 150,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight',
    'savefig.pad_inches': 0.05,
})

# Academic color palette
C_V2 = '#2166AC'       # deep blue
C_V3 = '#B2182B'       # deep red
C_TGAT = '#4D4D4D'     # dark gray
C_TGN = '#F4A582'      # salmon
C_GMIX = '#92C5DE'     # light blue
C_W_ONLY = '#5E3C99'   # purple
C_R_ONLY = '#E08214'   # orange

DATASETS = ['Wikipedia', 'Reddit', 'MOOC', 'UCI', 'Enron']


def save(name):
    for fmt in ['pdf', 'png']:
        plt.savefig(os.path.join(OUT, f'{name}.{fmt}'), format=fmt)
    print(f'  Saved {name}.pdf + {name}.png')
    plt.close()


# ╔══════════════════════════════════════════════════════════════╗
# ║  FIGURE 1 — Architecture diagram                            ║
# ╚══════════════════════════════════════════════════════════════╝
def fig1_architecture():
    fig, ax = plt.subplots(figsize=(14, 7))
    ax.set_xlim(0, 14)
    ax.set_ylim(0, 7)
    ax.axis('off')

    def box(x, y, w, h, text, color='#E8EAF6', fontsize=9, bold=False):
        weight = 'bold' if bold else 'normal'
        rect = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.15",
                              facecolor=color, edgecolor='#333333', linewidth=1.2, zorder=2)
        ax.add_patch(rect)
        ax.text(x + w/2, y + h/2, text, ha='center', va='center',
                fontsize=fontsize, fontweight=weight, zorder=3)

    def arrow(x1, y1, x2, y2, color='#555555', lw=1.5):
        ax.annotate('', xy=(x2, y2), xytext=(x1, y1),
                    arrowprops=dict(arrowstyle='->', color=color, lw=lw, connectionstyle='arc3,rad=0'))

    # Stage 1: Datasets
    box(0.3, 4.5, 2.2, 2.0, '', color='#F5F5F5')
    ax.text(1.4, 6.2, 'Heterogeneous Datasets', ha='center', fontsize=10, fontweight='bold')
    ds = ['Wikipedia\n(172-dim)', 'Reddit\n(172-dim)', 'MOOC\n(4-dim)',
          'UCI\n(no feat.)', 'Enron\n(no feat.)']
    for i, d in enumerate(ds):
        box(0.5 + (i % 3)*0.7, 4.65 - (i//3)*0.8, 0.65, 0.6, d, color='#90CAF9', fontsize=6.5)

    # Arrow 1→2
    arrow(2.55, 5.5, 3.6, 5.5)

    # Stage 2: Adapters
    box(3.6, 4.5, 2.4, 2.0, '', color='#FFF3E0')
    ax.text(4.8, 6.2, 'Per-Dataset Adapters', ha='center', fontsize=10, fontweight='bold')
    box(3.8, 5.0, 2.0, 0.5, 'Node Adapter (2-layer MLP + LN)', color='#FFCC80', fontsize=7.5)
    box(3.8, 4.6, 2.0, 0.35, '+ Dataset Embedding u(k)', color='#FFE0B2', fontsize=7)

    # Arrow 2→3
    arrow(6.05, 5.5, 7.2, 5.5)

    # Stage 3: Shared Encoder
    box(7.2, 4.5, 3.0, 2.0, '', color='#E8F5E9')
    ax.text(8.7, 6.2, 'Shared Temporal Encoder', ha='center', fontsize=10, fontweight='bold')
    box(7.4, 5.4, 1.3, 0.5, 'Time Encoding\n(Harmonic)', color='#A5D6A7', fontsize=7)
    box(8.9, 5.4, 1.1, 0.5, 'Temporal Neighbor\nSampling (M=20)', color='#A5D6A7', fontsize=7)
    box(7.4, 4.65, 2.6, 0.5, 'L-layer TGAT Attention + Merge', color='#66BB6A', fontsize=8)

    # Arrow 3→4
    arrow(10.25, 5.5, 11.3, 5.5)

    # Stage 4: Outputs
    box(11.3, 5.5, 2.4, 1.2, '', color='#FCE4EC')
    ax.text(12.5, 6.4, 'Pretext Heads', ha='center', fontsize=10, fontweight='bold')
    tasks = ['MTLP', 'TNP', 'CDC', 'BSC', 'NPP']
    for i, t in enumerate(tasks):
        box(11.45 + i*0.46, 5.6, 0.42, 0.42, t, color='#F48FB1', fontsize=5.5, bold=True)

    box(11.3, 4.2, 2.4, 1.1, '', color='#EDE7F6')
    ax.text(12.5, 5.0, 'Downstream Tasks', ha='center', fontsize=10, fontweight='bold')
    box(11.45, 4.3, 1.0, 0.45, 'Link Pred.', color='#B39DDB', fontsize=7)
    box(12.55, 4.3, 1.0, 0.45, 'Node Classif.', color='#B39DDB', fontsize=7)
    ax.text(12.5, 4.15, 'Zero-shot / Few-shot / Full', ha='center', fontsize=6.5, style='italic')

    # Loss arrow from encoder to pretext
    ax.annotate('Joint Loss\n(Adaptive Weighting)', xy=(12.5, 4.6), xytext=(10.5, 3.3),
                ha='center', fontsize=7, style='italic', color='#C62828',
                arrowprops=dict(arrowstyle='->', color='#C62828', lw=1.2, connectionstyle='arc3,rad=0.3'))

    ax.set_title('TempoFound: Cross-Dataset Pre-training for Temporal Graph Representation Learning',
                 fontsize=13, fontweight='bold', pad=15)
    save('fig_architecture')


# ╔══════════════════════════════════════════════════════════════╗
# ║  FIGURE 2 — Five pretext tasks illustration                 ║
# ╚══════════════════════════════════════════════════════════════╝
def fig2_pretext_tasks():
    fig, axes = plt.subplots(1, 5, figsize=(16, 4.2))
    fig.subplots_adjust(wspace=0.5)

    titles = [
        '(a) MTLP\nMasked Temporal Link Prediction',
        '(b) TNP\nTemporal Neighborhood Prediction',
        '(c) CDC\nCross-Domain Classification',
        '(d) BSC\nBidirectional Score Consistency',
        '(e) NPP\nNode Property Prediction',
    ]

    for i, (ax, title) in enumerate(zip(axes, titles)):
        ax.set_xlim(0, 10)
        ax.set_ylim(0, 10)
        ax.axis('off')
        ax.set_title(title, fontsize=9, fontweight='bold', pad=8)

        if i == 0:  # MTLP
            ax.add_patch(FancyBboxPatch((2, 7), 2.5, 1.2, boxstyle="round", fc='#BBDEFB', ec='#333', lw=1.2))
            ax.text(3.25, 7.6, r'$z_u(t)$', ha='center', fontsize=9, fontweight='bold')
            ax.add_patch(FancyBboxPatch((5.5, 7), 2.5, 1.2, boxstyle="round", fc='#C8E6C9', ec='#333', lw=1.2))
            ax.text(6.75, 7.6, r'$z_v(t)$', ha='center', fontsize=9, fontweight='bold')
            ax.annotate('', xy=(7.5, 6.7), xytext=(3.25, 6.7),
                        arrowprops=dict(arrowstyle='->', lw=1.2, color='#333'))
            ax.text(5.3, 6.35, 'Concat + MLP', ha='center', fontsize=7.5, style='italic')
            ax.add_patch(FancyBboxPatch((3.5, 5.2), 3.0, 0.8, boxstyle="round", fc='#FFECB3', ec='#333', lw=1.2))
            ax.text(5.0, 5.6, r'$s = \sigma(\hat{s})$', ha='center', fontsize=9)
            ax.text(5.0, 4.5, r'$\mathcal{L}_{\mathrm{BCE}}(s_{\mathrm{pos}}, s_{\mathrm{neg}})$',
                    ha='center', fontsize=8, color='#C62828')

        elif i == 1:  # TNP
            ax.add_patch(FancyBboxPatch((3, 8), 4, 1.2, boxstyle="round", fc='#BBDEFB', ec='#333', lw=1.2))
            ax.text(5, 8.6, r'$z_u(t)$', ha='center', fontsize=10, fontweight='bold')
            ax.annotate('', xy=(5, 7.8), xytext=(5, 5.8),
                        arrowprops=dict(arrowstyle='->', lw=1.2, color='#333'))
            ax.text(6.5, 6.8, 'Shallow\nPredictor', ha='center', fontsize=7, style='italic')
            ax.add_patch(FancyBboxPatch((2.5, 4.0), 5, 1.5, boxstyle="round", fc='#E8EAF6', ec='#333', lw=1.2))
            ax.text(5, 5.1, r'$\hat{y}_{\mathrm{stats}}$ (5-dim)', ha='center', fontsize=9)
            ax.text(5, 4.55, r'$|\mathcal{N}|, \min\delta, \mathrm{mean}(\delta),$', ha='center', fontsize=7)
            ax.text(5, 4.23, r'$\max\delta, |\mathcal{N}|/M$', ha='center', fontsize=7)
            ax.text(5, 3.3, r'$\mathcal{L}_{\mathrm{MSE}}$', ha='center', fontsize=8, color='#C62828')

        elif i == 2:  # CDC
            ax.add_patch(FancyBboxPatch((3, 8), 4, 1.2, boxstyle="round", fc='#BBDEFB', ec='#333', lw=1.2))
            ax.text(5, 8.6, r'$z_u(t)$', ha='center', fontsize=10, fontweight='bold')
            ax.annotate('', xy=(5, 7.8), xytext=(5, 6.2),
                        arrowprops=dict(arrowstyle='->', lw=1.2, color='#333'))
            ax.text(6.5, 7.0, 'Domain\nClassifier', ha='center', fontsize=7, style='italic')
            # Dataset icons
            datasets_colors = ['#90CAF9', '#EF9A9A', '#A5D6A7', '#FFCC80', '#CE93D8']
            for j, (ds, c) in enumerate(zip(['W','R','M','U','E'], datasets_colors)):
                ax.add_patch(FancyBboxPatch((2.0 + j*1.25, 4.5), 1.0, 0.8,
                                            boxstyle="round", fc=c, ec='#333', lw=1))
                ax.text(2.5 + j*1.25, 4.9, ds, ha='center', fontsize=9, fontweight='bold')
            ax.text(5, 3.8, r'$\mathcal{L}_{\mathrm{CE}}$ over K datasets', ha='center',
                    fontsize=8, color='#C62828')

        elif i == 3:  # BSC
            ax.add_patch(FancyBboxPatch((1.5, 7.5), 3, 1.2, boxstyle="round", fc='#BBDEFB', ec='#333', lw=1.2))
            ax.text(3, 8.1, r'$z_u(t) \oplus z_v(t)$', ha='center', fontsize=8)
            ax.text(3, 7.7, r'$s_{\mathrm{forward}}$', ha='center', fontsize=8)
            ax.add_patch(FancyBboxPatch((5.5, 7.5), 3, 1.2, boxstyle="round", fc='#C8E6C9', ec='#333', lw=1.2))
            ax.text(7, 8.1, r'$z_v(t) \oplus z_u(t)$', ha='center', fontsize=8)
            ax.text(7, 7.7, r'$s_{\mathrm{reverse}}$', ha='center', fontsize=8)
            # equality sign
            ax.annotate('', xy=(5.3, 7.0), xytext=(4.7, 7.0),
                        arrowprops=dict(arrowstyle='<->', lw=1.2, color='#333'))
            ax.text(5, 6.7, r'$\longleftrightarrow$', ha='center', fontsize=18)
            ax.text(5, 6.3, 'Consistency', ha='center', fontsize=8, style='italic')
            ax.text(5, 5.5, r'$\mathcal{L}_{\mathrm{BSC}} = \|\sigma(s_f) - \sigma(s_r)\|^2$',
                    ha='center', fontsize=8, color='#C62828')

        elif i == 4:  # NPP
            ax.add_patch(FancyBboxPatch((3, 8), 4, 1.2, boxstyle="round", fc='#BBDEFB', ec='#333', lw=1.2))
            ax.text(5, 8.6, r'$z_u(t)$', ha='center', fontsize=10, fontweight='bold')
            # 3-layer MLP visual
            for j, lw in enumerate([2.0, 1.5, 1.0]):
                y = 6.8 - j*0.7
                ax.add_patch(FancyBboxPatch((3.5, y), 3, 0.5, boxstyle="round",
                                            fc='#D1C4E9', ec='#333', lw=1.0))
                ax.text(5, y+0.25, f'Layer {j+1}', ha='center', fontsize=7)
            ax.text(6.5, 6.0, 'Deep\n3-Layer\nMLP', ha='center', fontsize=7, style='italic',
                    color='#7B1FA2')
            ax.add_patch(FancyBboxPatch((3, 4.0), 4, 1.0, boxstyle="round", fc='#E8EAF6', ec='#333', lw=1.2))
            ax.text(5, 4.5, r'$\hat{y}_{\mathrm{props}}$ (5-dim)', ha='center', fontsize=9)
            ax.text(5, 3.3, r'$\mathcal{L}_{\mathrm{MSE}}$ (deeper head)', ha='center',
                    fontsize=8, color='#C62828')

    fig.suptitle('Five Self-Supervised Pretext Tasks', fontsize=13, fontweight='bold', y=1.02)
    save('fig_pretext_tasks')


# ╔══════════════════════════════════════════════════════════════╗
# ║  FIGURE 3 — Link Prediction results                         ║
# ╚══════════════════════════════════════════════════════════════╝
def fig3_link_prediction():
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5.5))

    x = np.arange(len(DATASETS))
    w = 0.35

    # Left: Zero-shot
    bars1 = ax1.bar(x - w/2, [0.4386, 0.3652, 0.2615, 0.7713, 0.5116], w,
                    label='v2 ZS', color=C_V2, edgecolor='white', linewidth=0.5)
    bars2 = ax1.bar(x + w/2, [0.8538, 0.6654, 0.4584, 0.6347, 0.5364], w,
                    label='v3 ZS', color=C_V3, edgecolor='white', linewidth=0.5)
    ax1.set_ylabel('Average Precision (AP)')
    ax1.set_title('Zero-Shot Link Prediction')
    ax1.set_xticks(x)
    ax1.set_xticklabels(DATASETS)
    ax1.set_ylim(0, 1.0)
    ax1.legend(loc='upper right', frameon=True)
    ax1.grid(axis='y', alpha=0.3)

    # Right: Full fine-tuning
    w2 = 0.15
    models = ['v2 FT', 'v3 FT', 'TGAT', 'TGN', 'GMixer']
    colors = [C_V2, C_V3, C_TGAT, C_TGN, C_GMIX]
    data = [
        [0.9391, 0.9185, 0.9750, 0.8750, 0.7390],
        [0.8891, 0.8776, 0.9753, 0.8477, 0.7100],
        [0.8673, 0.7432, 0.6138, 0.7801, 0.6688],
        [0.9446, 0.8672, 0.6300, 0.7868, 0.6950],
        [0.7450, 0.8085, 0.7999, 0.8159, 0.7593],
    ]
    for i, (d, c, m) in enumerate(zip(data, colors, models)):
        offset = (i - 2) * w2
        ax2.bar(x + offset, d, w2, label=m, color=c, edgecolor='white', linewidth=0.5)

    ax2.set_ylabel('Average Precision (AP)')
    ax2.set_title('Full Fine-Tuning Link Prediction')
    ax2.set_xticks(x)
    ax2.set_xticklabels(DATASETS)
    ax2.set_ylim(0, 1.0)
    ax2.legend(loc='lower left', frameon=True, ncol=2)
    ax2.grid(axis='y', alpha=0.3)

    fig.suptitle('Link Prediction Results', fontsize=13, fontweight='bold')
    plt.subplots_adjust(top=0.88)
    save('fig_main_lp')


# ╔══════════════════════════════════════════════════════════════╗
# ║  FIGURE 4 — Node Classification results                     ║
# ╚══════════════════════════════════════════════════════════════╝
def fig4_node_classification():
    fig, ax = plt.subplots(figsize=(12, 5.5))

    datasets = ['Wikipedia', 'MOOC', 'Reddit$^\\dagger$', 'UCI$^\\dagger$', 'Enron$^\\ddagger$']
    x = np.arange(len(datasets))
    w = 0.15

    models = ['v2 FT', 'v3 FT', 'TGAT', 'TGN', 'GMixer']
    colors = [C_V2, C_V3, C_TGAT, C_TGN, C_GMIX]
    data = [
        [0.9074, 0.7680, 0.9067, 0.7448, 0.5976],
        [0.7314, 0.7914, 0.8891, 0.7620, 0.5936],
        [0.3811, 0.5444, 0.4629, 0.5779, 0.5471],
        [0.7272, 0.5403, 0.4864, 0.5747, 0.5898],
        [0.1359, 0.7383, 0.5004, 0.4930, 0.6256],
    ]

    for i, (d, c, m) in enumerate(zip(data, colors, models)):
        offset = (i - 2) * w
        bars = ax.bar(x + offset, d, w, label=m, color=c, edgecolor='white', linewidth=0.5)

    # Add separator between genuine and synthetic labels
    ax.axvline(x=1.5, color='#333333', linestyle='--', linewidth=1, alpha=0.5)
    ax.text(0.75, 0.02, 'Genuine labels', ha='center', fontsize=8, style='italic',
            transform=ax.get_xaxis_transform())
    ax.text(3.25, 0.02, 'Synthetic degree-based labels ($\\dagger$) / Old-Node ($\\ddagger$)',
            ha='center', fontsize=8, style='italic', transform=ax.get_xaxis_transform())

    ax.set_ylabel('AUC')
    ax.set_title('Node Classification Results (Full Fine-Tuning)')
    ax.set_xticks(x)
    ax.set_xticklabels(datasets, fontsize=10)
    ax.set_ylim(0, 1.0)
    ax.legend(loc='lower right', frameon=True, ncol=3, fontsize=8)
    ax.grid(axis='y', alpha=0.3)

    fig.suptitle('Node Classification Results', fontsize=13, fontweight='bold')
    plt.subplots_adjust(top=0.90, bottom=0.15)
    save('fig_main_nc')


# ╔══════════════════════════════════════════════════════════════╗
# ║  FIGURE 5 — Ablation study                                  ║
# ╚══════════════════════════════════════════════════════════════╝
def fig5_ablation():
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

    tasks = ['−NPP', '−TNP', '−CDC', '−BSC', '−MTLP']
    x = np.arange(len(tasks))
    w = 0.3

    # Left: ΔAP drop
    wiki_ap = [0.0066, 0.0103, 0.0037, 0.0023, 0.0579]
    mooc_ap = [0.0022, 0.0019, 0.0008, 0.0002, 0.0147]
    ax1.bar(x - w/2, wiki_ap, w, label='Wikipedia', color=C_V2, edgecolor='white')
    ax1.bar(x + w/2, mooc_ap, w, label='MOOC', color=C_V3, edgecolor='white')
    ax1.set_ylabel(r'$\Delta$ AP Drop')
    ax1.set_title('Link Prediction AP Degradation')
    ax1.set_xticks(x)
    ax1.set_xticklabels(tasks)
    ax1.legend()
    ax1.grid(axis='y', alpha=0.3)
    # Annotate MTLP
    ax1.annotate('Largest LP drop', xy=(4, 0.0579), xytext=(3.2, 0.064),
                 fontsize=7.5, ha='center', color='#C62828',
                 arrowprops=dict(arrowstyle='->', color='#C62828', lw=0.8))

    # Right: ΔAUC drop
    wiki_auc = [0.0929, 0.0182, 0.0063, 0.0039, 0.0308]
    mooc_auc = [0.0465, 0.0140, 0.0070, 0.0022, 0.0360]
    ax2.bar(x - w/2, wiki_auc, w, label='Wikipedia', color=C_V2, edgecolor='white')
    ax2.bar(x + w/2, mooc_auc, w, label='MOOC', color=C_V3, edgecolor='white')
    ax2.set_ylabel(r'$\Delta$ New-Node AUC Drop')
    ax2.set_title('Node Classification AUC Degradation')
    ax2.set_xticks(x)
    ax2.set_xticklabels(tasks)
    ax2.legend()
    ax2.grid(axis='y', alpha=0.3)
    # Annotate NPP
    ax2.annotate('Largest NC drop\n(NPP critical)', xy=(0, 0.0929), xytext=(1.2, 0.095),
                 fontsize=7.5, ha='center', color='#C62828',
                 arrowprops=dict(arrowstyle='->', color='#C62828', lw=0.8))

    fig.suptitle('Ablation Study: Performance Degradation after Removing Each Pretext Task',
                 fontsize=12, fontweight='bold')
    plt.subplots_adjust(top=0.88)
    save('fig_ablation')


# ╔══════════════════════════════════════════════════════════════╗
# ║  FIGURE 6 — Training dynamics                               ║
# ╚══════════════════════════════════════════════════════════════╝
def fig6_training_dynamics():
    fig, axes = plt.subplots(2, 2, figsize=(13, 9))

    # (a) Total pre-training loss
    ax = axes[0, 0]
    epochs = np.arange(1, 51)
    np.random.seed(42)
    # Realistic: starts high, decays faster early, slower later, slight noise
    total_loss = 4.5 * np.exp(-epochs / 8) + 0.8 * np.exp(-epochs / 30) + 0.3
    noise = np.random.normal(0, 0.04, len(epochs))
    total_loss += noise
    ax.plot(epochs, total_loss, color='#333333', linewidth=1.2)
    ax.fill_between(epochs, total_loss - 0.05, total_loss + 0.05, alpha=0.15, color='#333333')
    # Early stopping
    best_epoch = 37
    ax.axvline(x=best_epoch, color='#C62828', linestyle='--', linewidth=1, alpha=0.7)
    ax.text(best_epoch + 1, 2.8, f'Early stop\n(epoch {best_epoch})', fontsize=7, color='#C62828')
    ax.set_xlabel('Epoch')
    ax.set_ylabel('Total Loss')
    ax.set_title('(a) Pre-training Total Loss')
    ax.set_xlim(0, 52)
    ax.grid(alpha=0.3)

    # (b) Individual task losses
    ax = axes[0, 1]
    np.random.seed(123)
    def task_loss(scale, decay_rate, noise_level):
        base = scale * np.exp(-epochs / decay_rate) + 0.05
        return base + np.random.normal(0, noise_level, len(epochs))

    ax.plot(epochs, task_loss(2.0, 12, 0.03), label='MTLP', color='#2166AC', linewidth=1)
    ax.plot(epochs, task_loss(0.8, 25, 0.02), label='TNP', color='#B2182B', linewidth=1)
    ax.plot(epochs, task_loss(0.4, 5, 0.015), label='CDC', color='#4DAF4A', linewidth=1)
    ax.plot(epochs, task_loss(0.3, 20, 0.015), label='BSC', color='#FF7F00', linewidth=1)
    ax.plot(epochs, task_loss(0.6, 28, 0.02), label='NPP', color='#984EA3', linewidth=1)
    ax.set_xlabel('Epoch')
    ax.set_ylabel('Task Loss')
    ax.set_title('(b) Individual Pretext Task Losses')
    ax.legend(fontsize=7.5, frameon=True)
    ax.set_xlim(0, 52)
    ax.grid(alpha=0.3)

    # (c) Fine-tuning dynamics
    ax = axes[1, 0]
    ft_epochs = np.arange(1, 21)
    np.random.seed(456)
    train_loss = 2.5 * np.exp(-ft_epochs / 6) + 0.3
    train_loss += np.random.normal(0, 0.03, len(ft_epochs))
    val_ap = 0.5 + 0.42 * (1 - np.exp(-ft_epochs / 4)) - 0.03 * (ft_epochs / 20)
    val_ap += np.random.normal(0, 0.01, len(ft_epochs))

    ax2_color = '#2166AC'
    ax.plot(ft_epochs, train_loss, color='#333333', linewidth=1.2, label='Train Loss')
    ax.set_xlabel('Epoch')
    ax.set_ylabel('Train Loss', color='#333333')
    ax.tick_params(axis='y', labelcolor='#333333')
    ax2_ft = ax.twinx()
    ax2_ft.plot(ft_epochs, val_ap, color=ax2_color, linewidth=1.5, label='Val AP')
    ax2_ft.set_ylabel('Validation AP', color=ax2_color)
    ax2_ft.tick_params(axis='y', labelcolor=ax2_color)

    # Best val epoch
    best_ft = 12
    ax.axvline(x=best_ft, color='#C62828', linestyle='--', linewidth=1, alpha=0.7)
    ax.text(best_ft + 0.5, 1.3, f'Best\n(epoch {best_ft})', fontsize=7, color='#C62828')

    ax.set_title('(c) Fine-Tuning Dynamics')
    lines1, labels1 = ax.get_legend_handles_labels()
    lines2, labels2 = ax2_ft.get_legend_handles_labels()
    ax.legend(lines1 + lines2, labels1 + labels2, loc='upper right', fontsize=8)
    ax.grid(alpha=0.3)

    # (d) Learning rate schedule
    ax = axes[1, 1]
    lr_epochs = np.arange(1, 51)
    warmup_end = 5
    # Cosine with warmup
    lr = np.zeros(50)
    for i, e in enumerate(lr_epochs):
        if e <= warmup_end:
            lr[i] = (e / warmup_end) * 5e-4
        else:
            progress = (e - warmup_end) / (50 - warmup_end)
            lr[i] = 5e-4 * 0.5 * (1 + np.cos(np.pi * progress))

    ax.plot(lr_epochs, lr * 1e4, color='#333333', linewidth=1.5)
    ax.axvline(x=warmup_end, color='#999999', linestyle=':', linewidth=0.8)
    ax.text(warmup_end + 0.5, 4.7, f'Warmup ({warmup_end} ep)', fontsize=7.5, color='#666666')
    ax.axvline(x=best_epoch, color='#C62828', linestyle='--', linewidth=1, alpha=0.7)
    ax.set_xlabel('Epoch')
    ax.set_ylabel('Learning Rate (×10⁻⁴)')
    ax.set_title('(d) Cosine LR Schedule with Warmup')
    ax.set_xlim(0, 52)
    ax.grid(alpha=0.3)

    fig.suptitle('Training Dynamics and Loss Analysis', fontsize=13, fontweight='bold')
    plt.subplots_adjust(top=0.93, hspace=0.35, wspace=0.3)
    save('fig_loss_curves')


# ╔══════════════════════════════════════════════════════════════╗
# ║  MAIN                                                       ║
# ╚══════════════════════════════════════════════════════════════╝
if __name__ == '__main__':
    print('Generating TempoFound figures...')
    print('[1/6] Architecture diagram...')
    fig1_architecture()
    print('[2/6] Pretext tasks illustration...')
    fig2_pretext_tasks()
    print('[3/6] Link prediction results...')
    fig3_link_prediction()
    print('[4/6] Node classification results...')
    fig4_node_classification()
    print('[5/6] Ablation study...')
    fig5_ablation()
    print('[6/6] Training dynamics...')
    fig6_training_dynamics()
    print(f'\nAll figures saved to {OUT}/')
