"""
Phase 3 ablation finetuning: W_only + R_only pretrained models.
Runs LP + NC on Wikipedia + MOOC, saves to results_ablation.csv.
Usage: python run_phase3_finetune.py --gpu 0
"""
import subprocess, sys, os, re, csv, time

GPU = 0
EPOCHS = 3
BS = 512
LR = 0.0001
NUM_NEIGHBORS = 5
LIMIT_BATCHES = 12

SCRIPT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'finetune_foundation.py')
RESULTS = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'results_ablation.csv')

PRETRAINED = {
    'W_only': os.path.join(os.path.dirname(os.path.abspath(__file__)),
                          'saved_models', 'ablation_W_only_pretrained.pth'),
    'R_only': os.path.join(os.path.dirname(os.path.abspath(__file__)),
                          'saved_models', 'ablation_R_only_pretrained.pth'),
}
DATASETS = ['wikipedia', 'mooc']
TASKS = ['link_prediction', 'node_classification']


def parse_finetune_output(stdout):
    """Parse test AP/AUC from finetune output (both LP and NC formats)."""
    r = {}
    for pat, key in [
        # LP final test output: "Link Prediction ... AP=0.9007 AUC=0.8693 Acc=0.7858"
        (r'Link Prediction[^=]*AP=([\d.]+)', 'test_ap'),
        (r'Link Prediction[^=]*AUC=([\d.]+)', 'test_auc'),
        (r'Link Prediction[^=]*Acc=([\d.]+)', 'test_acc'),
        # NC output: "Test — AUC=... AP=... NewNodeAUC=..."
        (r'Test — .*NewNodeAUC=([\d.]+)', 'new_node_auc'),
        (r'Test — .*NewNodeAP=([\d.]+)', 'new_node_ap'),
        (r'Test — .*OldNodeAUC=([\d.]+)', 'old_node_auc'),
        (r'Test — .*OldNodeAP=([\d.]+)', 'old_node_ap'),
        (r'Test — AP=([\d.]+)', 'test_ap'),
        (r'Test — AUC=([\d.]+)', 'test_auc'),
        (r'Test — Acc=([\d.]+)', 'test_acc'),
    ]:
        m = re.search(pat, stdout)
        if m:
            r[key] = float(m.group(1))
    return r


def run(pretrained_key, task, dataset):
    pretrained = PRETRAINED[pretrained_key]
    if not os.path.exists(pretrained):
        print(f'SKIP: {pretrained} not found')
        return None

    prefix = f'ablation_{pretrained_key}_ft'
    cmd = [
        sys.executable, SCRIPT,
        '--task', task,
        '--dataset', dataset,
        '--mode', 'full',
        '--pretrained_path', pretrained,
        '--epochs', str(EPOCHS),
        '--bs', str(BS),
        '--lr', str(LR),
        '--num_neighbors', str(NUM_NEIGHBORS),
        '--limit_batches', str(LIMIT_BATCHES),
        '--prefix', prefix,
        '--gpu', str(GPU),
    ]
    if task == 'node_classification':
        cmd += ['--weighted_bce', '--link_aux_weight', '1.0']

    tag = f'{pretrained_key}/{task}/{dataset}'
    print(f'\n{"="*60}')
    print(f'[{time.strftime("%H:%M:%S")}] {tag}')
    print(f'{"="*60}')

    try:
        r = subprocess.run(cmd, cwd=os.path.dirname(os.path.abspath(__file__)),
                           capture_output=True, text=True, timeout=36000)
        stdout = r.stdout + r.stderr
        tail = stdout[-3000:] if len(stdout) > 3000 else stdout
        print(tail)
        if r.returncode != 0:
            print(f'WARNING: exit code {r.returncode}')
        metrics = parse_finetune_output(stdout)
        print(f'Parsed: {metrics}')
        return metrics
    except subprocess.TimeoutExpired:
        print(f'TIMEOUT: {tag}')
        return {}
    except Exception as e:
        print(f'ERROR: {e}')
        return {}


def main():
    all_rows = []
    existing_keys = set()
    if os.path.exists(RESULTS):
        with open(RESULTS) as f:
            for row in csv.DictReader(f):
                existing_keys.add((row['pretrained'], row['task'], row['dataset']))
                all_rows.append(row)

    for pk in ['W_only', 'R_only']:
        for task in TASKS:
            for ds in DATASETS:
                if (pk, task, ds) in existing_keys:
                    print(f'SKIP (exists): {pk}/{task}/{ds}')
                    continue
                m = run(pk, task, ds)
                row = {
                    'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
                    'pretrained': pk,
                    'task': task,
                    'dataset': ds,
                }
                if m:
                    row.update(m)
                all_rows.append(row)
                # save incrementally
                keys = all_rows[0].keys()
                with open(RESULTS, 'w', newline='') as f:
                    w = csv.DictWriter(f, fieldnames=keys)
                    w.writeheader()
                    w.writerows(all_rows)
                print(f'  -> saved to {RESULTS}')

    print(f'\n{"="*60}')
    print(f'Phase 3 complete! {len(all_rows)} runs in {RESULTS}')
    print(f'{"="*60}')


if __name__ == '__main__':
    main()
