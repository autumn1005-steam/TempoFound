"""
Pre-training script for the Temporal Graph Foundation Model.

Jointly trains on Wikipedia + Reddit + MOOC with 4 self-supervised pretext tasks:
  MTLP — Masked Temporal Link Prediction
  TNP  — Temporal Neighborhood Prediction
  CDC  — Cross-Domain Contrastive (via domain discrimination)
  EFR  — Edge Feature Reconstruction (bidirectional consistency)

Usage:
  python pretrain_foundation.py --epochs 50 --shared_dim 256 --lr 0.0005

After pre-training, the model is saved to ./saved_models/foundation_pretrained.pth
and can be fine-tuned with finetune_foundation.py.
"""

import math
import time
import random
import argparse
import logging
import sys
import os

import numpy as np
import pandas as pd
import torch

from sklearn.metrics import average_precision_score, roc_auc_score

from graph import NeighborFinder
from utils import RandEdgeSampler, EarlyStopMonitor
from foundation_model import TemporalGraphFoundationModel


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

parser = argparse.ArgumentParser('Temporal Graph Foundation Model — Pre-training')
parser.add_argument('--datasets', type=str, nargs='+',
                    default=['wikipedia', 'reddit', 'mooc'],
                    help='datasets to pre-train on')
parser.add_argument('--epochs', type=int, default=50, help='pre-training epochs')
parser.add_argument('--bs', type=int, default=512, help='batch size per dataset per step')
parser.add_argument('--shared_dim', type=int, default=256, help='shared hidden dimension')
parser.add_argument('--time_dim', type=int, default=128, help='time encoding dimension')
parser.add_argument('--num_layers', type=int, default=2, help='temporal encoder layers')
parser.add_argument('--num_neighbors', type=int, default=20, help='historical neighbors to sample')
parser.add_argument('--n_head', type=int, default=4, help='attention heads')
parser.add_argument('--lr', type=float, default=0.0005, help='learning rate')
parser.add_argument('--drop_out', type=float, default=0.1, help='dropout rate')
parser.add_argument('--gpu', type=int, default=0, help='GPU index (-1 for CPU)')
parser.add_argument('--prefix', type=str, default='foundation', help='save prefix')
parser.add_argument('--grad_accum', type=int, default=1, help='gradient accumulation steps')
parser.add_argument('--eval_every', type=int, default=1, help='evaluate every N epochs (default 1 for per-epoch early stopping with patience of max_round epochs)')
parser.add_argument('--warmup_epochs', type=int, default=5, help='linear LR warmup epochs (0 = no warmup)')
parser.add_argument('--limit_batches', type=int, default=200,
                    help='max batches per dataset per epoch (limits epoch length)')
parser.add_argument('--seed', type=int, default=42, help='random seed')
args = parser.parse_args()

random.seed(args.seed)
np.random.seed(args.seed)
torch.manual_seed(args.seed)

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
os.makedirs('log', exist_ok=True)
fh = logging.FileHandler(f'log/foundation_pretrain_{time.time():.0f}.log')
fh.setLevel(logging.DEBUG)
ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)
ch.setFormatter(formatter)
logger.addHandler(fh)
logger.addHandler(ch)

logger.info(args)

# ---------------------------------------------------------------------------
# Device
# ---------------------------------------------------------------------------

if args.gpu >= 0 and torch.cuda.is_available():
    device = torch.device(f'cuda:{args.gpu}')
else:
    device = torch.device('cpu')
logger.info(f'Using device: {device}')

# ---------------------------------------------------------------------------
# Load all datasets
# ---------------------------------------------------------------------------

def load_single_dataset(name):
    """Load one dataset, build NeighborFinder, return all necessary objects."""
    csv_path = f'./processed/ml_{name}.csv'
    npy_path = f'./processed/ml_{name}.npy'
    node_npy_path = f'./processed/ml_{name}_node.npy'

    df = pd.read_csv(csv_path)
    e_feat = np.load(npy_path)
    n_feat = np.load(node_npy_path)

    src_l = df.u.values
    dst_l = df.i.values
    e_idx_l = df.idx.values
    ts_l = df.ts.values
    label_l = df.label.values

    max_idx = max(src_l.max(), dst_l.max())

    # Train/val/test split by time
    val_time, test_time = list(np.quantile(ts_l, [0.70, 0.85]))

    # Build graphs
    adj_list = [[] for _ in range(max_idx + 1)]
    for src, dst, eidx, ts in zip(src_l, dst_l, e_idx_l, ts_l):
        adj_list[src].append((dst, eidx, ts))
        adj_list[dst].append((src, eidx, ts))
    full_ngh_finder = NeighborFinder(adj_list, uniform=False)

    # Training data: edges before val_time
    train_flag = ts_l <= val_time
    train_src = src_l[train_flag]
    train_dst = dst_l[train_flag]
    train_ts = ts_l[train_flag]

    # Validation data
    val_flag = (ts_l > val_time) & (ts_l <= test_time)
    val_src = src_l[val_flag]
    val_dst = dst_l[val_flag]
    val_ts = ts_l[val_flag]

    # Test data
    test_flag = ts_l > test_time
    test_src = src_l[test_flag]
    test_dst = dst_l[test_flag]
    test_ts = ts_l[test_flag]

    rand_sampler = RandEdgeSampler(train_src, train_dst)

    raw_node_dim = n_feat.shape[1]
    raw_edge_dim = e_feat.shape[1]

    config = {
        'name': name,
        'raw_node_dim': raw_node_dim,
        'raw_edge_dim': raw_edge_dim,
        'n_nodes': max_idx,
        'n_edges': len(e_feat) - 1,
    }

    data = {
        'df': df,
        'n_feat': n_feat,
        'e_feat': e_feat,
        'ngh_finder': full_ngh_finder,
        'rand_sampler': rand_sampler,
        'train_src': train_src,
        'train_dst': train_dst,
        'train_ts': train_ts,
        'val_src': val_src,
        'val_dst': val_dst,
        'val_ts': val_ts,
        'test_src': test_src,
        'test_dst': test_dst,
        'test_ts': test_ts,
        'val_time': val_time,
        'test_time': test_time,
    }

    return config, data


logger.info('Loading datasets...')
dataset_configs = []
dataset_data = {}

for ds_name in args.datasets:
    try:
        cfg, data = load_single_dataset(ds_name)
        dataset_configs.append(cfg)
        dataset_data[ds_name] = data
        logger.info(f'  {ds_name}: {cfg["n_nodes"]} nodes, {len(data["train_src"])} train edges, '
                    f'node_dim={cfg["raw_node_dim"]}, edge_dim={cfg["raw_edge_dim"]}')
    except FileNotFoundError as e:
        logger.warning(f'  {ds_name}: SKIPPED — {e}')
        logger.warning(f'  Run "python process.py" first to generate processed/ml_{ds_name}.csv')

if len(dataset_configs) == 0:
    logger.error('No datasets loaded. Run process.py first.')
    sys.exit(1)

# ---------------------------------------------------------------------------
# Build foundation model
# ---------------------------------------------------------------------------

logger.info('Building foundation model...')
model = TemporalGraphFoundationModel(
    dataset_configs=dataset_configs,
    shared_dim=args.shared_dim,
    time_dim=args.time_dim,
    num_layers=args.num_layers,
    n_head=args.n_head,
    drop_out=args.drop_out,
    num_neighbors=args.num_neighbors,
)
model = model.to(device)

# Load dataset raw embeddings
for ds_name in args.datasets:
    if ds_name in dataset_data:
        model.load_dataset_embeddings(ds_name, dataset_data[ds_name]['n_feat'], dataset_data[ds_name]['e_feat'])

total_params = sum(p.numel() for p in model.parameters())
trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
logger.info(f'Model params: {total_params:,} total, {trainable_params:,} trainable')

optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-5)
scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)

os.makedirs('./saved_models', exist_ok=True)
os.makedirs('./saved_checkpoints', exist_ok=True)
MODEL_SAVE_PATH = f'./saved_models/{args.prefix}_pretrained.pth'

# ---------------------------------------------------------------------------
# Pre-training loop
# ---------------------------------------------------------------------------

logger.info(f'Starting pre-training on {len(dataset_configs)} datasets for {args.epochs} epochs')
logger.info(f'Pretext tasks: MTLP + TNP + CDC + EFR + NPP')

best_val_ap = -1.0
early_stopper = EarlyStopMonitor(max_round=10, higher_better=True)

# Loss curve CSV logging
LOSS_CSV_PATH = f'log/pretrain_losses_{args.prefix}_{int(time.time())}.csv'
_loss_csv_columns = ['epoch', 'train_total', 'train_mtlp', 'train_tnp', 'train_cdc', 'train_efr', 'train_npp', 'lr']
for ds_name in args.datasets:
    _loss_csv_columns += [f'val_ap_{ds_name}', f'val_auc_{ds_name}']

def _init_loss_csv():
    with open(LOSS_CSV_PATH, 'w') as f:
        f.write(','.join(_loss_csv_columns) + '\n')

def _log_loss_row(epoch_num, train_losses, val_metrics, lr_val):
    row = {col: '' for col in _loss_csv_columns}
    row['epoch'] = epoch_num
    for k in train_losses:
        row[f'train_{k}'] = f'{train_losses[k]:.6f}'
    row['lr'] = f'{lr_val:.2e}'
    for ds, metrics in val_metrics.items():
        if 'ap' in metrics:
            row[f'val_ap_{ds}'] = f'{metrics["ap"]:.6f}'
        if 'auc' in metrics:
            row[f'val_auc_{ds}'] = f'{metrics["auc"]:.6f}'
    with open(LOSS_CSV_PATH, 'a') as f:
        f.write(','.join(str(row[c]) for c in _loss_csv_columns) + '\n')

_init_loss_csv()

for epoch in range(args.epochs):
    model.train()
    epoch_losses = {'mtlp': 0.0, 'tnp': 0.0, 'cdc': 0.0, 'efr': 0.0, 'npp': 0.0, 'total': 0.0}
    total_batches = 0

    # Linear LR warmup (0 → base_lr over warmup_epochs, then cosine decay)
    if args.warmup_epochs > 0 and epoch < args.warmup_epochs:
        warmup_factor = (epoch + 1) / args.warmup_epochs
        for param_group in optimizer.param_groups:
            param_group['lr'] = args.lr * warmup_factor

    # Iterate over datasets in shuffled order
    ds_order = list(args.datasets)
    random.shuffle(ds_order)

    for ds_name in ds_order:
        if ds_name not in dataset_data:
            continue
        data = dataset_data[ds_name]

        train_src = data['train_src']
        train_dst = data['train_dst']
        train_ts = data['train_ts']
        ngh_finder = data['ngh_finder']
        rand_sampler = data['rand_sampler']

        num_instances = len(train_src)
        num_batches = min(math.ceil(num_instances / args.bs), args.limit_batches)
        idx_list = np.arange(num_instances)
        np.random.shuffle(idx_list)

        for k in range(num_batches):
            s_idx = k * args.bs
            e_idx = min(num_instances, s_idx + args.bs)
            batch_idx = idx_list[s_idx:e_idx]
            size = len(batch_idx)
            if size == 0:
                continue

            src_l = train_src[batch_idx]
            dst_l = train_dst[batch_idx]
            ts_l = train_ts[batch_idx]
            neg_src, neg_dst = rand_sampler.sample(size)

            # Compute neighborhood stats for TNP pretext task
            ngh_stats = model.compute_neighborhood_stats(
                ds_name, ngh_finder, src_l, ts_l
            )

            # NPP uses same targets as TNP (reuse computed stats)
            node_props = ngh_stats

            # Pretext forward pass
            batch_data = {
                'src_idx': src_l,
                'dst_idx': dst_l,
                'cut_time': ts_l,
                'neg_dst_idx': neg_dst,
                'ngh_stats': ngh_stats,
                'node_props': node_props,
            }

            losses, _, _ = model.pretrain_forward(ds_name, ngh_finder, batch_data)
            total_loss = model.compute_pretrain_loss(losses)

            (total_loss / args.grad_accum).backward()

            if (k + 1) % args.grad_accum == 0 or k == num_batches - 1:
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                optimizer.step()
                optimizer.zero_grad()

            for key in epoch_losses:
                if key in losses:
                    epoch_losses[key] += losses[key].item()
            epoch_losses['total'] += total_loss.item()
            total_batches += 1

    # Average losses
    for key in epoch_losses:
        epoch_losses[key] /= max(total_batches, 1)

    scheduler.step()

    # Log task weights
    task_weights = torch.exp(-model.task_log_vars).detach().cpu().numpy()
    logger.info(
        f'Epoch {epoch:3d} | total={epoch_losses["total"]:.4f} '
        f'mtlp={epoch_losses["mtlp"]:.4f} tnp={epoch_losses["tnp"]:.4f} '
        f'cdc={epoch_losses["cdc"]:.4f} efr={epoch_losses["efr"]:.4f} '
        f'npp={epoch_losses["npp"]:.4f} '
        f'| w_mtlp={task_weights[0]:.3f} w_tnp={task_weights[1]:.3f} '
        f'w_cdc={task_weights[2]:.3f} w_efr={task_weights[3]:.3f} '
        f'w_npp={task_weights[4]:.3f} '
        f'| lr={scheduler.get_last_lr()[0]:.2e}'
    )

    val_metrics = {}
    # Validation (link prediction AP on each dataset)
    if (epoch + 1) % args.eval_every == 0:
        model.eval()
        val_aps = []
        with torch.no_grad():
            for ds_name in args.datasets:
                if ds_name not in dataset_data:
                    continue
                data = dataset_data[ds_name]
                ngh_finder = data['ngh_finder']
                val_src = data['val_src'][:500]
                val_dst = data['val_dst'][:500]
                val_ts = data['val_ts'][:500]
                rand_sampler = data['rand_sampler']

                pos_scores, neg_scores = [], []
                for j in range(0, len(val_src), 64):
                    s = val_src[j:j+64]
                    d = val_dst[j:j+64]
                    t = val_ts[j:j+64]
                    ns, nd = rand_sampler.sample(len(s))
                    src_emb = model.encode_nodes(ds_name, ngh_finder, s, t)
                    dst_emb = model.encode_nodes(ds_name, ngh_finder, d, t)
                    neg_emb = model.encode_nodes(ds_name, ngh_finder, nd, t)
                    pos_logit = model.link_head(src_emb, dst_emb)
                    neg_logit = model.link_head(src_emb, neg_emb)
                    pos_scores.append(torch.sigmoid(pos_logit).cpu().numpy())
                    neg_scores.append(torch.sigmoid(neg_logit).cpu().numpy())

                pos = np.concatenate(pos_scores)
                neg = np.concatenate(neg_scores)
                preds = np.concatenate([pos, neg])
                labels = np.concatenate([np.ones_like(pos), np.zeros_like(neg)])
                ap = average_precision_score(labels, preds)
                auc = roc_auc_score(labels, preds)
                val_aps.append(ap)
                val_metrics[ds_name] = {'ap': ap, 'auc': auc}
                logger.info(f'  Val {ds_name}: AP={ap:.4f} AUC={auc:.4f}')

        mean_val_ap = np.mean(val_aps) if val_aps else 0.0
        logger.info(f'  Mean val AP: {mean_val_ap:.4f}')

        # Save best checkpoints
        if mean_val_ap > best_val_ap + 1e-4:
            best_val_ap = mean_val_ap
            model.save_pretrained(MODEL_SAVE_PATH)
            logger.info(f'  [BEST] Model saved to {MODEL_SAVE_PATH} (AP={best_val_ap:.4f})')

        ckpt_path = f'./saved_checkpoints/{args.prefix}_epoch{epoch}.pth'
        model.save_pretrained(ckpt_path)

        if early_stopper.early_stop_check(mean_val_ap):
            logger.info(f'Early stopping at epoch {epoch}')
            _log_loss_row(epoch, epoch_losses, val_metrics, scheduler.get_last_lr()[0])
            break
        val_metrics = val_metrics or {}
    else:
        val_metrics = {}

    _log_loss_row(epoch, epoch_losses, val_metrics, scheduler.get_last_lr()[0])

# ---------------------------------------------------------------------------
# Final save
# ---------------------------------------------------------------------------

model.save_pretrained(MODEL_SAVE_PATH)
logger.info(f'Pre-training complete. Final model saved to {MODEL_SAVE_PATH}')
logger.info(f'Best validation AP: {best_val_ap:.4f}')
logger.info('Next step: run finetune_foundation.py for downstream task transfer.')
