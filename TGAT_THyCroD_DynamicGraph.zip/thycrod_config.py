VARIANT_CHOICES = [
    "full",
    "no_hyperbolic",
    "no_dynamic_contrastive",
    "no_hyperdiff",
    "single_view",
    "no_temporal",
    "no_historical_context",
]


def apply_thycrod_variant(args):
    """Apply T-HyCroD ablation variant switches in-place."""

    if args.variant == "full":
        args.use_hyperbolic = True
        args.use_hyperdiff = True
        args.use_time_encoding = True
        args.use_view_b = True
        args.use_historical_context = True
        return args

    if args.variant == "no_hyperbolic":
        args.use_hyperbolic = False
        args.lambda_dyn = 0.0
        args.lambda_hyp = 0.0
        args.use_hyperdiff = False
        args.use_contrastive = False
    elif args.variant == "no_dynamic_contrastive":
        args.lambda_dyn = 0.0
    elif args.variant == "no_hyperdiff":
        args.use_hyperdiff = False
        args.lambda_hyp = 0.0
    elif args.variant == "single_view":
        args.use_view_b = False
        args.use_hyperdiff = False
        args.lambda_dyn = 0.0
        args.lambda_hyp = 0.0
    elif args.variant == "no_temporal":
        args.use_time_encoding = False
    elif args.variant == "no_historical_context":
        args.use_historical_context = False

    return args
