@echo off
REM ============================================================================
REM Master experiment script — runs ALL TGFM paper experiments
REM Estimated total time on CPU: 100-200 hours
REM Run this script and leave it overnight / over the weekend.
REM ============================================================================
cd /d "C:\Users\18053\Desktop\TGFM\TGAT_THyCroD_DynamicGraph"

set PYTHON=C:\Users\18053\AppData\Local\Programs\Python\Python310\python.exe
set GPU=-1
set EPOCHS_LP=50
set EPOCHS_NC=15
set BS=200
set NC_BS=30
set SEEDS=42 123 2024
set MODELS=tgat tgn graphmixer
set DATASETS=wikipedia reddit mooc uci enron

echo ================================================================
echo Phase 1: Multi-seed Link Prediction (all models x all datasets)
echo ================================================================
%PYTHON% run_multiseed.py --models %MODELS% --datasets %DATASETS% --seeds %SEEDS% --task link_prediction --epochs %EPOCHS_LP% --bs %BS% --gpu %GPU% --prefix full_lp
if %ERRORLEVEL% NEQ 0 echo WARNING: Phase 1 had errors

echo ================================================================
echo Phase 2: Multi-seed Node Classification (all models x all datasets)
echo ================================================================
%PYTHON% run_multiseed.py --models %MODELS% --datasets %DATASETS% --seeds %SEEDS% --task node_classification --epochs %EPOCHS_NC% --bs %NC_BS% --gpu %GPU% --prefix full_nc
if %ERRORLEVEL% NEQ 0 echo WARNING: Phase 2 had errors

echo ================================================================
echo Phase 3: Ablation Study (dataset combinations)
echo ================================================================
%PYTHON% run_ablation_datasets.py --task link_prediction --pt_epochs %EPOCHS_LP% --ft_epochs 20 --gpu %GPU%
if %ERRORLEVEL% NEQ 0 echo WARNING: Phase 3 had errors

echo ================================================================
echo ALL EXPERIMENTS COMPLETE
echo Results: results_multiseed.csv, results_multiseed_agg.csv, results_ablation.csv
echo Loss curves: log/pretrain_losses_*.csv
echo ================================================================
