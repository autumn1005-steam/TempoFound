"""
Run ALL downstream evaluations for v5 foundation model:
  - Link prediction: full FT on all 5 datasets
  - Node classification: full FT on Wikipedia + MOOC (real labels)
                         + Reddit/UCI/Enron (synthetic degree labels)

Usage:
  python eval_all_v5.py --pretrained_path ./saved_models/foundation_v5_pretrained.pth
"""

import subprocess
import sys
import os
import time
import argparse

PRETRAINED = None
PYTHON = sys.executable

DATASETS = ['wikipedia', 'reddit', 'mooc', 'uci', 'enron']

# Node classification labels: real for wiki/mooc, synthetic for others
NODE_LABEL_MAP = {
    'wikipedia': '',   # use CSV labels (real: banned user)
    'reddit': './processed/ml_reddit_node_labels.npy',
    'mooc': '',        # use CSV labels (real: dropout)
    'uci': './processed/ml_uci_node_labels.npy',
    'enron': './processed/ml_enron_node_labels.npy',
}


def run(cmd, desc):
    print(f'\n{"="*70}')
    print(f'  {desc}')
    print(f'  CMD: {cmd}')
    print(f'{"="*70}')
    t0 = time.time()
    result = subprocess.run(cmd, shell=True)
    elapsed = time.time() - t0
    status = 'OK' if result.returncode == 0 else f'FAILED (exit={result.returncode})'
    print(f'  [{status}] {elapsed/60:.1f} min')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pretrained_path', default='./saved_models/foundation_v5_pretrained.pth')
    parser.add_argument('--skip_lp', action='store_true')
    parser.add_argument('--skip_node_clf', action='store_true')
    parser.add_argument('--epochs', type=int, default=20)
    parser.add_argument('--limit_batches', type=int, default=0)
    args = parser.parse_args()

    global PRETRAINED
    PRETRAINED = args.pretrained_path

    if not os.path.exists(PRETRAINED):
        print(f'ERROR: Pre-trained model not found: {PRETRAINED}')
        sys.exit(1)

    lb_flag = f' --limit_batches {args.limit_batches}' if args.limit_batches > 0 else ''

    # ---- Link Prediction ----
    if not args.skip_lp:
        for ds in DATASETS:
            cmd = (
                f'{PYTHON} finetune_foundation.py '
                f'--task link_prediction --dataset {ds} --mode full '
                f'--pretrained_path {PRETRAINED} '
                f'--epochs {args.epochs} '
                f'--prefix v5'
                f'{lb_flag}'
            )
            run(cmd, f'Link Prediction — {ds}')

    # ---- Node Classification ----
    if not args.skip_node_clf:
        for ds in DATASETS:
            label_flag = ''
            if NODE_LABEL_MAP.get(ds):
                label_flag = f' --node_label_path {NODE_LABEL_MAP[ds]}'

            cmd = (
                f'{PYTHON} finetune_foundation.py '
                f'--task node_classification --dataset {ds} --mode full '
                f'--pretrained_path {PRETRAINED} '
                f'--epochs {args.epochs} '
                f'--prefix v5'
                f'{label_flag}'
                f'{lb_flag}'
            )
            run(cmd, f'Node Classification — {ds}')

    print(f'\n{"="*70}')
    print('  ALL EVALUATIONS COMPLETE')
    print(f'{"="*70}')


if __name__ == '__main__':
    main()
