"""
Plot training/validation loss curves from logged CSVs.

Usage:
  # Pre-training losses
  python plot_loss_curves.py --mode pretrain --csv log/pretrain_losses_v2.csv --output fig_pretrain_loss.pdf

  # Fine-tuning losses
  python plot_loss_curves.py --mode finetune --csv log/finetune_losses_lp_wikipedia.csv --output fig_finetune_loss.pdf

  # Compare multiple runs
  python plot_loss_curves.py --mode compare --csv log/pretrain_losses_v2.csv log/pretrain_losses_v3.csv --output fig_compare.pdf
"""

import argparse
import os
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def plot_pretrain_losses(csv_path, output_path):
    """Plot pre-training loss components and validation AP."""
    data = np.genfromtxt(csv_path, delimiter=',', names=True, dtype=None, encoding='utf-8')
    if data.size == 0:
        print(f'No data in {csv_path}')
        return

    epochs = data['epoch'].astype(int)

    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    axes = axes.flatten()

    # Subplot 1: Total loss
    ax = axes[0]
    ax.plot(epochs, data['train_total'], 'b-', linewidth=1.5, label='Train Total Loss')
    ax.set_xlabel('Epoch')
    ax.set_ylabel('Total Loss')
    ax.set_title('Total Pre-training Loss')
    ax.legend()
    ax.grid(True, alpha=0.3)

    # Subplot 2: Individual pretext task losses
    ax = axes[1]
    task_names = ['train_mtlp', 'train_tnp', 'train_cdc', 'train_efr', 'train_npp']
    colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd']
    for task, color in zip(task_names, colors):
        if f"'{task}'" in data.dtype.names or task in data.dtype.names:
            ax.plot(epochs, data[task], '-', color=color, linewidth=1.0, alpha=0.8, label=task.replace('train_', '').upper())
    ax.set_xlabel('Epoch')
    ax.set_ylabel('Loss')
    ax.set_title('Pretext Task Losses')
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.3)

    # Subplot 3: Validation AP per dataset
    ax = axes[2]
    val_cols = [c for c in data.dtype.names if c.startswith('val_ap_')]
    for col in val_cols:
        ds_name = col.replace('val_ap_', '')
        mask = data[col] != 0  # skip epochs without validation
        if mask.any():
            ax.plot(epochs[mask], data[col][mask], 'o-', markersize=4, linewidth=1.5, label=ds_name)
    ax.set_xlabel('Epoch')
    ax.set_ylabel('Validation AP')
    ax.set_title('Validation Link Prediction AP')
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.3)

    # Subplot 4: Learning rate schedule + task weights
    ax = axes[3]
    ax.plot(epochs, data['lr'], 'k-', linewidth=1.5, label='Learning Rate')
    ax.set_xlabel('Epoch')
    ax.set_ylabel('Learning Rate')
    ax.set_title('Learning Rate Schedule')
    ax.legend()
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f'Pretrain loss plot saved to {output_path}')


def plot_finetune_losses(csv_path, output_path):
    """Plot fine-tuning loss and validation metrics."""
    data = np.genfromtxt(csv_path, delimiter=',', names=True, dtype=None, encoding='utf-8')
    if data.size == 0:
        print(f'No data in {csv_path}')
        return

    epochs = data['epoch'].astype(int)

    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    axes = axes.flatten()

    # Subplot 1: Train loss
    ax = axes[0]
    ax.plot(epochs, data['train_loss'], 'b-', linewidth=1.5, label='Train Loss')
    ax.set_xlabel('Epoch')
    ax.set_ylabel('Loss')
    ax.set_title('Training Loss')
    ax.legend()
    ax.grid(True, alpha=0.3)

    # Subplot 2: Validation AP and AUC
    ax = axes[1]
    if 'val_AP' in data.dtype.names:
        ax.plot(epochs, data['val_AP'], 'o-', color='#2ca02c', markersize=4, linewidth=1.5, label='Val AP')
    if 'val_AUC' in data.dtype.names:
        ax.plot(epochs, data['val_AUC'], 's-', color='#ff7f0e', markersize=4, linewidth=1.5, label='Val AUC')
    ax.set_xlabel('Epoch')
    ax.set_ylabel('Metric')
    ax.set_title('Validation Metrics')
    ax.legend()
    ax.grid(True, alpha=0.3)

    # Subplot 3: Train vs Val (overfitting analysis)
    ax = axes[2]
    ax.plot(epochs, data['train_loss'], 'b-', linewidth=1.5, label='Train Loss')
    if 'val_AP' in data.dtype.names:
        ax_twin = ax.twinx()
        ax_twin.plot(epochs, data['val_AP'], 'r--', linewidth=1.5, label='Val AP')
        ax_twin.set_ylabel('Val AP', color='r')
        ax_twin.tick_params(axis='y', labelcolor='r')
    ax.set_xlabel('Epoch')
    ax.set_ylabel('Train Loss', color='b')
    ax.tick_params(axis='y', labelcolor='b')
    ax.set_title('Overfitting Analysis (Train Loss vs Val AP)')
    ax.grid(True, alpha=0.3)

    # Subplot 4: Node classification specifics (if applicable)
    ax = axes[3]
    if 'val_NewNodeAUC' in data.dtype.names and 'val_OldNodeAUC' in data.dtype.names:
        mask_new = ~np.isnan(data['val_NewNodeAUC'])
        mask_old = ~np.isnan(data['val_OldNodeAUC'])
        if mask_new.any():
            ax.plot(epochs[mask_new], data['val_NewNodeAUC'][mask_new], 'o-', color='#9467bd', markersize=4, label='New Node AUC')
        if mask_old.any():
            ax.plot(epochs[mask_old], data['val_OldNodeAUC'][mask_old], 's-', color='#8c564b', markersize=4, label='Old Node AUC')
        ax.set_xlabel('Epoch')
        ax.set_ylabel('AUC')
        ax.set_title('Node Classification by Node Type')
        ax.legend()
        ax.grid(True, alpha=0.3)
    elif 'train_task_loss' in data.dtype.names and 'train_link_aux_loss' in data.dtype.names:
        ax.plot(epochs, data['train_task_loss'], '-', color='#1f77b4', linewidth=1.0, label='Task Loss')
        ax.plot(epochs, data['train_link_aux_loss'], '-', color='#ff7f0e', linewidth=1.0, label='Link Aux Loss')
        ax.set_xlabel('Epoch')
        ax.set_ylabel('Loss')
        ax.set_title('Task vs Auxiliary Loss')
        ax.legend()
        ax.grid(True, alpha=0.3)
    else:
        ax.text(0.5, 0.5, 'No node-specific data', ha='center', va='center', transform=ax.transAxes)
        ax.set_title('Additional Metrics')

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f'Finetune loss plot saved to {output_path}')


def plot_compare_runs(csv_paths, output_path, labels=None):
    """Compare multiple runs (e.g., v2 vs v3) on the same plot."""
    if labels is None:
        labels = [f'Run {i+1}' for i in range(len(csv_paths))]

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    for csv_path, label in zip(csv_paths, labels):
        data = np.genfromtxt(csv_path, delimiter=',', names=True, dtype=None, encoding='utf-8')
        if data.size == 0:
            continue
        epochs = data['epoch'].astype(int)
        axes[0].plot(epochs, data['train_total'], '-', linewidth=1.5, label=f'{label} Total Loss')
        axes[1].plot(epochs, data['train_mtlp'], '-', linewidth=1.0, alpha=0.7, label=f'{label} MTLP')

    axes[0].set_xlabel('Epoch')
    axes[0].set_ylabel('Loss')
    axes[0].set_title('Total Loss Comparison')
    axes[0].legend(fontsize=8)
    axes[0].grid(True, alpha=0.3)

    axes[1].set_xlabel('Epoch')
    axes[1].set_ylabel('Loss')
    axes[1].set_title('MTLP Loss Comparison')
    axes[1].legend(fontsize=8)
    axes[1].grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f'Comparison plot saved to {output_path}')


def main():
    parser = argparse.ArgumentParser('Plot Training Loss Curves')
    parser.add_argument('--mode', type=str, choices=['pretrain', 'finetune', 'compare'], required=True)
    parser.add_argument('--csv', type=str, nargs='+', required=True)
    parser.add_argument('--output', type=str, default='fig_loss_curves.pdf')
    parser.add_argument('--labels', type=str, nargs='+', default=None)
    args = parser.parse_args()

    plt.rcParams.update({
        'font.family': 'serif',
        'font.size': 11,
        'axes.labelsize': 12,
        'axes.titlesize': 13,
        'legend.fontsize': 9,
        'figure.dpi': 150,
    })

    if args.mode == 'pretrain':
        plot_pretrain_losses(args.csv[0], args.output)
    elif args.mode == 'finetune':
        plot_finetune_losses(args.csv[0], args.output)
    elif args.mode == 'compare':
        plot_compare_runs(args.csv, args.output, args.labels)


if __name__ == '__main__':
    main()
