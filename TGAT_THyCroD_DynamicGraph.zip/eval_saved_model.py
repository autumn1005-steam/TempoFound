"""
Evaluate a saved fine-tuned model on the test set.
Usage: python eval_saved_model.py --model ./saved_models/v2_link_prediction_uci.pth --task link_prediction --dataset uci
"""
import argparse, logging, time, os, sys
import numpy as np, pandas as pd, torch
from sklearn.metrics import average_precision_score, roc_auc_score, accuracy_score
from graph import NeighborFinder
from utils import RandEdgeSampler
from foundation_model import TemporalGraphFoundationModel

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

parser = argparse.ArgumentParser()
parser.add_argument('--model', required=True)
parser.add_argument('--task', required=True, choices=['link_prediction', 'node_classification'])
parser.add_argument('--dataset', required=True)
parser.add_argument('--pretrained_path', default='./saved_models/foundation_v2_pretrained.pth')
parser.add_argument('--node_label_path', default='')
parser.add_argument('--prefix', default='eval')
args = parser.parse_args()

device = torch.device('cpu')

# Load data
g_df = pd.read_csv(f'./processed/ml_{args.dataset}.csv')
e_feat = np.load(f'./processed/ml_{args.dataset}.npy')
n_feat = np.load(f'./processed/ml_{args.dataset}_node.npy')

val_time, test_time = list(np.quantile(g_df.ts, [0.70, 0.85]))
src = g_df.u.values; dst = g_df.i.values; e_idx = g_df.idx.values; ts = g_df.ts.values
label = g_df.label.values if 'label' in g_df.columns else np.zeros_like(src)

max_idx = max(src.max(), dst.max())
total_edges = len(src)

if args.node_label_path and os.path.exists(args.node_label_path):
    ext_labels = np.load(args.node_label_path)
    if len(ext_labels) == len(label):
        label = ext_labels.astype(np.int32)
        logger.info(f'Loaded external labels from {args.node_label_path}')

# Splits
val_mask = (ts > val_time) & (ts <= test_time)
test_mask = ts > test_time
train_mask = ts <= val_time

if args.task == 'node_classification':
    # For node classification we only use edges with valid labels
    valid_mask = (label >= 0) if not args.node_label_path else np.ones(len(src), dtype=bool)
    all_mask = val_mask | test_mask | train_mask
    val_mask = val_mask & valid_mask
    test_mask = test_mask & valid_mask
    train_mask = train_mask & valid_mask & ~val_mask & ~test_mask

test_src = src[test_mask]; test_dst = dst[test_mask]; test_ts = ts[test_mask]
test_labels = label[test_mask] if args.task == 'node_classification' else None
val_src = src[val_mask]; val_dst = dst[val_mask]; val_ts = ts[val_mask]
val_labels = label[val_mask] if args.task == 'node_classification' else None

logger.info(f'Dataset: {train_mask.sum()} train, {val_mask.sum()} val, {test_mask.sum()} test')

full_adj_list = [[] for _ in range(max_idx + 1)]
for s, d, eid, t in zip(src, dst, e_idx, ts):
    full_adj_list[s].append((d, eid, t))
    full_adj_list[d].append((s, eid, t))
full_ngh_finder = NeighborFinder(full_adj_list, uniform=False)

# Build model from pretrained + load fine-tuned weights
checkpoint = torch.load(args.pretrained_path, map_location=device, weights_only=False)
existing_names = [cfg['name'] for cfg in checkpoint['dataset_configs']]

new_config = {'name': args.dataset, 'raw_node_dim': n_feat.shape[1],
              'raw_edge_dim': e_feat.shape[1], 'n_nodes': max_idx,
              'n_edges': len(e_feat)-1}

if args.dataset in existing_names:
    model = TemporalGraphFoundationModel.load_pretrained(args.pretrained_path, map_location=device)
else:
    model = TemporalGraphFoundationModel.load_for_new_dataset(
        args.pretrained_path, new_config, map_location=device)

model = model.to(device)
model.load_dataset_embeddings(args.dataset, n_feat, e_feat)

# Free unused embeddings
for ds_name in list(model.dataset_node_embed.keys()):
    if ds_name != args.dataset:
        del model.dataset_node_embed[ds_name]
        del model.dataset_edge_embed[ds_name]

# Add task head
if args.task == 'link_prediction':
    model.add_finetune_link_head()
else:
    model.add_finetune_node_clf_head()

# Load fine-tuned weights (skip mismatched keys since we freed unused embeddings)
ft_state = torch.load(args.model, map_location=device, weights_only=False)
model_state = model.state_dict()
for k, v in ft_state.items():
    if k in model_state and model_state[k].shape == v.shape:
        model_state[k].copy_(v)
model.load_state_dict(model_state)
logger.info('Fine-tuned model loaded.')

# Evaluate
if args.task == 'link_prediction':
    rand_sampler = RandEdgeSampler(test_src, test_dst)
    with torch.no_grad():
        # Positive
        pos_logits = []
        bs = 512
        for k in range(0, len(test_src), bs):
            s = test_src[k:k+bs]; d = test_dst[k:k+bs]; t = test_ts[k:k+bs]
            pos_logits.append(model.finetune_link_forward(args.dataset, full_ngh_finder, s, d, t).cpu())
        pos_logits = torch.cat(pos_logits)

        # Negative
        neg_src, neg_dst = rand_sampler.sample(len(test_src))
        neg_logits = []
        for k in range(0, len(neg_src), bs):
            s = neg_src[k:k+bs]; d = neg_dst[k:k+bs]
            neg_logits.append(model.finetune_link_forward(args.dataset, full_ngh_finder, s, d, test_ts[k:k+bs]).cpu())
        neg_logits = torch.cat(neg_logits)

        y_true = np.concatenate([np.ones(len(test_src)), np.zeros(len(test_src))])
        y_score = torch.sigmoid(torch.cat([pos_logits, neg_logits])).numpy()

    ap = average_precision_score(y_true, y_score)
    auc = roc_auc_score(y_true, y_score)
    acc = accuracy_score(y_true, y_score > 0.5)
    logger.info(f'=== Test Results ===')
    logger.info(f'AP={ap:.4f} AUC={auc:.4f} Acc={acc:.4f}')
else:
    with torch.no_grad():
        src_emb = model.encode_nodes(args.dataset, full_ngh_finder, test_src, test_ts)
        dst_emb = model.encode_nodes(args.dataset, full_ngh_finder, test_dst, test_ts)
        node_stats = model.compute_node_stats_tensor(args.dataset, full_ngh_finder, test_src, test_ts)
        combined = torch.cat([src_emb, dst_emb, src_emb * dst_emb, node_stats], dim=-1)
        logits = model.ft_node_clf_head(combined).squeeze(-1)
        y_score = torch.sigmoid(logits).cpu().numpy()
        y_true = test_labels

    ap = average_precision_score(y_true, y_score)
    auc = roc_auc_score(y_true, y_score)
    acc = accuracy_score(y_true, y_score > 0.5)
    logger.info(f'=== Test Results ===')
    logger.info(f'AUC={auc:.4f} AP={ap:.4f} Acc={acc:.4f}')
