"""Real-time Phase 2 NC progress monitor. Ctrl+C to exit."""
import csv, time, os, sys

CSV = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'results_nc_phase2.csv')
MODELS = ['tgat', 'tgn', 'graphmixer']
DATASETS = ['wikipedia', 'reddit', 'mooc', 'uci', 'enron']
SEEDS = [42, 123, 2024]
TOTAL = len(MODELS) * len(DATASETS) * len(SEEDS)

prev = -1
while True:
    if not os.path.exists(CSV):
        print(f'Waiting for {CSV}...', end='\r')
        time.sleep(5)
        continue
    done_set = set()
    with open(CSV) as f:
        for row in csv.DictReader(f):
            done_set.add((row['model'], row['dataset'], int(row['seed'])))
    done = len(done_set)
    if done != prev:
        prev = done
        os.system('cls' if os.name == 'nt' else 'clear')
        pct = done * 100 // TOTAL
        bar = '=' * (done * 30 // TOTAL) + '-' * (30 - done * 30 // TOTAL)
        print(f'Phase 2 NC Progress  [{bar}] {done}/{TOTAL} ({pct}%)\n')
        for model in MODELS:
            line = f'{model:>12s} '
            for ds in DATASETS:
                cnt = sum(1 for s in SEEDS if (model, ds, s) in done_set)
                line += f'{ds[:7]:7s}[{"#"*cnt}{"."*(3-cnt)}]  '
            print(line)
        print(f'\nUpdated: {time.strftime("%H:%M:%S")}')
    time.sleep(3)
