"""
Phase 2 NC baseline re-run: TGAT, TGN, GraphMixer node classification.
Outputs to results_nc_phase2.csv and results_nc_phase2_agg.csv.

Usage:
  python run_nc_phase2.py --gpu 0
"""
import argparse
import subprocess
import sys
import os
import re
import csv
import time
import numpy as np
from collections import defaultdict

parser = argparse.ArgumentParser('Phase 2 NC Runner')
parser.add_argument('--gpu', type=int, default=0)
args = parser.parse_args()

MODELS = ['tgat', 'tgn', 'graphmixer']
DATASETS = ['wikipedia', 'reddit', 'mooc', 'uci', 'enron']
SEEDS = [42, 123, 2024]
EPOCHS = 20
BS = 200
LR = 0.0001
N_LAYER = 2

SYNTHETIC_LABEL_DATASETS = {'reddit', 'uci', 'enron'}

SCRIPT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'learn_node.py')
RESULTS_CSV = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'results_nc_phase2.csv')
AGG_CSV = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'results_nc_phase2_agg.csv')

os.makedirs(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'log'), exist_ok=True)


def parse_node_clf_output(stdout):
    result = {}
    match = re.search(
        r'Test statistics: Old nodes -- auc:\s*([\d.]+|nan)\s+ap:\s*([\d.]+|nan)',
        stdout
    )
    if match:
        result['old_auc'] = float(match.group(1)) if match.group(1) != 'nan' else float('nan')
        result['old_ap'] = float(match.group(2)) if match.group(2) != 'nan' else float('nan')
    match = re.search(
        r'Test statistics: New nodes -- auc:\s*([\d.]+|nan)\s+ap:\s*([\d.]+|nan)',
        stdout
    )
    if match:
        result['new_auc'] = float(match.group(1)) if match.group(1) != 'nan' else float('nan')
        result['new_ap'] = float(match.group(2)) if match.group(2) != 'nan' else float('nan')
    # Also parse overall auc/ap/acc from final lines
    for pattern, key in [
        (r'Final train statistics.*?auc:\s*([\d.]+)', 'train_auc'),
        (r'Final train statistics.*?ap:\s*([\d.]+)', 'train_ap'),
        (r'Final train statistics.*?acc:\s*([\d.]+)', 'train_acc'),
    ]:
        m = re.search(pattern, stdout)
        if m and key not in result:
            result[key] = float(m.group(1))
    return result


def run_experiment(model, dataset, seed):
    prefix = f'nc_phase2_{model}_{dataset}_s{seed}'
    cmd = [
        sys.executable, SCRIPT,
        '--model_name', model,
        '--data', dataset,
        '--n_epoch', str(EPOCHS),
        '--bs', str(BS),
        '--n_layer', str(N_LAYER),
        '--lr', str(LR),
        '--prefix', prefix,
        '--seed', str(seed),
        '--gpu', str(args.gpu),
        '--train_encoder',
        '--weighted_bce',
    ]
    if dataset in SYNTHETIC_LABEL_DATASETS:
        label_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'processed', f'ml_{dataset}_node_labels.npy')
        cmd += ['--node_label_path', label_path]

    print(f'\n{"="*60}')
    print(f'[{time.strftime("%H:%M:%S")}] model={model} dataset={dataset} seed={seed}')
    print(f'{"="*60}')

    try:
        result = subprocess.run(
            cmd,
            cwd=os.path.dirname(os.path.abspath(__file__)),
            capture_output=True, text=True, timeout=72000,
        )
        stdout = result.stdout + result.stderr
        # Print last 1500 chars for progress
        tail = stdout[-2000:] if len(stdout) > 2000 else stdout
        print(tail)
        if result.returncode != 0:
            print(f'WARNING: exit code {result.returncode}')

        metrics = parse_node_clf_output(stdout)
        print(f'Parsed metrics: {metrics}')
        return metrics
    except subprocess.TimeoutExpired:
        print(f'TIMEOUT: {model} {dataset} seed={seed}')
        return {}
    except Exception as e:
        print(f'ERROR: {e}')
        return {}


def main():
    all_results = []

    total = len(MODELS) * len(DATASETS) * len(SEEDS)
    idx = 0

    for model in MODELS:
        for dataset in DATASETS:
            for seed in SEEDS:
                idx += 1
                print(f'\n[{idx}/{total}] {model}/{dataset}/s{seed}')
                metrics = run_experiment(model, dataset, seed)
                row = {
                    'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
                    'model': model,
                    'dataset': dataset,
                    'seed': seed,
                    'task': 'node_classification',
                    'epochs': EPOCHS,
                }
                row.update(metrics)
                all_results.append(row)

                # Write incrementally
                if all_results:
                    keys = all_results[0].keys()
                    with open(RESULTS_CSV, 'w', newline='') as f:
                        writer = csv.DictWriter(f, fieldnames=keys)
                        writer.writeheader()
                        writer.writerows(all_results)
                    print(f'  -> {RESULTS_CSV} ({len(all_results)} runs)')

    # Aggregate
    grouped = defaultdict(list)
    for row in all_results:
        key = (row['model'], row['dataset'])
        grouped[key].append(row)

    agg_rows = []
    for (model, dataset), rows in grouped.items():
        agg = {'model': model, 'dataset': dataset, 'task': 'node_classification', 'n_runs': len(rows)}
        metric_names = [k for k in rows[0].keys()
                        if k not in ('timestamp', 'model', 'dataset', 'seed', 'task', 'epochs')]
        for metric in metric_names:
            values = [r[metric] for r in rows if metric in r and r[metric] is not None and not np.isnan(r[metric])]
            if values:
                agg[metric] = f'{np.mean(values):.4f} +/- {np.std(values, ddof=1):.4f}'
            elif any(metric in r and r[metric] is not None and np.isnan(r[metric]) for r in rows):
                agg[metric] = 'nan'
        agg_rows.append(agg)

    if agg_rows:
        keys = agg_rows[0].keys()
        with open(AGG_CSV, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=keys)
            writer.writeheader()
            writer.writerows(agg_rows)
        print(f'\nAggregated results saved to {AGG_CSV}')

        print(f'\n{"="*80}')
        print('Phase 2 NC Aggregated Results')
        print(f'{"="*80}')
        for agg in agg_rows:
            parts = [f'{k}={agg[k]}' for k in agg if k not in ('model', 'dataset', 'task', 'n_runs')]
            print(f'{agg["model"]:12s} {agg["dataset"]:12s} | ' + ' | '.join(parts))
        print(f'{"="*80}')


if __name__ == '__main__':
    main()
