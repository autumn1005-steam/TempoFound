"""
Ablation study: single-dataset vs cross-dataset pre-training.

Runs pre-training with different dataset combinations, then fine-tunes
each checkpoint on all 5 downstream datasets, collecting results into
a comparison table.

Dataset combinations tested:
  single: wikipedia-only, reddit-only, mooc-only
  pair:   wikipedia+reddit (v2), wikipedia+mooc, reddit+mooc
  multi:  wikipedia+reddit+mooc (v3), wikipedia+reddit+uci

Usage:
  python run_ablation_datasets.py

Can take many hours on CPU. Use --quick for a fast test (5 epochs pre-training,
3 epochs fine-tuning).
"""

import argparse
import subprocess
import sys
import os
import re
import csv
import time
import itertools

parser = argparse.ArgumentParser('Ablation Study Runner')
parser.add_argument('--datasets', type=str, nargs='+',
                    default=['wikipedia', 'reddit', 'mooc', 'uci', 'enron'],
                    help='downstream datasets to evaluate on')
parser.add_argument('--pt_epochs', type=int, default=50, help='pre-training epochs')
parser.add_argument('--ft_epochs', type=int, default=20, help='fine-tuning epochs')
parser.add_argument('--bs', type=int, default=512, help='batch size')
parser.add_argument('--shared_dim', type=int, default=256, help='shared dimension')
parser.add_argument('--lr', type=float, default=0.0005, help='learning rate')
parser.add_argument('--gpu', type=int, default=-1)
parser.add_argument('--quick', action='store_true', help='quick test with fewer epochs')
parser.add_argument('--task', type=str, choices=['link_prediction', 'node_classification', 'both'],
                    default='link_prediction')
args = parser.parse_args()

if args.quick:
    args.pt_epochs = 5
    args.ft_epochs = 3

os.makedirs('log', exist_ok=True)
RESULTS_CSV = './results_ablation.csv'

# Pre-training configurations to test
PT_CONFIGS = {
    'W_only': ['wikipedia'],
}

DOWNLOAD_DATASETS = ['wikipedia', 'reddit', 'mooc', 'uci', 'enron']
for ds in DOWNLOAD_DATASETS:
    for name, ds_list in PT_CONFIGS.items():
        for pt_ds in ds_list:
            if pt_ds not in DOWNLOAD_DATASETS:
                print(f'WARNING: {pt_ds} not in known datasets for config {name}')
                continue


def run_pretrain(name, pt_datasets, shared_dim, pt_epochs):
    """Run pre-training. Returns path to saved checkpoint."""
    prefix = f'ablation_{name}'
    saved_path = f'./saved_models/{prefix}_pretrained.pth'
    limit_flag = ['--limit_batches', '50'] if args.quick else []

    cmd = [
        sys.executable, 'pretrain_foundation.py',
        '--datasets'] + pt_datasets + [
        '--epochs', str(pt_epochs),
        '--bs', str(args.bs),
        '--shared_dim', str(shared_dim),
        '--lr', str(args.lr),
        '--gpu', str(args.gpu),
        '--prefix', prefix,
        '--seed', '42',
    ] + limit_flag

    print(f'\n{"="*70}')
    print(f'Pre-training: {name} on {pt_datasets}')
    print(f'Command: {" ".join(cmd)}')
    print(f'{"="*70}')

    result = subprocess.run(cmd, capture_output=True, text=True, timeout=86400)
    if result.returncode != 0:
        print(f'Pre-training FAILED: {name}')
        print(result.stdout[-2000:])
        print(result.stderr[-2000:])
        return None
    print(result.stdout[-500:])
    return saved_path if os.path.exists(saved_path) else None


def parse_ft_output(stdout, task_type):
    """Parse test metrics from fine-tuning output."""
    metrics = {}
    if task_type == 'link_prediction':
        match = re.search(r'Link Prediction.*?AP=([\d.]+)\s+AUC=([\d.]+)\s+Acc=([\d.]+)', stdout)
        if match:
            metrics['AP'] = float(match.group(1))
            metrics['AUC'] = float(match.group(2))
            metrics['Acc'] = float(match.group(3))
    else:
        match = re.search(r'Test statistics: Old nodes -- auc:\s*([\d.]+)\s+ap:\s*([\d.]+)', stdout)
        if match:
            metrics['OldNodeAUC'] = float(match.group(1))
            metrics['OldNodeAP'] = float(match.group(2))
        match = re.search(r'Test statistics: New nodes -- auc:\s*([\d.]+)\s+ap:\s*([\d.]+)', stdout)
        if match:
            metrics['NewNodeAUC'] = float(match.group(1))
            metrics['NewNodeAP'] = float(match.group(2))
    return metrics


def run_finetune(pt_name, pretrained_path, dataset, task_type, ft_epochs):
    """Run fine-tuning on one downstream dataset."""
    prefix = f'ablation_{pt_name}_ft_{dataset}'
    cmd = [
        sys.executable, 'finetune_foundation.py',
        '--task', task_type,
        '--dataset', dataset,
        '--mode', 'full',
        '--pretrained_path', pretrained_path,
        '--epochs', str(ft_epochs),
        '--bs', str(args.bs),
        '--gpu', str(args.gpu),
        '--prefix', prefix,
        '--seed', '42',
    ]
    if task_type == 'node_classification':
        # Add synthetic labels for Reddit/UCI/Enron
        node_label_path = f'./processed/ml_{dataset}_node_labels.npy'
        if os.path.exists(node_label_path):
            cmd += ['--node_label_path', node_label_path]

    print(f'  Fine-tuning: {pt_name} -> {dataset} ({task_type})')

    result = subprocess.run(cmd, capture_output=True, text=True, timeout=36000)
    metrics = parse_ft_output(result.stdout + result.stderr, task_type)
    if not metrics:
        print(f'  WARNING: could not parse metrics for {pt_name} -> {dataset}')
        print(f'  STDOUT tail: {result.stdout[-500:]}')
    return metrics


def main():
    all_rows = []

    for pt_name, pt_datasets in PT_CONFIGS.items():
        print(f'\n{"#"*70}')
        print(f'# Pre-training config: {pt_name} ({pt_datasets})')
        print(f'{"#"*70}')

        # Pre-train
        pt_path = run_pretrain(pt_name, pt_datasets, args.shared_dim, args.pt_epochs)
        if pt_path is None:
            print(f'SKIPPING {pt_name}: pre-training failed.')
            continue

        # Fine-tune on each downstream dataset
        tasks = ['link_prediction', 'node_classification'] if args.task == 'both' else [args.task]
        for task in tasks:
            for ds in args.datasets:
                # Check dataset exists
                if not os.path.exists(f'./processed/ml_{ds}.csv'):
                    print(f'  SKIPPING {ds}: data not found.')
                    continue
                metrics = run_finetune(pt_name, pt_path, ds, task, args.ft_epochs)
                row = {
                    'pt_config': pt_name,
                    'pt_datasets': '+'.join(pt_datasets),
                    'downstream_dataset': ds,
                    'task': task,
                }
                row.update(metrics)
                all_rows.append(row)

                # Write incrementally
                if all_rows:
                    keys = all_rows[0].keys()
                    with open(RESULTS_CSV, 'w', newline='') as f:
                        writer = csv.DictWriter(f, fieldnames=keys)
                        writer.writeheader()
                        writer.writerows(all_rows)
                    print(f'  Progress saved to {RESULTS_CSV}')

    # Print summary table
    print(f'\n{"="*90}')
    print('Ablation Results Summary')
    print(f'{"="*90}')
    for row in all_rows:
        metric_str = ' | '.join(f'{k}={v:.4f}' if isinstance(v, float) else f'{k}={v}'
                                for k, v in row.items() if k not in ('pt_config', 'pt_datasets', 'downstream_dataset', 'task'))
        print(f'{row["pt_config"]:12s} -> {row["downstream_dataset"]:12s} [{row["task"]:20s}] {metric_str}')

    print(f'\nFull results in {RESULTS_CSV}')


if __name__ == '__main__':
    main()
