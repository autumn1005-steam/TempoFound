"""
Multi-seed experiment runner for TGFM baselines.

Runs experiments across (model x dataset x seed) combinations and reports
mean +- std for each metric. Supports both link_prediction and node_classification.

Usage:
  python run_multiseed.py --models tgat tgn graphmixer --datasets wikipedia reddit --seeds 42 123 2024 --task link_prediction --epochs 50
  python run_multiseed.py --models tgat --datasets wikipedia --seeds 42 123 --task node_classification --epochs 15

Output:
  results_multiseed.csv  — per-run raw metrics
  results_multiseed_agg.csv — mean ± std aggregated across seeds
"""

import argparse
import subprocess
import sys
import os
import re
import csv
import time
import numpy as np
from collections import defaultdict


parser = argparse.ArgumentParser('Multi-Seed Experiment Runner')
parser.add_argument('--models', type=str, nargs='+', default=['tgat'],
                    choices=['tgat', 'thycrod', 'tgn', 'graphmixer'])
parser.add_argument('--datasets', type=str, nargs='+',
                    default=['wikipedia', 'reddit', 'mooc', 'uci', 'enron'])
parser.add_argument('--seeds', type=int, nargs='+', default=[42, 123, 2024])
parser.add_argument('--task', type=str, choices=['link_prediction', 'node_classification'],
                    default='link_prediction')
parser.add_argument('--epochs', type=int, default=50)
parser.add_argument('--bs', type=int, default=200)
parser.add_argument('--n_layer', type=int, default=2)
parser.add_argument('--lr', type=float, default=0.0001)
parser.add_argument('--gpu', type=int, default=-1)
parser.add_argument('--prefix', type=str, default='multiseed')
parser.add_argument('--node_label_path', type=str, default='')
args = parser.parse_args()

os.makedirs('log', exist_ok=True)

script_name = 'learn_edge.py' if args.task == 'link_prediction' else 'learn_node.py'

RESULTS_CSV = './results_multiseed.csv'
AGG_CSV = './results_multiseed_agg.csv'


def parse_link_prediction_output(stdout):
    """Parse final test AP/AUC from learn_edge.py output."""
    result = {}
    # Test statistics: Old nodes -- acc: X, auc: Y, ap: Z
    match = re.search(
        r'Test statistics: Old nodes -- acc:\s*([\d.]+),\s*auc:\s*([\d.]+),\s*ap:\s*([\d.]+)',
        stdout
    )
    if match:
        result['old_acc'] = float(match.group(1))
        result['old_auc'] = float(match.group(2))
        result['old_ap'] = float(match.group(3))
    # New nodes
    match = re.search(
        r'Test statistics: New nodes -- acc:\s*([\d.]+),\s*auc:\s*([\d.]+),\s*ap:\s*([\d.]+)',
        stdout
    )
    if match:
        result['new_acc'] = float(match.group(1))
        result['new_auc'] = float(match.group(2))
        result['new_ap'] = float(match.group(3))

    # Fallback: look for the AUC/AP mentioned without old/new split
    if not result:
        for pattern, key in [
            (r'auc:\s*([\d.]+)', 'auc'),
            (r'ap:\s*([\d.]+)', 'ap'),
            (r'acc:\s*([\d.]+)', 'acc'),
        ]:
            matches = re.findall(pattern, stdout, re.IGNORECASE)
            if matches:
                result[key] = float(matches[-1])
    return result


def parse_node_clf_output(stdout):
    """Parse final test AUC/AP from learn_node.py output."""
    result = {}
    match = re.search(
        r'Test statistics: Old nodes -- auc:\s*([\d.]+|nan)\s+ap:\s*([\d.]+|nan)',
        stdout
    )
    if match:
        result['old_auc'] = float(match.group(1)) if match.group(1) != 'nan' else float('nan')
        result['old_ap'] = float(match.group(2)) if match.group(2) != 'nan' else float('nan')
    match = re.search(
        r'Test statistics: New nodes -- auc:\s*([\d.]+|nan)\s+ap:\s*([\d.]+|nan)',
        stdout
    )
    if match:
        result['new_auc'] = float(match.group(1)) if match.group(1) != 'nan' else float('nan')
        result['new_ap'] = float(match.group(2)) if match.group(2) != 'nan' else float('nan')
    # Also parse the final line which has the overall auc/ap/acc
    for pattern, key in [
        (r'auc:\s*([\d.]+)', 'auc'),
        (r'ap:\s*([\d.]+)', 'ap'),
        (r'acc:\s*([\d.]+)', 'acc'),
    ]:
        matches = re.findall(pattern, stdout, re.IGNORECASE)
        if matches and key not in result:
            result[key] = float(matches[-1])
    return result


def run_experiment(model, dataset, seed):
    """Run one experiment and return parsed metrics."""
    prefix = f'{args.prefix}_{model}_{dataset}_s{seed}'
    cmd = [
        sys.executable, script_name,
        '--model_name', model,
        '--data', dataset,
        '--n_epoch', str(args.epochs),
        '--bs', str(args.bs),
        '--n_layer', str(args.n_layer),
        '--lr', str(args.lr),
        '--prefix', prefix,
        '--seed', str(seed),
        '--gpu', str(args.gpu),
    ]
    if args.task == 'node_classification' and args.node_label_path:
        cmd += ['--node_label_path', args.node_label_path]

    print(f'\n{"="*60}')
    print(f'Running: model={model} dataset={dataset} seed={seed}')
    print(f'Command: {" ".join(cmd)}')
    print(f'{"="*60}')

    try:
        result = subprocess.run(
            cmd,
            cwd=os.path.dirname(os.path.abspath(__file__)) or '.',
            capture_output=True, text=True, timeout=72000,  # 20h max
        )
        stdout = result.stdout + result.stderr
        print(result.stdout[-3000:] if len(result.stdout) > 3000 else result.stdout)
        if result.returncode != 0:
            print(f'WARNING: exit code {result.returncode}')

        if args.task == 'link_prediction':
            metrics = parse_link_prediction_output(stdout)
        else:
            metrics = parse_node_clf_output(stdout)

        print(f'Parsed metrics: {metrics}')
        return metrics
    except subprocess.TimeoutExpired:
        print(f'TIMEOUT: {model} {dataset} seed={seed}')
        return {}
    except Exception as e:
        print(f'ERROR: {e}')
        return {}


def main():
    all_results = []

    for model in args.models:
        for dataset in args.datasets:
            for seed in args.seeds:
                metrics = run_experiment(model, dataset, seed)
                row = {
                    'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
                    'model': model,
                    'dataset': dataset,
                    'seed': seed,
                    'task': args.task,
                    'epochs': args.epochs,
                }
                row.update(metrics)
                all_results.append(row)

                # Write incrementally
                if all_results:
                    keys = all_results[0].keys()
                    with open(RESULTS_CSV, 'w', newline='') as f:
                        writer = csv.DictWriter(f, fieldnames=keys)
                        writer.writeheader()
                        writer.writerows(all_results)
                    print(f'Progress saved to {RESULTS_CSV}')

    # Aggregate
    grouped = defaultdict(list)
    for row in all_results:
        key = (row['model'], row['dataset'])
        grouped[key].append(row)

    agg_rows = []
    for (model, dataset), rows in grouped.items():
        agg = {'model': model, 'dataset': dataset, 'task': args.task, 'n_runs': len(rows)}
        metric_names = [k for k in rows[0].keys()
                        if k not in ('timestamp', 'model', 'dataset', 'seed', 'task', 'epochs')]
        for metric in metric_names:
            values = [r[metric] for r in rows if metric in r and r[metric] is not None]
            if values:
                agg[metric] = f'{np.mean(values):.4f} ± {np.std(values, ddof=1):.4f}'
        agg_rows.append(agg)

    if agg_rows:
        keys = agg_rows[0].keys()
        with open(AGG_CSV, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=keys)
            writer.writeheader()
            writer.writerows(agg_rows)
        print(f'\nAggregated results saved to {AGG_CSV}')

        # Print table
        print(f'\n{"="*80}')
        print(f'Aggregated Results ({args.task})')
        print(f'{"="*80}')
        for agg in agg_rows:
            print(f'{agg["model"]:12s} {agg["dataset"]:12s} ' +
                  ' | '.join(f'{k}={agg[k]}' for k in agg if k not in ('model', 'dataset', 'task', 'n_runs')))
        print(f'{"="*80}')


if __name__ == '__main__':
    main()
