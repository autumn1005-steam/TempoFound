"""
TGN: Temporal Graph Networks
Reference: Rossi et al., "Temporal Graph Networks for Deep Learning on Dynamic Graphs", 2020

Extends TGAT with a trainable node memory module.
Reuses TimeEncode, AttnModel, MergeLayer from module.py.
"""

import numpy as np
import torch
import torch.nn as nn

from module import TimeEncode, AttnModel, MergeLayer


class TGNGatedMemory(nn.Module):
    """GRU-based node memory module.

    Stores a d-dimensional memory vector per node, updated whenever the node
    participates in an interaction. The message function combines source/dest
    embeddings, edge features, and time deltas.
    """

    def __init__(self, n_nodes, raw_node_dim, feat_dim, edge_dim, time_dim, memory_dim=None, drop_out=0.1):
        super().__init__()
        self.memory_dim = memory_dim or feat_dim
        self.feat_dim = feat_dim

        self.memory = nn.Embedding(n_nodes, self.memory_dim, padding_idx=0)
        nn.init.zeros_(self.memory.weight)

        message_input_dim = feat_dim * 2 + edge_dim + time_dim
        self.message_fn = nn.Sequential(
            nn.Linear(message_input_dim, self.memory_dim),
            nn.ReLU(),
            nn.Dropout(drop_out),
            nn.Linear(self.memory_dim, self.memory_dim),
        )

        self.memory_updater = nn.GRUCell(self.memory_dim, self.memory_dim)

        self.memory_proj = nn.Linear(self.memory_dim, feat_dim)

        self._last_update_src = None
        self._last_update_dst = None

    def get_memory(self, node_ids):
        """Look up and project memory for given node IDs. Returns [B, feat_dim]."""
        device = self.memory.weight.device
        ids = torch.from_numpy(np.asarray(node_ids, dtype=np.int64)).long().to(device)
        mem = self.memory(ids)
        return self.memory_proj(mem)

    def compute_messages(self, src_emb, dst_emb, edge_feat, time_enc):
        """Compute messages for interaction (src, dst, edge, delta_t).

        All inputs should be [B, D] tensors.
        Returns [B, memory_dim].
        """
        combined = torch.cat([src_emb, dst_emb, edge_feat, time_enc], dim=-1)
        return self.message_fn(combined)

    def update_memory(self, node_ids, messages):
        """Update memory for given nodes with GRU cell (detached, no gradient).

        node_ids: numpy array of node IDs
        messages: [B, memory_dim] tensor
        """
        device = self.memory.weight.device
        ids = torch.from_numpy(np.asarray(node_ids, dtype=np.int64)).long().to(device)
        old_mem = self.memory(ids)
        new_mem = self.memory_updater(messages, old_mem)
        self.memory.weight.data[ids] = new_mem.detach()

    def reset_memory(self):
        nn.init.zeros_(self.memory.weight)


class TGN(nn.Module):
    """TGN model compatible with TGAT's interface (learn_edge.py / learn_node.py).

    Compared to TGAN: adds a GRU-based memory that augments node raw embeddings.
    The temporal convolution (tem_conv) is nearly identical to TGAN except the
    base case adds memory to raw node features.
    """

    def __init__(
        self,
        ngh_finder,
        n_feat,
        e_feat,
        attn_mode='prod',
        use_time='time',
        agg_method='attn',
        node_dim=None,
        time_dim=None,
        num_layers=3,
        n_head=4,
        null_idx=0,
        num_heads=1,
        drop_out=0.1,
        seq_len=None,
        memory_dim=None,
        **kwargs,
    ):
        super().__init__()
        self.num_layers = num_layers
        self.ngh_finder = ngh_finder
        self.null_idx = null_idx

        self.n_feat_th = nn.Parameter(torch.from_numpy(n_feat.astype(np.float32)))
        self.e_feat_th = nn.Parameter(torch.from_numpy(e_feat.astype(np.float32)))
        self.node_raw_embed = nn.Embedding.from_pretrained(self.n_feat_th, padding_idx=0, freeze=True)
        self.edge_raw_embed = nn.Embedding.from_pretrained(self.e_feat_th, padding_idx=0, freeze=True)

        self.feat_dim = self.n_feat_th.shape[1]
        self.n_feat_dim = self.feat_dim
        self.e_feat_dim = self.feat_dim
        self.model_dim = self.feat_dim
        self.use_time = use_time
        self.raw_node_dim = self.feat_dim

        n_nodes = self.n_feat_th.shape[0]
        self.memory_dim = memory_dim or self.feat_dim
        self.memory = TGNGatedMemory(
            n_nodes=n_nodes,
            raw_node_dim=self.feat_dim,
            feat_dim=self.feat_dim,
            edge_dim=self.feat_dim,
            time_dim=self.feat_dim,  # time encoder always expands to feat_dim
            memory_dim=self.memory_dim,
            drop_out=drop_out,
        )

        self.merge_layer = MergeLayer(self.feat_dim, self.feat_dim, self.feat_dim, self.feat_dim)

        if agg_method == 'attn':
            self.attn_model_list = nn.ModuleList([
                AttnModel(self.feat_dim, self.feat_dim, self.feat_dim,
                          attn_mode=attn_mode, n_head=n_head, drop_out=drop_out)
                for _ in range(num_layers)
            ])
        elif agg_method == 'lstm':
            from module import LSTMPool
            self.attn_model_list = nn.ModuleList([
                LSTMPool(self.feat_dim, self.feat_dim, self.feat_dim)
                for _ in range(num_layers)
            ])
        elif agg_method == 'mean':
            from module import MeanPool
            self.attn_model_list = nn.ModuleList([
                MeanPool(self.feat_dim, self.feat_dim) for _ in range(num_layers)
            ])
        else:
            raise ValueError('invalid agg_method')

        if use_time == 'time':
            self.time_encoder = TimeEncode(expand_dim=self.feat_dim)
        elif use_time == 'pos':
            from module import PosEncode
            assert seq_len is not None
            self.time_encoder = PosEncode(expand_dim=self.feat_dim, seq_len=seq_len)
        elif use_time == 'empty':
            from module import EmptyEncode
            self.time_encoder = EmptyEncode(expand_dim=self.feat_dim)
        else:
            raise ValueError('invalid time option')

        self.affinity_score = MergeLayer(self.feat_dim, self.feat_dim, self.feat_dim, 1)

    def get_base_features(self, node_ids):
        """Raw features + memory projection for nodes. Returns [B, feat_dim]."""
        raw_feat = self.node_raw_embed(
            torch.from_numpy(np.asarray(node_ids, dtype=np.int64)).long().to(self.n_feat_th.device)
        )
        mem_feat = self.memory.get_memory(node_ids)
        return raw_feat + mem_feat

    def forward(self, src_idx_l, target_idx_l, cut_time_l, num_neighbors=20):
        src_embed = self.tem_conv(src_idx_l, cut_time_l, self.num_layers, num_neighbors)
        target_embed = self.tem_conv(target_idx_l, cut_time_l, self.num_layers, num_neighbors)
        score = self.affinity_score(src_embed, target_embed).squeeze(dim=-1)
        return score

    def contrast(self, src_idx_l, target_idx_l, background_idx_l, cut_time_l, num_neighbors=20):
        src_embed = self.tem_conv(src_idx_l, cut_time_l, self.num_layers, num_neighbors)
        target_embed = self.tem_conv(target_idx_l, cut_time_l, self.num_layers, num_neighbors)
        background_embed = self.tem_conv(background_idx_l, cut_time_l, self.num_layers, num_neighbors)
        pos_score = self.affinity_score(src_embed, target_embed).squeeze(dim=-1)
        neg_score = self.affinity_score(src_embed, background_embed).squeeze(dim=-1)
        return pos_score.sigmoid(), neg_score.sigmoid()

    def tem_conv(self, src_idx_l, cut_time_l, curr_layers, num_neighbors=20):
        """Recursive temporal convolution — identical to TGAN except base case adds memory."""
        assert curr_layers >= 0

        device = self.n_feat_th.device
        batch_size = len(src_idx_l)

        src_node_batch_th = torch.from_numpy(np.asarray(src_idx_l, dtype=np.int64)).long().to(device)
        cut_time_l_th = torch.from_numpy(np.asarray(cut_time_l, dtype=np.float32)).float().to(device)

        cut_time_l_th = torch.unsqueeze(cut_time_l_th, dim=1)
        src_node_t_embed = self.time_encoder(torch.zeros_like(cut_time_l_th))

        if curr_layers == 0:
            # Base case: raw features + memory
            return self.get_base_features(src_idx_l)

        src_node_conv_feat = self.tem_conv(
            src_idx_l, cut_time_l,
            curr_layers=curr_layers - 1,
            num_neighbors=num_neighbors,
        )

        src_ngh_node_batch, src_ngh_eidx_batch, src_ngh_t_batch = self.ngh_finder.get_temporal_neighbor(
            src_idx_l, cut_time_l, num_neighbors=num_neighbors,
        )

        src_ngh_node_batch_th = torch.from_numpy(src_ngh_node_batch).long().to(device)
        src_ngh_eidx_batch = torch.from_numpy(src_ngh_eidx_batch).long().to(device)

        src_ngh_t_batch_delta = np.asarray(cut_time_l, dtype=np.float32)[:, np.newaxis] - src_ngh_t_batch
        src_ngh_t_batch_th = torch.from_numpy(src_ngh_t_batch_delta).float().to(device)

        src_ngh_node_batch_flat = src_ngh_node_batch.flatten()
        src_ngh_t_batch_flat = src_ngh_t_batch.flatten()

        src_ngh_node_conv_feat = self.tem_conv(
            src_ngh_node_batch_flat, src_ngh_t_batch_flat,
            curr_layers=curr_layers - 1,
            num_neighbors=num_neighbors,
        )
        src_ngh_feat = src_ngh_node_conv_feat.view(batch_size, num_neighbors, -1)

        src_ngh_t_embed = self.time_encoder(src_ngh_t_batch_th)
        src_ngn_edge_feat = self.edge_raw_embed(src_ngh_eidx_batch)

        mask = src_ngh_node_batch_th == 0
        attn_m = self.attn_model_list[curr_layers - 1]

        local, weight = attn_m(
            src_node_conv_feat, src_node_t_embed,
            src_ngh_feat, src_ngh_t_embed, src_ngn_edge_feat, mask,
        )
        return local

    def update_memory_batch(self, src_idx_l, dst_idx_l, cut_time_l, e_idx_l, num_neighbors=20):
        """Update node memory after a training batch using raw features (fast path)."""
        device = self.n_feat_th.device
        with torch.no_grad():
            src_ids = np.asarray(src_idx_l, dtype=np.int64)
            dst_ids = np.asarray(dst_idx_l, dtype=np.int64)
            e_ids = np.asarray(e_idx_l, dtype=np.int64)

            src_feat = self.node_raw_embed(torch.from_numpy(src_ids).long().to(device))
            dst_feat = self.node_raw_embed(torch.from_numpy(dst_ids).long().to(device))
            edge_feat = self.edge_raw_embed(torch.from_numpy(e_ids).long().to(device))

            delta_t = torch.zeros(len(src_idx_l), 1, device=device)
            time_enc = self.time_encoder(delta_t).squeeze(1)

            msg_src = self.memory.compute_messages(src_feat, dst_feat, edge_feat, time_enc)
            msg_dst = self.memory.compute_messages(dst_feat, src_feat, edge_feat, time_enc)

            self.memory.update_memory(src_ids, msg_src)
            self.memory.update_memory(dst_ids, msg_dst)

    def prewarm_memory(self, train_src_l, train_dst_l, train_ts_l, train_e_idx_l, batch_size=512):
        """Initialize memory by processing all training edges in chronological order."""
        device = self.n_feat_th.device
        order = np.argsort(train_ts_l)
        num_edges = len(order)
        for k in range(0, num_edges, batch_size):
            idx = order[k:k + batch_size]
            self.update_memory_batch(
                train_src_l[idx], train_dst_l[idx],
                train_ts_l[idx], train_e_idx_l[idx],
            )
