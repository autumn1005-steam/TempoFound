"""
GraphMixer: Do We Really Need Complicated Model Architectures For Temporal Networks?
Reference: Cong et al., ICLR 2023

Architecture: fixed time encoding + MLP-Mixer blocks + mean-pooling.
No learned attention, no recurrent memory — simple and fast baseline.
"""

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


class FixedTimeEncode(nn.Module):
    """Non-learnable sinusoidal time encoding with fixed random frequencies."""

    def __init__(self, time_dim, sigma=1.0):
        super().__init__()
        weights = torch.randn(time_dim) * sigma
        self.register_buffer('frequencies', weights)

    def forward(self, delta_t):
        """delta_t: [B, N] time deltas, returns [B, N, time_dim]."""
        delta_t = delta_t.unsqueeze(-1)
        enc = torch.cos(delta_t * self.frequencies.view(1, 1, -1))
        return enc


class MLPMixerBlock(nn.Module):
    """One MLP-Mixer block: token mixing across neighbors + channel mixing across features.

    Pre-norm style: LayerNorm before each MLP, residual connections after.
    """

    def __init__(self, num_tokens, num_channels, token_mlp_dim=None, channel_mlp_dim=None, drop_out=0.1):
        super().__init__()
        token_dim = token_mlp_dim or num_tokens * 2
        channel_dim = channel_mlp_dim or num_channels * 2

        self.token_norm = nn.LayerNorm(num_channels)
        self.token_mlp = nn.Sequential(
            nn.Linear(num_tokens, token_dim),
            nn.GELU(),
            nn.Dropout(drop_out),
            nn.Linear(token_dim, num_tokens),
        )

        self.channel_norm = nn.LayerNorm(num_channels)
        self.channel_mlp = nn.Sequential(
            nn.Linear(num_channels, channel_dim),
            nn.GELU(),
            nn.Dropout(drop_out),
            nn.Linear(channel_dim, num_channels),
        )

    def forward(self, x):
        # x: [B, N, D] where N = num_tokens (neighbors), D = num_channels (features)
        # Token mixing: transpose to [B, D, N], mix across N, transpose back
        residual = x
        x = self.token_norm(x)
        x = x.transpose(1, 2)  # [B, D, N]
        x = self.token_mlp(x)  # [B, D, N]
        x = x.transpose(1, 2)  # [B, N, D]
        x = x + residual

        # Channel mixing
        residual = x
        x = self.channel_norm(x)
        x = self.channel_mlp(x)  # [B, N, D]
        x = x + residual
        return x


class GraphMixerLinkEncoder(nn.Module):
    """Encode a node's temporal context: N recent neighbors → single embedding."""

    def __init__(self, raw_node_dim, raw_edge_dim, time_dim, hidden_dim,
                 num_neighbors, num_mixer_layers=2, drop_out=0.1):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.num_neighbors = num_neighbors
        self.raw_node_dim = raw_node_dim
        self.raw_edge_dim = raw_edge_dim

        self.time_encoder = FixedTimeEncode(time_dim)
        input_dim = raw_node_dim + raw_edge_dim + time_dim
        self.input_project = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(drop_out),
        )

        self.mixer_blocks = nn.ModuleList([
            MLPMixerBlock(num_neighbors, hidden_dim, drop_out=drop_out)
            for _ in range(num_mixer_layers)
        ])

        self.output_norm = nn.LayerNorm(hidden_dim)

    def forward(self, neighbor_nodes, neighbor_edges, neighbor_delta_t,
                node_raw_embed_fn, edge_raw_embed_fn):
        """Encode a batch of nodes given their temporal neighbors.

        Args:
            neighbor_nodes: [B, N] node IDs
            neighbor_edges: [B, N] edge IDs
            neighbor_delta_t: [B, N] time deltas (cut_time - ngh_time)
            node_raw_embed_fn: fn(ids) -> [B, N, raw_node_dim]
            edge_raw_embed_fn: fn(ids) -> [B, N, raw_edge_dim]

        Returns: [B, hidden_dim]
        """
        B, N = neighbor_nodes.shape

        node_feat = node_raw_embed_fn(neighbor_nodes)      # [B, N, raw_node_dim]
        edge_feat = edge_raw_embed_fn(neighbor_edges)       # [B, N, raw_edge_dim]
        time_enc = self.time_encoder(neighbor_delta_t)       # [B, N, time_dim]

        combined = torch.cat([node_feat, edge_feat, time_enc], dim=-1)  # [B, N, input_dim]
        x = self.input_project(combined)  # [B, N, hidden_dim]

        for block in self.mixer_blocks:
            x = block(x)

        x = self.output_norm(x)
        return x.mean(dim=1)  # [B, hidden_dim]


class GraphMixerLinkDecoder(nn.Module):
    """Score a (src, dst) pair for link prediction."""

    def __init__(self, hidden_dim, drop_out=0.1):
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Dropout(drop_out),
            nn.Linear(hidden_dim, 1),
        )

    def forward(self, src_emb, dst_emb):
        return self.mlp(torch.cat([src_emb, dst_emb], dim=-1)).squeeze(-1)


class GraphMixer(nn.Module):
    """GraphMixer model compatible with learn_edge.py / learn_node.py data pipeline.

    Uses NeighborFinder for temporal neighbor sampling (no recursive convolution).
    Raw node/edge embeddings are frozen (loaded from preprocessed data).
    """

    def __init__(
        self,
        ngh_finder,
        n_feat,
        e_feat,
        attn_mode='prod',
        use_time='time',
        agg_method='attn',
        node_dim=None,
        time_dim=None,
        num_layers=2,
        n_head=2,
        null_idx=0,
        num_heads=1,
        drop_out=0.1,
        seq_len=None,
        num_neighbors=None,
        num_mixer_layers=None,
        **kwargs,
    ):
        super().__init__()
        self.ngh_finder = ngh_finder
        self.null_idx = null_idx

        self.n_feat_th = nn.Parameter(torch.from_numpy(n_feat.astype(np.float32)))
        self.e_feat_th = nn.Parameter(torch.from_numpy(e_feat.astype(np.float32)))
        self.node_raw_embed = nn.Embedding.from_pretrained(self.n_feat_th, padding_idx=0, freeze=True)
        self.edge_raw_embed = nn.Embedding.from_pretrained(self.e_feat_th, padding_idx=0, freeze=True)

        self.raw_node_dim = self.n_feat_th.shape[1]
        self.raw_edge_dim = self.e_feat_th.shape[1]
        self.feat_dim = node_dim or self.raw_node_dim
        self.n_feat_dim = self.feat_dim
        self.e_feat_dim = self.raw_edge_dim
        self.time_dim = time_dim or self.feat_dim
        self.num_neighbors = num_neighbors or seq_len or 20
        self.num_mixer_layers = num_mixer_layers or num_layers

        self.link_encoder = GraphMixerLinkEncoder(
            raw_node_dim=self.raw_node_dim,
            raw_edge_dim=self.raw_edge_dim,
            time_dim=self.time_dim,
            hidden_dim=self.feat_dim,
            num_neighbors=self.num_neighbors,
            num_mixer_layers=self.num_mixer_layers,
            drop_out=drop_out,
        )
        self.link_decoder = GraphMixerLinkDecoder(self.feat_dim, drop_out=drop_out)

    def _raw_node_fn(self, node_ids):
        """Resolve node IDs → raw features [B, N, raw_node_dim]."""
        device = self.n_feat_th.device
        ids = torch.from_numpy(node_ids.astype(np.int64)).long().to(device)
        return self.node_raw_embed(ids)

    def _raw_edge_fn(self, edge_ids):
        """Resolve edge IDs → raw features [B, N, raw_edge_dim]."""
        device = self.n_feat_th.device
        ids = torch.from_numpy(edge_ids.astype(np.int64)).long().to(device)
        return self.edge_raw_embed(ids)

    def encode_node(self, src_idx_l, cut_time_l, num_neighbors=None):
        """Get temporal embedding for a batch of nodes."""
        if num_neighbors is None:
            num_neighbors = self.num_neighbors

        device = self.n_feat_th.device
        batch_size = len(src_idx_l)

        ngh_node_batch, ngh_eidx_batch, ngh_t_batch = self.ngh_finder.get_temporal_neighbor(
            src_idx_l, cut_time_l, num_neighbors=num_neighbors
        )

        cut_time_np = np.asarray(cut_time_l, dtype=np.float32)
        delta_t = cut_time_np[:, np.newaxis] - ngh_t_batch
        delta_t = np.maximum(delta_t, 0.0)
        delta_t = torch.from_numpy(delta_t).float().to(device)

        return self.link_encoder(
            ngh_node_batch, ngh_eidx_batch, delta_t,
            self._raw_node_fn, self._raw_edge_fn
        )

    def tem_conv(self, src_idx_l, cut_time_l, curr_layers, num_neighbors=None):
        """Single-hop encoding for node classification compatibility."""
        return self.encode_node(src_idx_l, cut_time_l, num_neighbors)

    def forward(self, src_idx_l, target_idx_l, cut_time_l, num_neighbors=None):
        """Link prediction score."""
        src_emb = self.encode_node(src_idx_l, cut_time_l, num_neighbors)
        dst_emb = self.encode_node(target_idx_l, cut_time_l, num_neighbors)
        return self.link_decoder(src_emb, dst_emb)

    def contrast(self, src_idx_l, target_idx_l, background_idx_l, cut_time_l, num_neighbors=None):
        """Return positive and negative scores for evaluation."""
        src_emb = self.encode_node(src_idx_l, cut_time_l, num_neighbors)
        pos_emb = self.encode_node(target_idx_l, cut_time_l, num_neighbors)
        neg_emb = self.encode_node(background_idx_l, cut_time_l, num_neighbors)
        pos_score = self.link_decoder(src_emb, pos_emb).sigmoid()
        neg_score = self.link_decoder(src_emb, neg_emb).sigmoid()
        return pos_score, neg_score
