import math

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from module import AttnModel


class _TimeEncode(nn.Module):
    """TGAT-style harmonic time encoding."""

    def __init__(self, expand_dim):
        super().__init__()
        basis = 1 / 10 ** np.linspace(0, 9, expand_dim)
        self.basis_freq = nn.Parameter(torch.from_numpy(basis).float())
        self.phase = nn.Parameter(torch.zeros(expand_dim).float())

    def forward(self, ts):
        batch_size = ts.size(0)
        seq_len = ts.size(1)
        ts = ts.view(batch_size, seq_len, 1)
        map_ts = ts * self.basis_freq.view(1, 1, -1)
        map_ts = map_ts + self.phase.view(1, 1, -1)
        return torch.cos(map_ts)


class _MergeLayer(nn.Module):
    def __init__(self, dim1, dim2, hidden_dim, out_dim):
        super().__init__()
        self.fc1 = nn.Linear(dim1 + dim2, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, out_dim)
        self.act = nn.ReLU()
        nn.init.xavier_normal_(self.fc1.weight)
        nn.init.xavier_normal_(self.fc2.weight)

    def forward(self, x1, x2):
        h = self.act(self.fc1(torch.cat([x1, x2], dim=1)))
        return self.fc2(h)


class HyperDiffBranch(nn.Module):
    """Lightweight tangent-space diffusion transform for HyperDiff View C."""

    def __init__(self, hidden_dim, drop_out=0.1):
        super().__init__()
        self.diffusion = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(drop_out),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.smoothing_gate = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.Sigmoid(),
        )

    def forward(self, tangent_z):
        diffused = self.diffusion(tangent_z)
        gate = self.smoothing_gate(torch.cat([tangent_z, diffused], dim=1))
        return tangent_z + gate * diffused


class T_HyCroD(nn.Module):
    """TGAT-compatible Temporal Hyperbolic Contrastive Diffusion encoder.

    The class keeps the original TGAT data path intact: it consumes numpy node
    id/time batches, queries NeighborFinder for historical neighbors before the
    query time, and returns fixed-size dynamic node representations.
    """

    def __init__(
        self,
        ngh_finder,
        n_feat,
        e_feat,
        attn_mode="prod",
        use_time="time",
        agg_method="attn",
        node_dim=None,
        hidden_dim=None,
        time_dim=None,
        num_layers=2,
        n_head=2,
        null_idx=0,
        num_heads=1,
        drop_out=0.1,
        seq_len=None,
        curvature=1.0,
        diffusion_steps=2,
        contrast_temperature=0.2,
        tau=None,
        lambda_dyn=1.0,
        lambda_hyp=1.0,
        use_contrastive=True,
        include_bc_loss=False,
        max_contrastive_batch_size=1024,
        view_b_edge_dropout=0.1,
        view_b_feature_mask=0.1,
        view_b_time_zero=0.1,
        use_hyperdiff=True,
        use_hyperbolic=True,
        use_view_b=True,
        use_historical_context=True,
    ):
        super().__init__()
        del attn_mode, n_head, num_heads, seq_len

        self.ngh_finder = ngh_finder
        self.null_idx = null_idx
        self.num_layers = num_layers
        self.use_time = use_time
        self.use_hyperbolic = bool(use_hyperbolic)
        self.diffusion_steps = max(1, int(diffusion_steps))
        self.contrast_temperature = float(tau if tau is not None else contrast_temperature)
        self.lambda_dyn = float(lambda_dyn)
        self.lambda_hyp = float(lambda_hyp)
        self.use_contrastive = bool(use_contrastive)
        self.include_bc_loss = bool(include_bc_loss)
        self.max_contrastive_batch_size = int(max_contrastive_batch_size)
        self.view_b_edge_dropout = float(view_b_edge_dropout)
        self.view_b_feature_mask = float(view_b_feature_mask)
        self.view_b_time_zero = float(view_b_time_zero)
        self.use_hyperdiff = bool(use_hyperdiff)
        self.use_view_b = bool(use_view_b)
        self.use_historical_context = bool(use_historical_context)
        self.hyper_agg_method = "mean" if agg_method == "mean" else "attn"

        self.n_feat_th = nn.Parameter(torch.from_numpy(n_feat.astype(np.float32)))
        self.e_feat_th = nn.Parameter(torch.from_numpy(e_feat.astype(np.float32)))
        self.node_raw_embed = nn.Embedding.from_pretrained(self.n_feat_th, padding_idx=0, freeze=True)
        self.edge_raw_embed = nn.Embedding.from_pretrained(self.e_feat_th, padding_idx=0, freeze=True)

        self.raw_node_dim = self.n_feat_th.shape[1]
        self.raw_edge_dim = self.e_feat_th.shape[1]
        self.feat_dim = int(hidden_dim or node_dim or self.raw_node_dim)
        self.n_feat_dim = self.feat_dim
        self.e_feat_dim = self.raw_edge_dim
        self.time_dim = time_dim or self.feat_dim
        self.model_dim = self.feat_dim
        self.c = float(curvature)

        if use_time == "time":
            self.time_encoder = _TimeEncode(self.time_dim)
        elif use_time == "empty":
            self.time_encoder = None
        else:
            raise ValueError("T_HyCroD currently supports use_time='time' or 'empty'.")

        self.node_id_embed = nn.Embedding(self.n_feat_th.shape[0], self.feat_dim, padding_idx=0)
        self.node_project = nn.Sequential(
            nn.Linear(self.raw_node_dim, self.feat_dim),
            nn.ReLU(),
            nn.Dropout(drop_out),
            nn.Linear(self.feat_dim, self.feat_dim),
        )
        self.query_tangent = nn.Linear(self.feat_dim, self.feat_dim)
        self.neighbor_tangent = nn.Linear(self.feat_dim, self.feat_dim)
        self.edge_project = nn.Linear(self.e_feat_dim, self.feat_dim)
        self.time_project = nn.Linear(self.time_dim, self.feat_dim)
        self.message_fusion = nn.Sequential(
            nn.Linear(self.feat_dim * 3, self.feat_dim),
            nn.ReLU(),
            nn.Dropout(drop_out),
            nn.Linear(self.feat_dim, self.feat_dim),
        )
        self.view_gate = nn.Sequential(
            nn.Linear(self.feat_dim * 4, self.feat_dim),
            nn.ReLU(),
            nn.Dropout(drop_out),
            nn.Linear(self.feat_dim, 3),
        )
        self.structural_attn = nn.Sequential(
            nn.Linear(self.feat_dim * 4, self.feat_dim),
            nn.ReLU(),
            nn.Linear(self.feat_dim, 1),
        )
        self.hyperbolic_output = nn.Sequential(
            nn.Linear(self.feat_dim * 2, self.feat_dim),
            nn.ReLU(),
            nn.Dropout(drop_out),
            nn.Linear(self.feat_dim, self.feat_dim),
        )
        self.tgat_attn_model_list = nn.ModuleList(
            [AttnModel(self.feat_dim, self.feat_dim, self.feat_dim, attn_mode="prod", n_head=2, drop_out=drop_out)
             for _ in range(num_layers)]
        )
        self.hyperdiff_branch = HyperDiffBranch(self.feat_dim, drop_out=drop_out)
        self.output_norm = nn.LayerNorm(self.feat_dim)
        self.link_scorer = nn.Sequential(
            nn.Linear(self.feat_dim * 4 + 1, self.feat_dim),
            nn.ReLU(),
            nn.Dropout(drop_out),
            nn.Linear(self.feat_dim, 1),
        )
        self.link_distance_scale = nn.Parameter(torch.zeros(1))
        self.link_distance_bias = nn.Parameter(torch.zeros(1))
        self.affinity_score = _MergeLayer(self.feat_dim, self.feat_dim, self.feat_dim, 1)
        self.node_classifier = nn.Sequential(
            nn.Linear(self.feat_dim * 2, self.feat_dim),
            nn.ReLU(),
            nn.Dropout(drop_out),
            nn.Linear(self.feat_dim, 1),
        )

    def get_temporal_embedding(
        self,
        src_idx_l,
        dst_idx_l,
        cut_time_l,
        edge_idx_l=None,
        num_neighbors=20,
    ):
        del edge_idx_l
        src_emb = self.tem_conv(src_idx_l, cut_time_l, self.num_layers, num_neighbors)
        dst_emb = self.tem_conv(dst_idx_l, cut_time_l, self.num_layers, num_neighbors)
        return src_emb, dst_emb

    def forward(self, src_idx_l, target_idx_l, cut_time_l, num_neighbors=20):
        src_emb, dst_emb = self.get_temporal_embedding(
            src_idx_l, target_idx_l, cut_time_l, num_neighbors=num_neighbors
        )
        return self.score_link(src_emb, dst_emb)

    def contrast(
        self,
        src_idx_l,
        dst_idx_l,
        neg_dst_idx_l,
        cut_time_l,
        edge_idx_l=None,
        num_neighbors=20,
        return_loss=False,
    ):
        if isinstance(edge_idx_l, (int, np.integer)):
            num_neighbors = int(edge_idx_l)
            edge_idx_l = None

        src_emb = self.tem_conv(src_idx_l, cut_time_l, self.num_layers, num_neighbors)
        dst_emb = self.tem_conv(dst_idx_l, cut_time_l, self.num_layers, num_neighbors)
        neg_emb = self.tem_conv(neg_dst_idx_l, cut_time_l, self.num_layers, num_neighbors)

        pos_score = self.score_link(src_emb, dst_emb).sigmoid()
        neg_score = self.score_link(src_emb, neg_emb).sigmoid()

        if not return_loss:
            return pos_score, neg_score

        loss_dict = {
            "src_dst_nce": self._pair_nce(src_emb, dst_emb, neg_emb),
            "src_dst_hyp_distance": self._hyp_distance_loss(src_emb, dst_emb, neg_emb),
        }
        z_a, z_b, z_c = self.get_dynamic_view_embeddings(
            src_idx_l,
            cut_time_l,
            num_neighbors=num_neighbors,
            curr_layers=self.num_layers,
            training=self.training,
            return_hyperdiff=True,
        )
        loss_dict.update(self.compute_contrastive_loss(z_a, z_b, z_c))
        return pos_score, neg_score, loss_dict

    def score_link(self, src_emb, dst_emb):
        src_tangent = self._contrast_tangent(src_emb)
        dst_tangent = self._contrast_tangent(dst_emb)
        pair_feat = torch.cat(
            [
                src_tangent,
                dst_tangent,
                torch.abs(src_tangent - dst_tangent),
                src_tangent * dst_tangent,
                torch.log1p(self._sqdist(self._expmap0(src_tangent), self._expmap0(dst_tangent))).unsqueeze(1),
            ],
            dim=1,
        )
        hyp_dist = pair_feat[:, -1]
        mlp_score = self.link_scorer(pair_feat).squeeze(dim=-1)
        return mlp_score - self.link_distance_scale.abs() * hyp_dist + self.link_distance_bias

    def node_classification(
        self,
        src_idx_l,
        dst_idx_l,
        cut_time_l,
        edge_idx_l=None,
        num_neighbors=20,
        return_prob=False,
    ):
        src_emb, dst_emb = self.get_temporal_embedding(
            src_idx_l, dst_idx_l, cut_time_l, edge_idx_l=edge_idx_l, num_neighbors=num_neighbors
        )
        logits = self.node_classifier(torch.cat([src_emb, dst_emb], dim=1)).squeeze(dim=-1)
        if return_prob:
            return logits.sigmoid()
        return logits

    def temporal_node_stats(self, node_idx_l, cut_time_l, num_neighbors=20):
        view = self.sample_view_A(node_idx_l, cut_time_l, num_neighbors)
        valid = view["valid_mask"].float()
        delta = torch.clamp(view["delta_t"], min=0.0) * valid
        count = valid.sum(dim=1)
        safe_count = count.clamp_min(1.0)
        large_delta = torch.where(valid.bool(), delta, torch.full_like(delta, 1e10))
        min_delta = large_delta.min(dim=1).values
        min_delta = torch.where(count > 0, min_delta, torch.zeros_like(min_delta))
        mean_delta = delta.sum(dim=1) / safe_count
        max_delta = delta.max(dim=1).values
        density = count / max(float(num_neighbors), 1.0)
        return torch.stack(
            [
                torch.log1p(count),
                torch.log1p(min_delta),
                torch.log1p(mean_delta),
                torch.log1p(max_delta),
                density,
            ],
            dim=1,
        )

    def tem_conv(self, src_idx_l, cut_time_l, curr_layers=None, num_neighbors=20):
        if curr_layers is None:
            curr_layers = self.num_layers
        if curr_layers <= 0:
            return self._base_node_embedding(src_idx_l)

        src_idx_l = self._as_numpy(src_idx_l, np.int64)
        cut_time_l = self._as_numpy(cut_time_l, np.float32)
        device = self.n_feat_th.device

        src_embed = self.tem_conv(src_idx_l, cut_time_l, curr_layers - 1, num_neighbors)
        z_a, z_b, z_c = self.get_dynamic_view_embeddings(
            src_idx_l,
            cut_time_l,
            num_neighbors=num_neighbors,
            curr_layers=curr_layers,
            base_embed=src_embed,
            training=self.training,
            return_hyperdiff=True,
        )
        query_tangent = self.query_tangent(src_embed)

        gate_input = torch.cat([query_tangent, z_a, z_b, z_c], dim=1)
        view_weight = torch.softmax(self.view_gate(gate_input), dim=1)
        out = view_weight[:, 0:1] * z_a + view_weight[:, 1:2] * z_b + view_weight[:, 2:3] * z_c
        return self.output_norm(out + query_tangent)

    def get_dynamic_view_embeddings(
        self,
        node_idx_l,
        cut_time_l,
        num_neighbors=20,
        curr_layers=None,
        base_embed=None,
        training=None,
        return_hyperdiff=False,
    ):
        """Return hyperbolic dynamic embeddings for a node-time batch."""

        if curr_layers is None:
            curr_layers = self.num_layers
        if training is None:
            training = self.training

        node_idx_l = self._as_numpy(node_idx_l, np.int64)
        cut_time_l = self._as_numpy(cut_time_l, np.float32)
        if base_embed is None:
            base_embed = self.tem_conv(node_idx_l, cut_time_l, curr_layers - 1, num_neighbors)

        view_a = self.sample_view_A(node_idx_l, cut_time_l, num_neighbors)
        if self.use_view_b:
            view_b = self.sample_view_B(node_idx_l, cut_time_l, num_neighbors, training=training)
        else:
            view_b = self._clone_view(view_a)
        z_a = self.encode_hyperbolic_view(base_embed, view_a, curr_layers - 1, num_neighbors)
        z_b = self.encode_hyperbolic_view(base_embed, view_b, curr_layers - 1, num_neighbors)
        if return_hyperdiff:
            z_c = self.hyperdiff_view(z_a)
            return z_a, z_b, z_c
        return z_a, z_b

    def hyperdiff_view(self, z_a):
        """Derive HyperDiff View C from View A's dynamic representation."""

        if not self.use_hyperdiff:
            return z_a

        z_a_hyp = self._expmap0(z_a)
        tangent_z = self._logmap0(z_a_hyp)
        diffused_tangent = self.hyperdiff_branch(tangent_z)
        z_c_hyp = self._expmap0(diffused_tangent)
        return self._logmap0(z_c_hyp)

    def hyperdiff_contrast_loss(self, z_a, z_c):
        """A-C contrastive loss helper for downstream training integration."""

        return self.compute_contrastive_loss(z_a, z_a, z_c)["loss_hyp"]

    def compute_contrastive_loss(
        self,
        z_a,
        z_b,
        z_c,
        tau=None,
        lambda_dyn=None,
        lambda_hyp=None,
        include_bc=None,
        enabled=None,
    ):
        """Compute multi-view contrastive losses for A-B and A-C views."""

        if enabled is None:
            enabled = self.use_contrastive
        if lambda_dyn is None:
            lambda_dyn = self.lambda_dyn
        if lambda_hyp is None:
            lambda_hyp = self.lambda_hyp
        if include_bc is None:
            include_bc = self.include_bc_loss

        zero = z_a.new_tensor(0.0)
        if not enabled:
            return {
                "loss_dyn": zero,
                "loss_hyp": zero,
                "loss_contrast": zero,
            }

        z_a, z_b, z_c = self._contrastive_subset(z_a, z_b, z_c)
        loss_dyn = self._cosine_infonce_loss(z_a, z_b, tau=tau)
        if self.use_hyperdiff:
            loss_hyp = self._hyperbolic_infonce_loss(z_a, z_c, tau=tau)
        else:
            loss_hyp = zero

        loss_contrast = float(lambda_dyn) * loss_dyn + float(lambda_hyp) * loss_hyp
        loss_dict = {
            "loss_dyn": loss_dyn,
            "loss_hyp": loss_hyp,
            "loss_contrast": loss_contrast,
        }

        if include_bc:
            loss_bc = self._cosine_infonce_loss(z_b, z_c, tau=tau)
            loss_dict["loss_bc"] = loss_bc
            loss_dict["loss_contrast"] = loss_dict["loss_contrast"] + loss_bc

        return loss_dict

    def contrastive_loss_for_batch(
        self,
        node_idx_l,
        cut_time_l,
        num_neighbors=20,
        curr_layers=None,
        tau=None,
        lambda_dyn=None,
        lambda_hyp=None,
        enabled=None,
    ):
        """Sample A/B/C views for a node-time batch and return contrastive loss dict."""

        z_a, z_b, z_c = self.get_dynamic_view_embeddings(
            node_idx_l,
            cut_time_l,
            num_neighbors=num_neighbors,
            curr_layers=curr_layers,
            training=self.training,
            return_hyperdiff=True,
        )
        return self.compute_contrastive_loss(
            z_a,
            z_b,
            z_c,
            tau=tau,
            lambda_dyn=lambda_dyn,
            lambda_hyp=lambda_hyp,
            enabled=enabled,
        )

    def _contrastive_subset(self, z_a, z_b, z_c):
        max_size = self.max_contrastive_batch_size
        batch_size = z_a.size(0)
        if max_size <= 0 or batch_size <= max_size:
            return z_a, z_b, z_c
        if self.training:
            idx = torch.randperm(batch_size, device=z_a.device)[:max_size]
        else:
            idx = torch.arange(max_size, device=z_a.device)
        return z_a[idx], z_b[idx], z_c[idx]

    def format_loss_log(self, task_loss, loss_dict):
        """Return a compact training-log string for task and contrastive losses."""

        loss_dyn = loss_dict.get("loss_dyn", task_loss.new_tensor(0.0))
        loss_hyp = loss_dict.get("loss_hyp", task_loss.new_tensor(0.0))
        loss_contrast = loss_dict.get("loss_contrast", task_loss.new_tensor(0.0))
        total_loss = task_loss + loss_contrast
        return (
            f"task_loss: {task_loss.item():.6f}, "
            f"loss_dyn: {loss_dyn.item():.6f}, "
            f"loss_hyp: {loss_hyp.item():.6f}, "
            f"total_loss: {total_loss.item():.6f}"
        )

    def _cosine_infonce_loss(self, z_left, z_right, tau=None):
        tau = self._resolve_tau(tau)
        left = F.normalize(self._contrast_tangent(z_left), dim=1)
        right = F.normalize(self._contrast_tangent(z_right), dim=1)
        logits_lr = torch.matmul(left, right.t()) / tau
        logits_rl = torch.matmul(right, left.t()) / tau
        labels = torch.arange(z_left.size(0), device=z_left.device)
        return 0.5 * (F.cross_entropy(logits_lr, labels) + F.cross_entropy(logits_rl, labels))

    def _hyperbolic_infonce_loss(self, z_left, z_right, tau=None):
        tau = self._resolve_tau(tau)
        left_h = self._expmap0(z_left)
        right_h = self._expmap0(z_right)
        logits_lr = -self._pairwise_sqdist(left_h, right_h) / tau
        logits_rl = logits_lr.t()
        labels = torch.arange(z_left.size(0), device=z_left.device)
        return 0.5 * (F.cross_entropy(logits_lr, labels) + F.cross_entropy(logits_rl, labels))

    def _contrast_tangent(self, z):
        return self._logmap0(self._expmap0(z))

    def _resolve_tau(self, tau):
        return float(self.contrast_temperature if tau is None else tau)

    def _pairwise_sqdist(self, x, y):
        x_exp = x.unsqueeze(1)
        y_exp = y.unsqueeze(0)
        return self._sqdist(x_exp, y_exp)

    def sample_view_A(self, node_idx_l, cut_time_l, num_neighbors):
        """Tempo-Structural Historical View sampled from TGAT NeighborFinder.

        Returns a dict of tensors. Every non-padding edge is guaranteed to have
        edge_time < cut_time; future or padding entries are masked out.
        """

        node_idx_l = self._as_numpy(node_idx_l, np.int64)
        cut_time_l = self._as_numpy(cut_time_l, np.float32)
        device = self.n_feat_th.device

        if not self.use_historical_context or num_neighbors <= 0:
            return self._empty_view(node_idx_l, cut_time_l, max(1, num_neighbors), device)

        ngh_node, ngh_eidx, ngh_time = self.ngh_finder.get_temporal_neighbor(
            node_idx_l, cut_time_l, num_neighbors=num_neighbors
        )
        ngh_node = ngh_node.astype(np.int64, copy=False)
        ngh_eidx = ngh_eidx.astype(np.int64, copy=False)
        ngh_time = ngh_time.astype(np.float32, copy=False)

        delta_t = cut_time_l[:, np.newaxis] - ngh_time
        valid_np = (ngh_node != self.null_idx) & (ngh_time < cut_time_l[:, np.newaxis])
        ngh_node = np.where(valid_np, ngh_node, self.null_idx)
        ngh_eidx = np.where(valid_np, ngh_eidx, self.null_idx)
        ngh_time = np.where(valid_np, ngh_time, 0.0).astype(np.float32, copy=False)
        delta_t = np.where(valid_np, delta_t, 0.0).astype(np.float32, copy=False)

        neighbor_node_ids = torch.from_numpy(ngh_node).long().to(device)
        edge_ids = torch.from_numpy(ngh_eidx).long().to(device)
        edge_timestamps = torch.from_numpy(ngh_time).float().to(device)
        delta_t_th = torch.from_numpy(delta_t).float().to(device)
        valid_mask = neighbor_node_ids != self.null_idx
        query_node_ids = torch.from_numpy(node_idx_l).long().to(device)
        cut_time_th = torch.from_numpy(cut_time_l).float().to(device)
        edge_features = self.edge_raw_embed(edge_ids)

        return {
            "neighbor_node_ids": neighbor_node_ids,
            "edge_ids": edge_ids,
            "edge_timestamps": edge_timestamps,
            "edge_features": edge_features,
            "delta_t": delta_t_th,
            "valid_mask": valid_mask,
            "query_node_ids": query_node_ids,
            "cut_time": cut_time_th,
        }

    def _empty_view(self, node_idx_l, cut_time_l, num_neighbors, device):
        batch_size = len(node_idx_l)
        neighbor_node_ids = torch.zeros((batch_size, num_neighbors), dtype=torch.long, device=device)
        edge_ids = torch.zeros((batch_size, num_neighbors), dtype=torch.long, device=device)
        edge_timestamps = torch.zeros((batch_size, num_neighbors), dtype=torch.float, device=device)
        delta_t = torch.zeros((batch_size, num_neighbors), dtype=torch.float, device=device)
        valid_mask = torch.zeros((batch_size, num_neighbors), dtype=torch.bool, device=device)
        query_node_ids = torch.from_numpy(node_idx_l).long().to(device)
        cut_time_th = torch.from_numpy(cut_time_l).float().to(device)
        edge_features = self.edge_raw_embed(edge_ids)
        return {
            "neighbor_node_ids": neighbor_node_ids,
            "edge_ids": edge_ids,
            "edge_timestamps": edge_timestamps,
            "edge_features": edge_features,
            "delta_t": delta_t,
            "valid_mask": valid_mask,
            "query_node_ids": query_node_ids,
            "cut_time": cut_time_th,
        }

    def sample_view_B(self, node_idx_l, cut_time_l, num_neighbors, training=True):
        """Auxiliary Dynamic View from the same historical context as View A.

        Training mode applies edge dropout, edge feature masking, and stochastic
        time weakening. Evaluation mode returns a deterministic clone of View A.
        """

        view = self.sample_view_A(node_idx_l, cut_time_l, num_neighbors)
        view = self._clone_view(view)
        if not training:
            return view

        valid = view["valid_mask"]
        if self.view_b_edge_dropout > 0:
            keep = torch.rand_like(view["delta_t"]) >= self.view_b_edge_dropout
            keep = keep | (~valid)
            dropped = valid & (~keep)
            view["valid_mask"] = valid & keep
            view["neighbor_node_ids"] = view["neighbor_node_ids"].masked_fill(dropped, self.null_idx)
            view["edge_ids"] = view["edge_ids"].masked_fill(dropped, self.null_idx)
            view["edge_timestamps"] = view["edge_timestamps"].masked_fill(dropped, 0.0)
            view["delta_t"] = view["delta_t"].masked_fill(dropped, 0.0)
            valid = view["valid_mask"]

        if self.view_b_feature_mask > 0:
            feature_keep = torch.rand_like(view["edge_features"]) >= self.view_b_feature_mask
            view["edge_features"] = view["edge_features"] * feature_keep.float() * valid.unsqueeze(-1).float()

        if self.view_b_time_zero > 0:
            weaken = (torch.rand_like(view["delta_t"]) < self.view_b_time_zero) & valid
            view["delta_t"] = view["delta_t"].masked_fill(weaken, 0.0)

        return view

    def _base_node_embedding(self, src_idx_l):
        src_idx_l = self._as_numpy(src_idx_l, np.int64)
        device = self.n_feat_th.device
        src_th = torch.from_numpy(src_idx_l).long().to(device)
        return self.node_project(self.node_raw_embed(src_th)) + self.node_id_embed(src_th)

    def _encode_time_delta(self, time_delta, device):
        if torch.is_tensor(time_delta):
            time_delta_th = time_delta.float().to(device)
        else:
            time_delta_th = torch.from_numpy(time_delta.astype(np.float32)).float().to(device)
        if self.time_encoder is None:
            return torch.zeros((*time_delta_th.shape, self.feat_dim), device=device)
        return self.time_project(self.time_encoder(time_delta_th))

    def encode_hyperbolic_view(self, src_embed, view, prev_layers, num_neighbors):
        """Encode a sampled dynamic view into a hyperbolic dynamic embedding.

        The computation uses Euclidean operations only in the tangent space:
        raw node/edge/time features are linearly fused as tangent messages,
        mapped to the Poincare ball by expmap0, structurally aggregated there,
        and mapped back by logmap0 as the TGAT-compatible output embedding.
        """

        batch_size, view_neighbors = view["neighbor_node_ids"].shape
        flat_ngh_node = view["neighbor_node_ids"].detach().cpu().numpy().reshape(-1).astype(np.int64)
        flat_ngh_time = view["edge_timestamps"].detach().cpu().numpy().reshape(-1).astype(np.float32)
        ngh_prev = self.tem_conv(flat_ngh_node, flat_ngh_time, prev_layers, num_neighbors)
        ngh_prev = ngh_prev.view(batch_size, view_neighbors, self.feat_dim)

        query_tangent = self.query_tangent(src_embed)
        neighbor_message = self._build_neighbor_message(ngh_prev, view)
        invalid_mask = ~view["valid_mask"]
        neighbor_message = neighbor_message.masked_fill(invalid_mask.unsqueeze(-1), 0.0)
        if not self.use_hyperbolic:
            return self._tgat_style_structural_encoder(
                query_tangent,
                ngh_prev,
                view,
                invalid_mask,
                layer_idx=prev_layers,
            )
        return self._hyperbolic_structural_encoder(query_tangent, neighbor_message, view["delta_t"], invalid_mask)

    def _build_neighbor_message(self, neighbor_embed, view):
        node_msg = self.neighbor_tangent(neighbor_embed)
        edge_msg = self.edge_project(view["edge_features"])
        time_msg = self._encode_time_delta(view["delta_t"], neighbor_embed.device)
        return self.message_fusion(torch.cat([node_msg, edge_msg, time_msg], dim=-1))

    def _hyperbolic_structural_encoder(self, query_tangent, neighbor_tangent, time_delta, mask):
        device = query_tangent.device
        batch_size, num_neighbors, _ = neighbor_tangent.shape
        valid = (~mask).float()

        if num_neighbors == 0:
            return torch.zeros_like(query_tangent)

        neighbor_hyp = self._expmap0(neighbor_tangent)
        query_hyp = self._expmap0(query_tangent)

        if torch.is_tensor(time_delta):
            time_delta_th = time_delta.float().to(device)
        else:
            time_delta_th = torch.from_numpy(time_delta.astype(np.float32)).float().to(device)

        weights = self._historical_attention(query_tangent, neighbor_tangent, time_delta_th, mask)
        if self.hyper_agg_method == "mean":
            weights = valid / valid.sum(dim=1, keepdim=True).clamp_min(1.0)

        diffused_hyp = query_hyp
        for _ in range(self.diffusion_steps):
            tangent_neighbors = self._logmap0(neighbor_hyp)
            tangent_agg = torch.sum(weights.unsqueeze(-1) * tangent_neighbors, dim=1)
            agg_hyp = self._expmap0(tangent_agg)
            diffused_hyp = self._proj(self._mobius_add(diffused_hyp, agg_hyp))

        diffused_tangent = self._logmap0(diffused_hyp)
        output_tangent = self.hyperbolic_output(torch.cat([query_tangent, diffused_tangent], dim=1))
        no_history = valid.sum(dim=1, keepdim=True).eq(0)
        return torch.where(no_history, query_tangent, output_tangent)

    def _tgat_style_structural_encoder(self, query_tangent, neighbor_embed, view, mask, layer_idx):
        edge_msg = self.edge_project(view["edge_features"])
        time_msg = self._encode_time_delta(view["delta_t"], query_tangent.device)
        query_time = self._encode_time_delta(torch.zeros_like(view["delta_t"][:, :1]), query_tangent.device)
        attn_idx = max(0, min(int(layer_idx), len(self.tgat_attn_model_list) - 1))
        out, _ = self.tgat_attn_model_list[attn_idx](
            query_tangent,
            query_time,
            self.neighbor_tangent(neighbor_embed),
            time_msg,
            edge_msg,
            mask,
        )
        no_history = (~mask).float().sum(dim=1, keepdim=True).eq(0)
        return torch.where(no_history, query_tangent, out)

    def _historical_attention(self, query_tangent, neighbor_tangent, time_delta_th, mask):
        batch_size, num_neighbors, _ = neighbor_tangent.shape
        valid = (~mask).float()
        query = query_tangent.unsqueeze(1).expand(batch_size, num_neighbors, self.feat_dim)
        attn_input = torch.cat(
            [query, neighbor_tangent, query * neighbor_tangent, torch.abs(query - neighbor_tangent)],
            dim=-1,
        )
        logits = self.structural_attn(attn_input).squeeze(dim=-1)
        time_bias = -torch.log1p(torch.clamp(time_delta_th, min=0.0)) / self._time_scale(time_delta_th)
        logits = logits + time_bias
        logits = logits.masked_fill(mask, -1e10)

        if valid.sum(dim=1).eq(0).any():
            logits = torch.where(valid.bool(), logits, torch.zeros_like(logits))

        weights = torch.softmax(logits, dim=1) * valid
        return weights / weights.sum(dim=1, keepdim=True).clamp_min(1.0)

    def _diffuse(self, src_embed, ngh_tangent, time_delta, mask):
        return self._hyperbolic_structural_encoder(src_embed, ngh_tangent, time_delta, mask)

    @staticmethod
    def _clone_view(view):
        return {
            key: value.clone() if torch.is_tensor(value) else value
            for key, value in view.items()
        }

    def _pair_nce(self, src_emb, pos_emb, neg_emb):
        src = F.normalize(src_emb, dim=1)
        pos = F.normalize(pos_emb, dim=1)
        neg = F.normalize(neg_emb, dim=1)
        pos_logit = torch.sum(src * pos, dim=1, keepdim=True) / self.contrast_temperature
        neg_logit = torch.sum(src * neg, dim=1, keepdim=True) / self.contrast_temperature
        logits = torch.cat([pos_logit, neg_logit], dim=1)
        labels = torch.zeros(src_emb.size(0), dtype=torch.long, device=src_emb.device)
        return F.cross_entropy(logits, labels)

    def _hyp_distance_loss(self, src_emb, pos_emb, neg_emb):
        src_h = self._expmap0(src_emb)
        pos_h = self._expmap0(pos_emb)
        neg_h = self._expmap0(neg_emb)
        pos_d = self._sqdist(src_h, pos_h)
        neg_d = self._sqdist(src_h, neg_h)
        return F.softplus(pos_d - neg_d).mean()

    def _expmap0(self, u):
        if not self.use_hyperbolic:
            return u
        sqrt_c = math.sqrt(self.c)
        norm = torch.clamp(torch.norm(u, p=2, dim=-1, keepdim=True), min=1e-15)
        gamma = torch.tanh(sqrt_c * norm) * u / (sqrt_c * norm)
        return self._proj(gamma)

    def _logmap0(self, y):
        if not self.use_hyperbolic:
            return y
        sqrt_c = math.sqrt(self.c)
        y = self._proj(y)
        norm = torch.clamp(torch.norm(y, p=2, dim=-1, keepdim=True), min=1e-15)
        return torch.atanh(torch.clamp(sqrt_c * norm, max=1 - 1e-5)) * y / (sqrt_c * norm)

    def _mobius_add(self, x, y):
        if not self.use_hyperbolic:
            return x + y
        c = self.c
        x2 = torch.sum(x * x, dim=-1, keepdim=True)
        y2 = torch.sum(y * y, dim=-1, keepdim=True)
        xy = torch.sum(x * y, dim=-1, keepdim=True)
        num = (1 + 2 * c * xy + c * y2) * x + (1 - c * x2) * y
        den = 1 + 2 * c * xy + c * c * x2 * y2
        return self._proj(num / den.clamp_min(1e-15))

    def _sqdist(self, x, y):
        if not self.use_hyperbolic:
            return torch.sum((x - y) * (x - y), dim=-1)
        sqrt_c = math.sqrt(self.c)
        diff = self._mobius_add(-x, y)
        norm = torch.clamp(torch.norm(diff, p=2, dim=-1), min=1e-15, max=(1 - 1e-5) / sqrt_c)
        dist = 2 / sqrt_c * torch.atanh(sqrt_c * norm)
        return dist.pow(2)

    def _proj(self, x):
        if not self.use_hyperbolic:
            return x
        max_norm = (1 - 1e-5) / math.sqrt(self.c)
        norm = torch.clamp(torch.norm(x, p=2, dim=-1, keepdim=True), min=1e-15)
        scale = torch.clamp(max_norm / norm, max=1.0)
        return x * scale

    @staticmethod
    def _time_scale(time_delta_th):
        positive = torch.clamp(time_delta_th, min=0.0)
        scale = positive[positive > 0].mean() if torch.any(positive > 0) else positive.new_tensor(1.0)
        return scale.clamp_min(1.0)

    @staticmethod
    def _as_numpy(value, dtype):
        if isinstance(value, np.ndarray):
            return value.astype(dtype, copy=False)
        if torch.is_tensor(value):
            return value.detach().cpu().numpy().astype(dtype, copy=False)
        return np.asarray(value, dtype=dtype)
