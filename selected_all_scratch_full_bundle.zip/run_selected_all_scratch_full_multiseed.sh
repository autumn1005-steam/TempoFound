#!/usr/bin/env bash
set -u
set -o pipefail

PYTHON="${PYTHON:-python}"
GPU="${GPU:-0}"
SEEDS="${SEEDS:-0 1 2 42}"
TARGETS="${TARGETS:-mooc wikipedia}"
MAX_JOBS="${MAX_JOBS:-2}"
EPOCHS="${EPOCHS:-30}"
BS="${BS:-512}"

RUN_DIR="server_runs/selected_all_scratch_full"
LOG_DIR="${RUN_DIR}/logs"
RESULT_DIR="${RUN_DIR}/job_results"
STATUS_DIR="${RUN_DIR}/job_status"

mkdir -p "${LOG_DIR}" "${RESULT_DIR}" "${STATUS_DIR}" saved_models

resolve_checkpoint() {
  local target="$1" condition="$2" seed="$3"
  local candidates=()

  if [[ "${target}" == "mooc" && "${condition}" == "selected" ]]; then
    candidates+=("saved_models/true_wiki_reddit_target_mooc_seed${seed}_pretrained.pth")
  elif [[ "${target}" == "mooc" && "${condition}" == "all" ]]; then
    candidates+=(
      "saved_models/causal_uniform_target_mooc_seed${seed}_pretrained.pth"
      "saved_models/compat_uniform_target_mooc_seed${seed}_pretrained.pth"
    )
  elif [[ "${target}" == "wikipedia" && "${condition}" == "selected" ]]; then
    candidates+=(
      "saved_models/wiki_confirm_uci_enron_seed${seed}_pretrained.pth"
      "saved_models/wiki_subset_uci_enron_seed${seed}_pretrained.pth"
    )
  elif [[ "${target}" == "wikipedia" && "${condition}" == "all" ]]; then
    candidates+=(
      "saved_models/wiki_confirm_all_four_seed${seed}_pretrained.pth"
      "saved_models/wiki_subset_all_four_seed${seed}_pretrained.pth"
    )
  fi

  local path
  for path in "${candidates[@]}"; do
    if [[ -s "${path}" ]]; then
      printf '%s\n' "${path}"
      return 0
    fi
  done
  return 1
}

scratch_checkpoint() {
  local target="$1" seed="$2"
  printf 'saved_models/full_benefit_scratch_%s_seed%s.pth\n' "${target}" "${seed}"
}

preflight() {
  local missing=0 target seed condition checkpoint
  for target in ${TARGETS}; do
    for seed in ${SEEDS}; do
      for condition in selected all; do
        if ! checkpoint="$(resolve_checkpoint "${target}" "${condition}" "${seed}")"; then
          echo "MISSING checkpoint: target=${target}, condition=${condition}, seed=${seed}" >&2
          missing=1
        else
          echo "FOUND ${target}/${condition}/seed${seed}: ${checkpoint}"
        fi
      done
    done
  done
  [[ ${missing} -eq 0 ]]
}

create_scratch() {
  local target="$1" seed="$2" checkpoint="$3" log="$4"
  [[ -s "${checkpoint}" ]] && return 0

  "${PYTHON}" create_scratch_checkpoint.py \
    --dataset "${target}" \
    --processed_dir ./processed \
    --output "${checkpoint}" \
    --seed "${seed}" \
    --shared_dim 128 \
    --time_dim 64 \
    --num_layers 2 \
    --n_head 2 \
    --drop_out 0.1 \
    --num_neighbors 10 \
    > "${log}" 2>&1
}

run_one() {
  local target="$1" condition="$2" seed="$3"
  local desc="full_${target}_${condition}_seed${seed}"
  local result_csv="${RESULT_DIR}/${desc}.csv"
  local status_tsv="${STATUS_DIR}/${desc}.tsv"
  local log="${LOG_DIR}/${desc}.log"
  local checkpoint start end rc

  if [[ -s "${result_csv}" ]]; then
    echo "SKIP existing result: ${desc}"
    return 0
  fi

  if [[ "${condition}" == "scratch" ]]; then
    checkpoint="$(scratch_checkpoint "${target}" "${seed}")"
    if ! create_scratch "${target}" "${seed}" "${checkpoint}" \
      "${LOG_DIR}/create_scratch_${target}_seed${seed}.log"; then
      printf 'desc\tstatus\texit_code\tseconds\n%s\tFAILED\t1\t0\n' \
        "${desc}" > "${status_tsv}"
      echo "FAILED scratch creation: ${desc}" >&2
      return 1
    fi
  else
    checkpoint="$(resolve_checkpoint "${target}" "${condition}" "${seed}")" || {
      echo "FAILED checkpoint resolution: ${desc}" >&2
      return 1
    }
  fi

  echo "===== ${desc}; checkpoint=${checkpoint} ====="
  start="$(date +%s)"
  "${PYTHON}" finetune_foundation.py \
    --task link_prediction \
    --dataset "${target}" \
    --mode full \
    --pretrained_path "${checkpoint}" \
    --epochs "${EPOCHS}" \
    --gpu "${GPU}" \
    --bs "${BS}" \
    --seed "${seed}" \
    --prefix "${desc}" \
    --results_csv "${result_csv}" \
    > "${log}" 2>&1
  rc=$?
  end="$(date +%s)"

  if [[ ${rc} -eq 0 && -s "${result_csv}" ]]; then
    printf 'desc\tstatus\texit_code\tseconds\n%s\tOK\t0\t%s\n' \
      "${desc}" "$((end - start))" > "${status_tsv}"
    echo "OK: ${desc} ($((end - start))s)"
    return 0
  fi

  printf 'desc\tstatus\texit_code\tseconds\n%s\tFAILED\t%s\t%s\n' \
    "${desc}" "${rc}" "$((end - start))" > "${status_tsv}"
  echo "FAILED: ${desc}; see ${log}" >&2
  return 1
}

if ! preflight; then
  echo "Preflight failed. No fine-tuning task was started." >&2
  exit 1
fi

pids=()
labels=()
failed=0

wait_first() {
  if ! wait "${pids[0]}"; then
    echo "FAILED worker: ${labels[0]}" >&2
    failed=1
  fi
  pids=("${pids[@]:1}")
  labels=("${labels[@]:1}")
}

for target in ${TARGETS}; do
  for seed in ${SEEDS}; do
    for condition in selected all scratch; do
      while [[ ${#pids[@]} -ge ${MAX_JOBS} ]]; do wait_first; done
      run_one "${target}" "${condition}" "${seed}" &
      pids+=("$!")
      labels+=("${target}/${condition}/seed${seed}")
    done
  done
done
while [[ ${#pids[@]} -gt 0 ]]; do wait_first; done

if [[ ${failed} -ne 0 ]]; then
  echo "At least one task failed; analysis was not started." >&2
  exit 1
fi

"${PYTHON}" analyze_selected_all_scratch_full.py \
  --results_dir "${RESULT_DIR}" \
  --out_dir "${RUN_DIR}/analysis"

echo "Selected/all/scratch full fine-tuning finished."
echo "Summary: ${RUN_DIR}/analysis/summary.csv"
