import argparse
from pathlib import Path

import pandas as pd


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results_dir", required=True)
    parser.add_argument("--out_dir", required=True)
    args = parser.parse_args()

    paths = sorted(Path(args.results_dir).glob("full_*.csv"))
    if not paths:
        raise SystemExit(f"No result CSV files found in {args.results_dir}")

    frames = []
    for path in paths:
        frame = pd.read_csv(path)
        frame["job_file"] = path.name
        frames.append(frame)
    data = pd.concat(frames, ignore_index=True)

    extracted = data["job_file"].str.extract(
        r"full_(mooc|wikipedia)_(selected|all|scratch)_seed(\d+)\.csv"
    )
    extracted.columns = ["target", "condition", "job_seed"]
    data = pd.concat([data, extracted], axis=1)
    data = data.dropna(subset=["target", "condition", "job_seed", "test_AP"])
    data["job_seed"] = data["job_seed"].astype(int)
    data = data.drop_duplicates(
        ["target", "condition", "job_seed"], keep="last"
    )

    expected = 2 * 3 * 4
    if len(data) != expected:
        raise SystemExit(
            f"Expected {expected} complete results, found {len(data)}. "
            "Do not report an incomplete summary."
        )

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    per_seed = data[
        ["target", "condition", "job_seed", "test_AP", "test_AUC", "epochs"]
    ].sort_values(["target", "job_seed", "condition"])
    per_seed.to_csv(out_dir / "per_seed.csv", index=False)

    summary = (
        per_seed.groupby(["target", "condition"])["test_AP"]
        .agg(mean_AP="mean", std_AP="std", min_AP="min", max_AP="max", count="count")
        .reset_index()
    )

    means = summary.pivot(index="target", columns="condition", values="mean_AP")
    summary["delta_vs_all"] = summary.apply(
        lambda row: row.mean_AP - means.loc[row.target, "all"], axis=1
    )
    summary["delta_vs_scratch"] = summary.apply(
        lambda row: row.mean_AP - means.loc[row.target, "scratch"], axis=1
    )

    wins = []
    for _, row in summary.iterrows():
        target_data = per_seed[per_seed.target.eq(row.target)]
        pivot = target_data.pivot(
            index="job_seed", columns="condition", values="test_AP"
        )
        wins.append(
            int((pivot[row.condition] > pivot["all"]).sum())
            if row.condition != "all"
            else 0
        )
    summary["wins_vs_all"] = wins
    summary.to_csv(out_dir / "summary.csv", index=False)

    print("\n===== Per-seed full fine-tuning AP =====")
    for target, group in per_seed.groupby("target"):
        print(f"\nTarget: {target}")
        print(
            group.pivot(index="job_seed", columns="condition", values="test_AP")
            .round(4)
            .to_string()
        )
    print("\n===== Cross-seed summary =====")
    print(summary.round(4).to_string(index=False))


if __name__ == "__main__":
    main()
