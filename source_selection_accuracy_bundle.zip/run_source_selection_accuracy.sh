#!/usr/bin/env bash
set -u
set -o pipefail

PYTHON="${PYTHON:-python}"
GPU="${GPU:-0}"
SEEDS="${SEEDS:-0 1 2 42}"
MAX_JOBS="${MAX_JOBS:-2}"
BATCH_SIZE="${BATCH_SIZE:-256}"
CALIBRATION_STEPS="${CALIBRATION_STEPS:-100}"
PROBE_BATCHES="${PROBE_BATCHES:-12}"
RUN_DIR="${RUN_DIR:-server_runs/source_selection_accuracy}"
SCORE_DIR="${RUN_DIR}/proxy_scores"
LOG_DIR="${RUN_DIR}/logs"

mkdir -p "${SCORE_DIR}" "${LOG_DIR}" log

checkpoint_for() {
  local config="$1" seed="$2"
  case "${config}" in
    uniform) echo "saved_models/causal_uniform_target_mooc_seed${seed}_pretrained.pth" ;;
    no_uci) echo "saved_models/true_no_uci_target_mooc_seed${seed}_pretrained.pth" ;;
    no_wikipedia|no_reddit|no_enron)
      echo "saved_models/true_${config}_target_mooc_seed${seed}_pretrained.pth" ;;
    *) return 2 ;;
  esac
}

run_one() {
  local config="$1" seed="$2" checkpoint output log_path
  checkpoint="$(checkpoint_for "${config}" "${seed}")" || return $?
  output="${SCORE_DIR}/${config}_seed${seed}.csv"
  log_path="${LOG_DIR}/${config}_seed${seed}.log"
  if [[ -s "${output}" ]]; then
    echo "SKIP proxy score: ${config} seed=${seed}"
    return 0
  fi
  if [[ ! -s "${checkpoint}" ]]; then
    echo "MISSING checkpoint: ${checkpoint}" >&2
    return 1
  fi
  echo "===== PROXY SCORE config=${config} seed=${seed} ====="
  "${PYTHON}" score_source_subset_target_proxy.py \
    --checkpoint "${checkpoint}" \
    --config "${config}" \
    --target_dataset mooc \
    --processed_dir ./processed \
    --output_csv "${output}" \
    --seed "${seed}" \
    --gpu "${GPU}" \
    --batch_size "${BATCH_SIZE}" \
    --calibration_steps "${CALIBRATION_STEPS}" \
    --probe_batches "${PROBE_BATCHES}" \
    > "${log_path}" 2>&1
}

configs=(uniform no_wikipedia no_reddit no_uci no_enron)
pids=()
labels=()
failed=0

wait_first() {
  if ! wait "${pids[0]}"; then
    echo "FAILED proxy worker: ${labels[0]}" >&2
    failed=1
  fi
  pids=("${pids[@]:1}")
  labels=("${labels[@]:1}")
}

for seed in ${SEEDS}; do
  for config in "${configs[@]}"; do
    while [[ ${#pids[@]} -ge ${MAX_JOBS} ]]; do wait_first; done
    run_one "${config}" "${seed}" &
    pids+=("$!")
    labels+=("${config}_seed${seed}")
  done
done
while [[ ${#pids[@]} -gt 0 ]]; do wait_first; done
[[ ${failed} -eq 0 ]] || exit 1

"${PYTHON}" analyze_source_selection_accuracy.py \
  --proxy_dir "${SCORE_DIR}" \
  --test_ap_csv server_runs/mooc_true_leave_one_multiseed/analysis/per_seed_AP.csv \
  --output_dir "${RUN_DIR}/analysis"

echo "Source-selection accuracy experiment finished."
echo "Summary: ${RUN_DIR}/analysis/selection_summary.csv"
