"""Compare target-train proxy selections with true held-out test performance."""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--proxy_dir", required=True)
    parser.add_argument("--test_ap_csv", required=True)
    parser.add_argument("--output_dir", required=True)
    args = parser.parse_args()
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)

    paths = sorted(Path(args.proxy_dir).glob("*.csv"))
    if not paths:
        raise SystemExit("No proxy-score CSV files found")
    proxy = pd.concat([pd.read_csv(path) for path in paths], ignore_index=True)
    proxy = proxy.drop_duplicates(["seed", "config"], keep="last")
    test = pd.read_csv(args.test_ap_csv, index_col=0)
    test.index = test.index.astype(int)
    test.index.name = "seed"
    test_long = test.stack().rename("test_AP").reset_index()
    test_long.columns = ["seed", "config", "test_AP"]
    merged = proxy.merge(test_long, on=["seed", "config"], how="inner")

    expected = 5
    counts = merged.groupby("seed")["config"].nunique()
    if (counts != expected).any():
        raise SystemExit(f"Incomplete candidate matrix:\n{counts}")

    selection_rows = []
    for seed, group in merged.groupby("seed"):
        selected = group.loc[group["proxy_AP"].idxmax()]
        oracle = group.loc[group["test_AP"].idxmax()]
        uniform_ap = float(group.loc[group.config.eq("uniform"), "test_AP"].iloc[0])
        rank_correlation = group["proxy_AP"].rank().corr(
            group["test_AP"].rank(), method="pearson"
        )
        selection_rows.append(
            {
                "seed": seed,
                "selected_config": selected["config"],
                "selected_proxy_AP": selected["proxy_AP"],
                "selected_test_AP": selected["test_AP"],
                "oracle_config": oracle["config"],
                "oracle_test_AP": oracle["test_AP"],
                "selection_regret": oracle["test_AP"] - selected["test_AP"],
                "selected_delta_vs_uniform": selected["test_AP"] - uniform_ap,
                "exact_oracle_selection": int(
                    selected["config"] == oracle["config"]
                ),
                "spearman_rank_correlation": rank_correlation,
            }
        )
    selections = pd.DataFrame(selection_rows).sort_values("seed")
    summary = pd.DataFrame(
        [
            {
                "selection_accuracy": selections["exact_oracle_selection"].mean(),
                "mean_selection_regret": selections["selection_regret"].mean(),
                "mean_selected_delta_vs_uniform": selections[
                    "selected_delta_vs_uniform"
                ].mean(),
                "mean_spearman_rank_correlation": selections[
                    "spearman_rank_correlation"
                ].mean(),
                "num_seeds": len(selections),
            }
        ]
    )
    merged.to_csv(output / "proxy_and_test_scores.csv", index=False)
    selections.to_csv(output / "per_seed_selection.csv", index=False)
    summary.to_csv(output / "selection_summary.csv", index=False)
    print("\n===== Per-seed automatic selection =====")
    print(selections.round(4).to_string(index=False))
    print("\n===== Selection summary =====")
    print(summary.round(4).to_string(index=False))


if __name__ == "__main__":
    main()
