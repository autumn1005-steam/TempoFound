"""Score a source-subset checkpoint using target-train interactions only."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from sklearn.metrics import average_precision_score, roc_auc_score

from analyze_gradient_conflict import load_dataset, set_seed
from analyze_target_gradient_alignment import (
    extend_model_preserving_source_embeddings,
    split_target_train_period,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--config", required=True)
    parser.add_argument("--target_dataset", default="mooc")
    parser.add_argument("--processed_dir", default="./processed")
    parser.add_argument("--output_csv", required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument("--batch_size", type=int, default=256)
    parser.add_argument("--calibration_steps", type=int, default=100)
    parser.add_argument("--probe_batches", type=int, default=12)
    parser.add_argument("--learning_rate", type=float, default=1e-3)
    parser.add_argument("--calibration_fraction", type=float, default=0.8)
    return parser.parse_args()


def reset_target_components(model, target_name: str, seed: int) -> None:
    adapter = model.adapters[target_name]
    torch.manual_seed(seed + 11003)
    for block in (adapter.node_project, adapter.edge_project):
        for module in block.modules():
            if module is not block and hasattr(module, "reset_parameters"):
                module.reset_parameters()

    torch.manual_seed(seed + 11009)
    target_id = model.name_to_id[target_name]
    with torch.no_grad():
        adapter.dataset_embed.weight[target_id].normal_()

    torch.manual_seed(seed + 11027)
    model.add_finetune_link_head()
    model.ft_link_head = model.ft_link_head.to(next(model.parameters()).device)


def link_logits(model, dataset_name, data, source, destination, timestamps):
    source_embedding = model.encode_nodes(
        dataset_name, data["neighbor_finder"], source, timestamps
    )
    destination_embedding = model.encode_nodes(
        dataset_name, data["neighbor_finder"], destination, timestamps
    )
    return model.ft_link_head(source_embedding, destination_embedding)


def train_target_probe(model, name, data, args) -> list[float]:
    for parameter in model.parameters():
        parameter.requires_grad = False
    parameters = list(model.adapters[name].parameters()) + list(
        model.ft_link_head.parameters()
    )
    for parameter in parameters:
        parameter.requires_grad = True

    model.eval()
    model.adapters[name].train()
    model.ft_link_head.train()
    optimizer = torch.optim.Adam(parameters, lr=args.learning_rate)
    rng = np.random.default_rng(args.seed + 12007)
    destination_pool = np.unique(data["train_dst"])
    losses = []

    for step in range(args.calibration_steps):
        indices = rng.choice(
            len(data["train_src"]),
            size=args.batch_size,
            replace=len(data["train_src"]) < args.batch_size,
        )
        source = data["train_src"][indices]
        destination = data["train_dst"][indices]
        timestamps = data["train_ts"][indices]
        negative = rng.choice(destination_pool, size=args.batch_size, replace=True)

        optimizer.zero_grad(set_to_none=True)
        positive_logits = link_logits(
            model, name, data, source, destination, timestamps
        )
        negative_logits = link_logits(
            model, name, data, source, negative, timestamps
        )
        loss = F.binary_cross_entropy_with_logits(
            positive_logits, torch.ones_like(positive_logits)
        ) + F.binary_cross_entropy_with_logits(
            negative_logits, torch.zeros_like(negative_logits)
        )
        loss.backward()
        optimizer.step()
        losses.append(float(loss.detach().cpu()))
    return losses


@torch.no_grad()
def evaluate_target_probe(model, name, data, calibration_data, args) -> dict:
    model.eval()
    rng = np.random.default_rng(args.seed + 13001)
    destination_pool = np.unique(calibration_data["train_dst"])
    sample_count = args.batch_size * args.probe_batches
    indices = rng.choice(
        len(data["train_src"]),
        size=sample_count,
        replace=len(data["train_src"]) < sample_count,
    )
    labels = []
    scores = []
    losses = []

    for batch in range(args.probe_batches):
        selected = indices[
            batch * args.batch_size : (batch + 1) * args.batch_size
        ]
        source = data["train_src"][selected]
        destination = data["train_dst"][selected]
        timestamps = data["train_ts"][selected]
        negative = rng.choice(destination_pool, size=len(selected), replace=True)
        positive_logits = link_logits(
            model, name, data, source, destination, timestamps
        )
        negative_logits = link_logits(
            model, name, data, source, negative, timestamps
        )
        loss = F.binary_cross_entropy_with_logits(
            positive_logits, torch.ones_like(positive_logits)
        ) + F.binary_cross_entropy_with_logits(
            negative_logits, torch.zeros_like(negative_logits)
        )
        losses.append(float(loss.cpu()))
        labels.extend([1] * len(selected) + [0] * len(selected))
        scores.extend(
            torch.sigmoid(torch.cat([positive_logits, negative_logits]))
            .cpu()
            .numpy()
            .reshape(-1)
            .tolist()
        )

    return {
        "proxy_AP": float(average_precision_score(labels, scores)),
        "proxy_AUC": float(roc_auc_score(labels, scores)),
        "proxy_loss": float(np.mean(losses)),
    }


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    device = (
        torch.device(f"cuda:{args.gpu}")
        if args.gpu >= 0 and torch.cuda.is_available()
        else torch.device("cpu")
    )
    target = load_dataset(args.target_dataset, args.processed_dir)
    calibration, probe = split_target_train_period(
        target, args.calibration_fraction
    )
    model, target_was_added = extend_model_preserving_source_embeddings(
        args.checkpoint, args.target_dataset, target, device
    )
    model.load_dataset_embeddings(
        args.target_dataset, target["node_features"], target["edge_features"]
    )
    reset_target_components(model, args.target_dataset, args.seed)
    calibration_losses = train_target_probe(
        model, args.target_dataset, calibration, args
    )
    metrics = evaluate_target_probe(
        model, args.target_dataset, probe, calibration, args
    )
    row = {
        "seed": args.seed,
        "config": args.config,
        "checkpoint": str(Path(args.checkpoint).resolve()),
        **metrics,
        "calibration_final_loss": calibration_losses[-1],
        "calibration_mean_last_10_loss": float(
            np.mean(calibration_losses[-10:])
        ),
        "calibration_steps": args.calibration_steps,
        "probe_batches": args.probe_batches,
        "batch_size": args.batch_size,
        "target_was_added": target_was_added,
    }
    output = Path(args.output_csv)
    output.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame([row]).to_csv(output, index=False)
    with open(output.with_suffix(".json"), "w", encoding="utf-8") as handle:
        json.dump(row, handle, indent=2)
    print(pd.DataFrame([row]).round(4).to_string(index=False))


if __name__ == "__main__":
    main()
