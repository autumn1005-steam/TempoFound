"""Measure source-domain gradient conflict in the shared temporal encoder."""

from __future__ import annotations

import argparse
import json
import os
import random
from itertools import combinations
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

from foundation_model import TemporalGraphFoundationModel
from graph import NeighborFinder


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Compute pairwise source-domain gradient cosine similarities."
    )
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument(
        "--datasets",
        nargs="+",
        default=["wikipedia", "reddit", "uci", "enron"],
    )
    parser.add_argument("--processed_dir", default="./processed")
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument("--batch_size", type=int, default=128)
    parser.add_argument("--num_batches", type=int, default=8)
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def load_dataset(name: str, processed_dir: str) -> dict:
    root = Path(processed_dir)
    frame = pd.read_csv(root / f"ml_{name}.csv")
    edge_features = np.load(root / f"ml_{name}.npy")
    node_features = np.load(root / f"ml_{name}_node.npy")

    src = frame.u.to_numpy()
    dst = frame.i.to_numpy()
    edge_idx = frame.idx.to_numpy()
    timestamps = frame.ts.to_numpy()
    validation_time = float(np.quantile(timestamps, 0.70))
    train_mask = timestamps <= validation_time

    max_node = int(max(src.max(), dst.max()))
    adjacency = [[] for _ in range(max_node + 1)]
    for source, destination, index, timestamp in zip(
        src, dst, edge_idx, timestamps
    ):
        adjacency[int(source)].append((int(destination), int(index), timestamp))
        adjacency[int(destination)].append((int(source), int(index), timestamp))

    return {
        "node_features": node_features,
        "edge_features": edge_features,
        "neighbor_finder": NeighborFinder(adjacency, uniform=False),
        "train_src": src[train_mask],
        "train_dst": dst[train_mask],
        "train_ts": timestamps[train_mask],
    }


def flatten_gradients(
    gradients: tuple[torch.Tensor | None, ...],
    parameters: list[torch.nn.Parameter],
) -> torch.Tensor:
    pieces = []
    for gradient, parameter in zip(gradients, parameters):
        if gradient is None:
            pieces.append(torch.zeros(parameter.numel(), device=parameter.device))
        else:
            pieces.append(gradient.detach().reshape(-1))
    return torch.cat(pieces).float().cpu()


def cosine(left: torch.Tensor, right: torch.Tensor) -> float:
    left_norm = torch.linalg.vector_norm(left)
    right_norm = torch.linalg.vector_norm(right)
    if left_norm.item() == 0.0 or right_norm.item() == 0.0:
        return float("nan")
    return float(torch.dot(left, right) / (left_norm * right_norm))


def domain_gradients(
    model: TemporalGraphFoundationModel,
    dataset_name: str,
    data: dict,
    shared_parameters: list[torch.nn.Parameter],
    seed: int,
    batch_size: int,
    num_batches: int,
) -> tuple[list[torch.Tensor], list[float]]:
    rng = np.random.default_rng(seed)
    train_src = data["train_src"]
    train_dst = data["train_dst"]
    train_ts = data["train_ts"]
    destination_pool = np.unique(train_dst)
    sample_count = batch_size * num_batches

    if len(train_src) >= sample_count:
        selected = rng.choice(len(train_src), size=sample_count, replace=False)
    else:
        selected = rng.choice(len(train_src), size=sample_count, replace=True)

    gradients = []
    losses = []
    for batch_index in range(num_batches):
        start = batch_index * batch_size
        stop = start + batch_size
        indices = selected[start:stop]
        source = train_src[indices]
        destination = train_dst[indices]
        timestamps = train_ts[indices]
        negative_destination = rng.choice(
            destination_pool, size=len(indices), replace=True
        )

        model.zero_grad(set_to_none=True)
        source_embedding = model.encode_nodes(
            dataset_name, data["neighbor_finder"], source, timestamps
        )
        destination_embedding = model.encode_nodes(
            dataset_name, data["neighbor_finder"], destination, timestamps
        )
        negative_embedding = model.encode_nodes(
            dataset_name,
            data["neighbor_finder"],
            negative_destination,
            timestamps,
        )

        positive_logits = model.link_head(source_embedding, destination_embedding)
        negative_logits = model.link_head(source_embedding, negative_embedding)
        loss = F.binary_cross_entropy_with_logits(
            positive_logits, torch.ones_like(positive_logits)
        ) + F.binary_cross_entropy_with_logits(
            negative_logits, torch.zeros_like(negative_logits)
        )

        batch_gradients = torch.autograd.grad(
            loss,
            shared_parameters,
            retain_graph=False,
            create_graph=False,
            allow_unused=True,
        )
        gradients.append(flatten_gradients(batch_gradients, shared_parameters))
        losses.append(float(loss.detach().cpu()))

    return gradients, losses


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    if args.gpu >= 0 and torch.cuda.is_available():
        device = torch.device(f"cuda:{args.gpu}")
    else:
        device = torch.device("cpu")

    checkpoint = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    checkpoint_datasets = {
        config["name"] for config in checkpoint["dataset_configs"]
    }
    missing = [name for name in args.datasets if name not in checkpoint_datasets]
    if missing:
        raise ValueError(f"Checkpoint does not contain datasets: {missing}")

    model = TemporalGraphFoundationModel.load_pretrained(
        args.checkpoint, map_location=device
    ).to(device)
    model.eval()

    data_by_domain = {}
    for dataset_name in args.datasets:
        data = load_dataset(dataset_name, args.processed_dir)
        data_by_domain[dataset_name] = data
        model.load_dataset_embeddings(
            dataset_name, data["node_features"], data["edge_features"]
        )

    shared_named_parameters = [
        (name, parameter)
        for name, parameter in model.named_parameters()
        if name.startswith("encoder.") and parameter.requires_grad
    ]
    shared_parameters = [parameter for _, parameter in shared_named_parameters]
    if not shared_parameters:
        raise RuntimeError("No trainable shared encoder parameters were found")

    gradients_by_domain = {}
    losses_by_domain = {}
    for domain_index, dataset_name in enumerate(args.datasets):
        print(f"Computing gradients: {dataset_name}", flush=True)
        gradients, losses = domain_gradients(
            model=model,
            dataset_name=dataset_name,
            data=data_by_domain[dataset_name],
            shared_parameters=shared_parameters,
            seed=args.seed + 1009 * domain_index,
            batch_size=args.batch_size,
            num_batches=args.num_batches,
        )
        gradients_by_domain[dataset_name] = gradients
        losses_by_domain[dataset_name] = losses

    mean_gradients = {
        name: torch.stack(gradients).mean(dim=0)
        for name, gradients in gradients_by_domain.items()
    }

    mean_cosine = pd.DataFrame(
        index=args.datasets, columns=args.datasets, dtype=float
    )
    batch_rows = []
    for left in args.datasets:
        for right in args.datasets:
            mean_cosine.loc[left, right] = cosine(
                mean_gradients[left], mean_gradients[right]
            )

    for left, right in combinations(args.datasets, 2):
        values = [
            cosine(left_gradient, right_gradient)
            for left_gradient, right_gradient in zip(
                gradients_by_domain[left], gradients_by_domain[right]
            )
        ]
        batch_rows.append(
            {
                "left": left,
                "right": right,
                "mean_batch_cosine": float(np.nanmean(values)),
                "std_batch_cosine": float(np.nanstd(values, ddof=1)),
                "negative_fraction": float(np.mean(np.asarray(values) < 0.0)),
                "num_batches": len(values),
            }
        )

    norm_rows = []
    for dataset_name in args.datasets:
        norms = [
            float(torch.linalg.vector_norm(gradient))
            for gradient in gradients_by_domain[dataset_name]
        ]
        norm_rows.append(
            {
                "dataset": dataset_name,
                "mean_loss": float(np.mean(losses_by_domain[dataset_name])),
                "std_loss": float(np.std(losses_by_domain[dataset_name], ddof=1)),
                "mean_gradient_norm": float(np.mean(norms)),
                "std_gradient_norm": float(np.std(norms, ddof=1)),
                "mean_gradient_vector_norm": float(
                    torch.linalg.vector_norm(mean_gradients[dataset_name])
                ),
            }
        )

    conflict_rows = []
    for dataset_name in args.datasets:
        other_domains = [name for name in args.datasets if name != dataset_name]
        similarities = [
            float(mean_cosine.loc[dataset_name, other])
            for other in other_domains
        ]
        conflict_rows.append(
            {
                "dataset": dataset_name,
                "mean_alignment_to_other_sources": float(np.mean(similarities)),
                "minimum_alignment": float(np.min(similarities)),
                "num_negative_source_pairs": int(
                    np.sum(np.asarray(similarities) < 0.0)
                ),
            }
        )

    mean_cosine.to_csv(output_dir / "mean_gradient_cosine.csv")
    pd.DataFrame(batch_rows).to_csv(
        output_dir / "batch_gradient_cosine.csv", index=False
    )
    pd.DataFrame(norm_rows).to_csv(
        output_dir / "gradient_norms.csv", index=False
    )
    conflict_frame = pd.DataFrame(conflict_rows).sort_values(
        "mean_alignment_to_other_sources"
    )
    conflict_frame.to_csv(output_dir / "domain_conflict_ranking.csv", index=False)

    metadata = {
        "checkpoint": os.path.abspath(args.checkpoint),
        "datasets": args.datasets,
        "seed": args.seed,
        "batch_size": args.batch_size,
        "num_batches": args.num_batches,
        "loss": "masked temporal link prediction",
        "parameter_scope": "shared encoder only",
        "num_shared_parameters": int(
            sum(parameter.numel() for parameter in shared_parameters)
        ),
        "shared_parameter_names": [name for name, _ in shared_named_parameters],
    }
    with open(output_dir / "metadata.json", "w", encoding="utf-8") as handle:
        json.dump(metadata, handle, indent=2)

    print("\nMean-gradient cosine similarity:")
    print(mean_cosine.round(4).to_string())
    print("\nDomain conflict ranking (lower means more conflict):")
    print(conflict_frame.round(4).to_string(index=False))
    print(f"\nResults written to {output_dir}")


if __name__ == "__main__":
    main()
