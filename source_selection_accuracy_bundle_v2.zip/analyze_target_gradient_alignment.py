"""Measure source gradients against an unlabeled target-domain gradient."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

from analyze_gradient_conflict import (
    cosine,
    domain_gradients,
    flatten_gradients,
    load_dataset,
    set_seed,
)
from foundation_model import TemporalGraphFoundationModel


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Compare each source-domain MTLP gradient with an unlabeled "
            "target-domain MTLP gradient."
        )
    )
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument(
        "--source_datasets",
        nargs="+",
        default=["wikipedia", "reddit", "uci", "enron"],
    )
    parser.add_argument("--target_dataset", default="mooc")
    parser.add_argument("--processed_dir", default="./processed")
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument("--batch_size", type=int, default=128)
    parser.add_argument("--num_batches", type=int, default=8)
    parser.add_argument("--calibration_steps", type=int, default=100)
    parser.add_argument("--calibration_lr", type=float, default=1e-3)
    parser.add_argument("--calibration_fraction", type=float, default=0.8)
    return parser.parse_args()


def extend_model_preserving_source_embeddings(
    checkpoint_path: str,
    target_name: str,
    target_data: dict,
    device: torch.device,
) -> tuple[TemporalGraphFoundationModel, bool]:
    checkpoint = torch.load(
        checkpoint_path, map_location="cpu", weights_only=False
    )
    existing_names = [config["name"] for config in checkpoint["dataset_configs"]]
    if target_name in existing_names:
        model = TemporalGraphFoundationModel.load_pretrained(
            checkpoint_path, map_location=device
        )
        return model.to(device), False

    target_config = {
        "name": target_name,
        "raw_node_dim": int(target_data["node_features"].shape[1]),
        "raw_edge_dim": int(target_data["edge_features"].shape[1]),
        "n_nodes": int(target_data["node_features"].shape[0] - 1),
        "n_edges": int(target_data["edge_features"].shape[0] - 1),
    }
    model = TemporalGraphFoundationModel(
        dataset_configs=checkpoint["dataset_configs"] + [target_config],
        shared_dim=checkpoint["shared_dim"],
        time_dim=checkpoint["time_dim"],
        num_layers=checkpoint["num_layers"],
        num_neighbors=checkpoint["num_neighbors"],
    )

    # Extending the dataset table changes dataset-embedding tensor shapes.
    # Preserve all source rows instead of silently reinitializing the table.
    model_state = model.state_dict()
    for name, value in checkpoint["model_state_dict"].items():
        if name not in model_state:
            continue
        destination = model_state[name]
        if destination.shape == value.shape:
            destination.copy_(value)
        elif (
            name.endswith("dataset_embed.weight")
            and destination.ndim == 2
            and value.ndim == 2
            and destination.shape[1] == value.shape[1]
            and destination.shape[0] >= value.shape[0]
        ):
            destination[: value.shape[0]].copy_(value)
    model.load_state_dict(model_state)
    return model.to(device), True


def split_target_train_period(
    target_data: dict, calibration_fraction: float
) -> tuple[dict, dict]:
    if not 0.0 < calibration_fraction < 1.0:
        raise ValueError("calibration_fraction must be between zero and one")

    order = np.argsort(target_data["train_ts"], kind="stable")
    split = int(len(order) * calibration_fraction)
    if split == 0 or split == len(order):
        raise ValueError("Target train period is too small for calibration/probe split")

    def subset(indices: np.ndarray) -> dict:
        result = dict(target_data)
        result["train_src"] = target_data["train_src"][indices]
        result["train_dst"] = target_data["train_dst"][indices]
        result["train_ts"] = target_data["train_ts"][indices]
        return result

    return subset(order[:split]), subset(order[split:])


def mtlp_loss(
    model: TemporalGraphFoundationModel,
    dataset_name: str,
    data: dict,
    source: np.ndarray,
    destination: np.ndarray,
    timestamps: np.ndarray,
    negative_destination: np.ndarray,
) -> torch.Tensor:
    source_embedding = model.encode_nodes(
        dataset_name, data["neighbor_finder"], source, timestamps
    )
    destination_embedding = model.encode_nodes(
        dataset_name, data["neighbor_finder"], destination, timestamps
    )
    negative_embedding = model.encode_nodes(
        dataset_name,
        data["neighbor_finder"],
        negative_destination,
        timestamps,
    )
    positive_logits = model.link_head(source_embedding, destination_embedding)
    negative_logits = model.link_head(source_embedding, negative_embedding)
    return F.binary_cross_entropy_with_logits(
        positive_logits, torch.ones_like(positive_logits)
    ) + F.binary_cross_entropy_with_logits(
        negative_logits, torch.zeros_like(negative_logits)
    )


def calibrate_target_adapter(
    model: TemporalGraphFoundationModel,
    target_name: str,
    calibration_data: dict,
    seed: int,
    batch_size: int,
    steps: int,
    learning_rate: float,
) -> list[float]:
    for parameter in model.parameters():
        parameter.requires_grad = False
    target_parameters = list(model.adapters[target_name].parameters())
    for parameter in target_parameters:
        parameter.requires_grad = True

    # Keep the frozen encoder deterministic while training only the target adapter.
    model.eval()
    model.adapters[target_name].train()
    optimizer = torch.optim.Adam(target_parameters, lr=learning_rate)
    rng = np.random.default_rng(seed + 7919)
    destination_pool = np.unique(calibration_data["train_dst"])
    losses = []

    for step in range(steps):
        replace = len(calibration_data["train_src"]) < batch_size
        indices = rng.choice(
            len(calibration_data["train_src"]),
            size=batch_size,
            replace=replace,
        )
        source = calibration_data["train_src"][indices]
        destination = calibration_data["train_dst"][indices]
        timestamps = calibration_data["train_ts"][indices]
        negative_destination = rng.choice(
            destination_pool, size=batch_size, replace=True
        )

        optimizer.zero_grad(set_to_none=True)
        loss = mtlp_loss(
            model,
            target_name,
            calibration_data,
            source,
            destination,
            timestamps,
            negative_destination,
        )
        loss.backward()
        optimizer.step()
        losses.append(float(loss.detach().cpu()))
        if (step + 1) % 20 == 0 or step == 0:
            print(
                f"Target adapter calibration {step + 1}/{steps}: "
                f"loss={losses[-1]:.4f}",
                flush=True,
            )
    return losses


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    device = (
        torch.device(f"cuda:{args.gpu}")
        if args.gpu >= 0 and torch.cuda.is_available()
        else torch.device("cpu")
    )

    all_names = list(args.source_datasets) + [args.target_dataset]
    data_by_domain = {
        name: load_dataset(name, args.processed_dir) for name in all_names
    }
    calibration_data, target_probe_data = split_target_train_period(
        data_by_domain[args.target_dataset], args.calibration_fraction
    )
    model, target_was_added = extend_model_preserving_source_embeddings(
        args.checkpoint,
        args.target_dataset,
        data_by_domain[args.target_dataset],
        device,
    )
    for name in all_names:
        model.load_dataset_embeddings(
            name,
            data_by_domain[name]["node_features"],
            data_by_domain[name]["edge_features"],
        )

    calibration_losses = calibrate_target_adapter(
        model=model,
        target_name=args.target_dataset,
        calibration_data=calibration_data,
        seed=args.seed,
        batch_size=args.batch_size,
        steps=args.calibration_steps,
        learning_rate=args.calibration_lr,
    )

    for parameter in model.parameters():
        parameter.requires_grad = False
    shared_named_parameters = [
        (name, parameter)
        for name, parameter in model.named_parameters()
        if name.startswith("encoder.")
    ]
    for _, parameter in shared_named_parameters:
        parameter.requires_grad = True
    shared_parameters = [parameter for _, parameter in shared_named_parameters]
    model.eval()

    gradients = {}
    losses = {}
    for index, name in enumerate(all_names):
        print(f"Computing shared-encoder gradients: {name}", flush=True)
        domain_data = (
            target_probe_data if name == args.target_dataset else data_by_domain[name]
        )
        domain_gradient, domain_loss = domain_gradients(
            model=model,
            dataset_name=name,
            data=domain_data,
            shared_parameters=shared_parameters,
            seed=args.seed + 1009 * index,
            batch_size=args.batch_size,
            num_batches=args.num_batches,
        )
        gradients[name] = domain_gradient
        losses[name] = domain_loss

    mean_gradients = {
        name: torch.stack(values).mean(dim=0) for name, values in gradients.items()
    }
    target_mean = mean_gradients[args.target_dataset]
    rows = []
    for source in args.source_datasets:
        paired_cosines = [
            cosine(source_gradient, target_gradient)
            for source_gradient, target_gradient in zip(
                gradients[source], gradients[args.target_dataset]
            )
        ]
        rows.append(
            {
                "source_dataset": source,
                "target_dataset": args.target_dataset,
                "mean_gradient_cosine": cosine(
                    mean_gradients[source], target_mean
                ),
                "mean_batch_cosine": float(np.nanmean(paired_cosines)),
                "std_batch_cosine": float(
                    np.nanstd(paired_cosines, ddof=1)
                ),
                "negative_batch_fraction": float(
                    np.mean(np.asarray(paired_cosines) < 0.0)
                ),
                "source_mean_gradient_norm": float(
                    torch.linalg.vector_norm(mean_gradients[source])
                ),
                "target_mean_gradient_norm": float(
                    torch.linalg.vector_norm(target_mean)
                ),
                "source_mean_loss": float(np.mean(losses[source])),
                "target_mean_loss": float(
                    np.mean(losses[args.target_dataset])
                ),
            }
        )

    alignment = pd.DataFrame(rows).sort_values("mean_gradient_cosine")
    alignment.to_csv(output_dir / "target_gradient_alignment.csv", index=False)
    pd.DataFrame(
        {
            "step": np.arange(1, len(calibration_losses) + 1),
            "loss": calibration_losses,
        }
    ).to_csv(output_dir / "target_adapter_calibration.csv", index=False)

    metadata = {
        "checkpoint": os.path.abspath(args.checkpoint),
        "source_datasets": args.source_datasets,
        "target_dataset": args.target_dataset,
        "target_was_added_to_checkpoint": target_was_added,
        "seed": args.seed,
        "batch_size": args.batch_size,
        "num_batches": args.num_batches,
        "calibration_steps": args.calibration_steps,
        "calibration_lr": args.calibration_lr,
        "calibration_fraction_of_target_train_period": args.calibration_fraction,
        "target_probe_fraction_of_target_train_period": 1.0
        - args.calibration_fraction,
        "loss": "masked temporal link prediction",
        "parameter_scope": "shared encoder only",
        "target_data_usage": "chronological training-period interactions only",
        "num_shared_parameters": int(
            sum(parameter.numel() for parameter in shared_parameters)
        ),
        "shared_parameter_names": [
            name for name, _ in shared_named_parameters
        ],
    }
    with open(output_dir / "metadata.json", "w", encoding="utf-8") as handle:
        json.dump(metadata, handle, indent=2)

    print("\nTarget-aware gradient alignment (lower means less compatible):")
    print(alignment.round(4).to_string(index=False))
    print(f"\nResults written to {output_dir}")


if __name__ == "__main__":
    main()
