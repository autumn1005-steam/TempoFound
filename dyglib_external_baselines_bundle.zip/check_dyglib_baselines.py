#!/usr/bin/env python3
"""Report completeness and failures for the external baseline queue."""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run_dir", type=Path, default=Path("server_runs/dyglib_external_baselines"))
    args = parser.parse_args()
    status_path = args.run_dir / "status.tsv"
    if not status_path.exists():
        raise SystemExit(f"Missing {status_path}")

    status = pd.read_csv(status_path, sep="\t").drop_duplicates("desc", keep="last")
    expected = 2 * (1 + 4 * 4)
    ok = int((status.status == "OK").sum())
    failed = int((status.status == "FAILED").sum())
    print(f"Completed: {len(status)} / {expected}")
    print(f"OK: {ok}")
    print(f"FAILED: {failed}")
    print(f"Remaining: {max(expected - len(status), 0)}")
    if len(status):
        print(f"Mean seconds/task: {status.seconds.mean():.1f}")
        print("\nLatest tasks:")
        print(status.tail(12).to_string(index=False))


if __name__ == "__main__":
    main()
