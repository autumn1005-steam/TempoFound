#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-$(pwd)}"
DYGLIB_DIR="${DYGLIB_DIR:-${PROJECT_DIR}/external/DyGLib}"
DYGLIB_URL="https://github.com/yule-BUAA/DyGLib.git"
BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

mkdir -p "${PROJECT_DIR}/log"
mkdir -p "$(dirname "${DYGLIB_DIR}")"

if [[ ! -f "${DYGLIB_DIR}/train_link_prediction.py" ]]; then
    if command -v git >/dev/null 2>&1 && git clone --depth 1 "${DYGLIB_URL}" "${DYGLIB_DIR}"; then
        :
    else
        echo "git clone failed; downloading the official source archive instead."
        tmp_zip="$(mktemp --suffix=.zip)"
        wget -O "${tmp_zip}" "https://codeload.github.com/yule-BUAA/DyGLib/zip/refs/heads/master"
        tmp_dir="$(mktemp -d)"
        unzip -q "${tmp_zip}" -d "${tmp_dir}"
        mv "${tmp_dir}/DyGLib-master" "${DYGLIB_DIR}"
        rm -rf "${tmp_zip}" "${tmp_dir}"
    fi
fi

python "${BUNDLE_DIR}/patch_dyglib_protocol.py" --dyglib_dir "${DYGLIB_DIR}"

# Force local imports even when the environment contains an unrelated
# third-party package named `models` or `utils`.
touch "${DYGLIB_DIR}/models/__init__.py" "${DYGLIB_DIR}/utils/__init__.py"

mkdir -p "${DYGLIB_DIR}/processed_data"
for dataset in wikipedia mooc; do
    target="${DYGLIB_DIR}/processed_data/${dataset}"
    mkdir -p "${target}"
    for suffix in ".csv" ".npy" "_node.npy"; do
        source="${PROJECT_DIR}/processed/ml_${dataset}${suffix}"
        [[ -s "${source}" ]] || { echo "Missing ${source}"; exit 1; }
        ln -sfn "${source}" "${target}/ml_${dataset}${suffix}"
    done
done

python -m pip install tabulate tqdm pandas numpy scikit-learn

if [[ -d "${DYGLIB_DIR}/.git" ]]; then
    git -C "${DYGLIB_DIR}" rev-parse HEAD | tee "${PROJECT_DIR}/dyglib_baseline_commit.txt"
else
    echo "master-source-archive" | tee "${PROJECT_DIR}/dyglib_baseline_commit.txt"
fi

python -m py_compile \
    "${DYGLIB_DIR}/train_link_prediction.py" \
    "${DYGLIB_DIR}/evaluate_link_prediction.py" \
    "${DYGLIB_DIR}/evaluate_models_utils.py" \
    "${DYGLIB_DIR}/utils/load_configs.py" \
    "${DYGLIB_DIR}/utils/DataLoader.py"

echo "DyGLib baseline environment is ready at ${DYGLIB_DIR}"
