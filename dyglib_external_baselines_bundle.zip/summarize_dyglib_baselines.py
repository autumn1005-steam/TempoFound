#!/usr/bin/env python3
"""Collect DyGLib JSON files into tidy per-seed and summary CSV files."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import pandas as pd


def parse_metrics(path: Path) -> tuple[float, float]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    metrics = payload["test metrics"]
    return float(metrics["average_precision"]), float(metrics["roc_auc"])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dyglib_dir", type=Path, required=True)
    parser.add_argument("--output_dir", type=Path, required=True)
    args = parser.parse_args()

    rows: list[dict] = []
    root = args.dyglib_dir / "saved_results"
    pattern = re.compile(r"(?:random_negative_sampling_)?(?P<model>[^_]+)_seed(?P<seed>\d+)$")

    for path in root.glob("*/*/*.json"):
        match = pattern.match(path.stem)
        if not match:
            continue
        model = path.parts[-3]
        dataset = path.parts[-2]
        if model not in {"EdgeBank", "TGAT", "TGN", "GraphMixer", "DyGFormer"}:
            continue
        ap, auc = parse_metrics(path)
        rows.append({
            "model": model,
            "dataset": dataset,
            "seed": int(match.group("seed")),
            "test_AP": ap,
            "test_AUC": auc,
            "result_file": str(path.resolve()),
        })

    if not rows:
        raise SystemExit(f"No baseline result JSON files found under {root}")

    output_dir = args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)
    frame = pd.DataFrame(rows).drop_duplicates(["model", "dataset", "seed"], keep="last")
    frame = frame.sort_values(["dataset", "model", "seed"])
    frame.to_csv(output_dir / "results.csv", index=False)

    summary = (
        frame.groupby(["dataset", "model"], as_index=False)
        .agg(
            AP_mean=("test_AP", "mean"),
            AP_std=("test_AP", "std"),
            AUC_mean=("test_AUC", "mean"),
            AUC_std=("test_AUC", "std"),
            num_seeds=("seed", "nunique"),
        )
        .sort_values(["dataset", "AP_mean"], ascending=[True, False])
    )
    summary.to_csv(output_dir / "summary.csv", index=False)
    print(summary.round(4).to_string(index=False))


if __name__ == "__main__":
    main()
