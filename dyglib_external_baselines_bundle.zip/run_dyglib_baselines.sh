#!/usr/bin/env bash
set -u
set -o pipefail

PROJECT_DIR="${PROJECT_DIR:-$(pwd)}"
DYGLIB_DIR="${DYGLIB_DIR:-${PROJECT_DIR}/external/DyGLib}"
BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GPU="${GPU:-0}"
SEEDS="${SEEDS:-0 1 2 42}"
DATASETS="${DATASETS:-wikipedia mooc}"
MODELS="${MODELS:-TGAT TGN GraphMixer DyGFormer}"
NUM_EPOCHS="${NUM_EPOCHS:-50}"
PATIENCE="${PATIENCE:-10}"
BATCH_SIZE="${BATCH_SIZE:-200}"

RUN_NAME="${RUN_NAME:-dyglib_external_baselines}"
RUN_DIR="${PROJECT_DIR}/server_runs/${RUN_NAME}"
LOG_DIR="${RUN_DIR}/logs"
STATUS="${RUN_DIR}/status.tsv"
mkdir -p "${LOG_DIR}"
[[ -f "${STATUS}" ]] || printf "timestamp\tdesc\tstatus\texit_code\tseconds\n" > "${STATUS}"

already_ok() {
    local desc="$1"
    awk -F '\t' -v d="${desc}" '$2 == d && $3 == "OK" {ok=1} END {exit !ok}' "${STATUS}"
}

record() {
    local desc="$1" status="$2" rc="$3" seconds="$4"
    printf "%s\t%s\t%s\t%s\t%s\n" \
        "$(date '+%Y-%m-%d %H:%M:%S')" "${desc}" "${status}" "${rc}" "${seconds}" >> "${STATUS}"
}

run_trainable() {
    local dataset="$1" model="$2" seed="$3"
    local desc="dyglib_${model}_${dataset}_seed${seed}"
    local result="${DYGLIB_DIR}/saved_results/${model}/${dataset}/${model}_seed${seed}.json"
    local log="${LOG_DIR}/${desc}.log"

    if already_ok "${desc}" && [[ -s "${result}" ]]; then
        echo "SKIP: ${desc}"
        return 0
    fi

    echo "===== ${desc} ====="
    local start end rc status
    start="$(date +%s)"
    (
        cd "${DYGLIB_DIR}"
        python train_link_prediction.py \
            --dataset_name "${dataset}" \
            --model_name "${model}" \
            --negative_sample_strategy random \
            --load_best_configs \
            --num_runs 1 \
            --run_seed "${seed}" \
            --num_epochs "${NUM_EPOCHS}" \
            --patience "${PATIENCE}" \
            --batch_size "${BATCH_SIZE}" \
            --val_ratio 0.15 \
            --test_ratio 0.15 \
            --gpu "${GPU}"
    ) > "${log}" 2>&1
    rc=$?
    end="$(date +%s)"
    status="FAILED"
    [[ ${rc} -eq 0 && -s "${result}" ]] && status="OK"
    record "${desc}" "${status}" "${rc}" "$((end - start))"
    echo "${status}: ${desc} ($((end - start))s)"
    return "${rc}"
}

run_edgebank() {
    local dataset="$1" seed=42
    local model="EdgeBank"
    local desc="dyglib_${model}_${dataset}_seed${seed}"
    local result="${DYGLIB_DIR}/saved_results/${model}/${dataset}/random_negative_sampling_${model}_seed${seed}.json"
    local log="${LOG_DIR}/${desc}.log"

    if already_ok "${desc}" && [[ -s "${result}" ]]; then
        echo "SKIP: ${desc}"
        return 0
    fi

    echo "===== ${desc} (deterministic baseline) ====="
    local start end rc status
    start="$(date +%s)"
    (
        cd "${DYGLIB_DIR}"
        python evaluate_link_prediction.py \
            --dataset_name "${dataset}" \
            --model_name EdgeBank \
            --negative_sample_strategy random \
            --load_best_configs \
            --num_runs 1 \
            --run_seed "${seed}" \
            --batch_size "${BATCH_SIZE}" \
            --val_ratio 0.15 \
            --test_ratio 0.15 \
            --gpu "${GPU}"
    ) > "${log}" 2>&1
    rc=$?
    end="$(date +%s)"
    status="FAILED"
    [[ ${rc} -eq 0 && -s "${result}" ]] && status="OK"
    record "${desc}" "${status}" "${rc}" "$((end - start))"
    echo "${status}: ${desc} ($((end - start))s)"
    return "${rc}"
}

failures=0
for dataset in ${DATASETS}; do
    run_edgebank "${dataset}" || failures=$((failures + 1))
    for model in ${MODELS}; do
        for seed in ${SEEDS}; do
            run_trainable "${dataset}" "${model}" "${seed}" || failures=$((failures + 1))
        done
    done
done

python "${BUNDLE_DIR}/summarize_dyglib_baselines.py" \
    --dyglib_dir "${DYGLIB_DIR}" \
    --output_dir "${RUN_DIR}"

echo "External baseline queue finished with ${failures} failed task(s)."
echo "Status:  ${STATUS}"
echo "Results: ${RUN_DIR}/results.csv"
exit "${failures}"
