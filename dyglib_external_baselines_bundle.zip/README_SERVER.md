# External temporal-graph baselines

This bundle runs EdgeBank, TGAT, TGN, GraphMixer, and DyGFormer using the
official DyGLib implementations on the project's exact processed Wikipedia and
MOOC files.

Protocol adjustments made by `patch_dyglib_protocol.py`:

- chronological 70/15/15 split;
- no additional 10% inductive-node removal from the training period;
- random negative destinations drawn from the training-period destination set;
- exact seeds 0, 1, 2, and 42;
- test AP and AUC collected from one shared implementation.

Run from the project root:

```bash
chmod +x dyglib_baseline_bundle/*.sh
bash dyglib_baseline_bundle/setup_dyglib_baselines.sh

nohup env GPU=0 \
  SEEDS="0 1 2 42" \
  DATASETS="wikipedia mooc" \
  MODELS="TGAT TGN GraphMixer DyGFormer" \
  NUM_EPOCHS=50 PATIENCE=10 BATCH_SIZE=200 \
  bash dyglib_baseline_bundle/run_dyglib_baselines.sh \
  > log/dyglib_external_baselines.log 2>&1 &

echo $! | tee dyglib_external_baselines.pid
tail -f log/dyglib_external_baselines.log
```

The queue is resumable. Re-running the same command skips successful tasks.

Check progress:

```bash
python dyglib_baseline_bundle/check_dyglib_baselines.py
```

Final outputs:

- `server_runs/dyglib_external_baselines/status.tsv`
- `server_runs/dyglib_external_baselines/results.csv`
- `server_runs/dyglib_external_baselines/summary.csv`

For a quick smoke test before the full queue:

```bash
env RUN_NAME="dyglib_smoke" GPU=0 SEEDS="42" DATASETS="wikipedia" MODELS="TGAT" \
  NUM_EPOCHS=2 PATIENCE=1 \
  bash dyglib_baseline_bundle/run_dyglib_baselines.sh
```
