#!/usr/bin/env python3
"""Patch DyGLib to match the TempoFound transductive LP protocol."""

from __future__ import annotations

import argparse
import re
from pathlib import Path


def replace_once(text: str, old: str, new: str, label: str) -> str:
    if new in text:
        return text
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected one match, found {count}")
    return text.replace(old, new, 1)


def patch_parser(root: Path) -> None:
    path = root / "utils" / "load_configs.py"
    text = path.read_text(encoding="utf-8")
    marker = "    parser.add_argument('--num_runs', type=int, default=5, help='number of runs')\n"
    addition = marker + (
        "    parser.add_argument('--run_seed', type=int, default=0, "
        "help='first random seed; use with num_runs=1 for an exact seed')\n"
    )
    if addition not in text:
        if marker not in text:
            raise RuntimeError("link parser run_seed: insertion point not found")
        # The file also contains a node-classification parser. Only the first
        # occurrence belongs to link prediction, which is the task run here.
        text = text.replace(marker, addition, 1)
    path.write_text(text, encoding="utf-8")


def patch_seeded_runs(path: Path) -> None:
    text = path.read_text(encoding="utf-8")
    if "set_random_seed(seed=args.run_seed + run)" not in text:
        pattern = re.compile(
            r"(?P<indent>^[ \t]+)set_random_seed\(seed=run\)\n\n"
            r"(?P=indent)args\.seed = run$",
            flags=re.MULTILINE,
        )

        def replacement(match: re.Match[str]) -> str:
            indent = match.group("indent")
            return (
                f"{indent}set_random_seed(seed=args.run_seed + run)\n\n"
                f"{indent}args.seed = args.run_seed + run"
            )

        text, count = pattern.subn(replacement, text)
        if count == 0:
            raise RuntimeError(f"seed patch pattern not found in {path}")
    elif "args.seed = args.run_seed + run" not in text:
        raise RuntimeError(f"seed patch pattern not found in {path}")
    path.write_text(text, encoding="utf-8")


def patch_transductive_split(root: Path) -> None:
    path = root / "utils" / "DataLoader.py"
    text = path.read_text(encoding="utf-8")
    old = "    train_mask = np.logical_and(node_interact_times <= val_time, observed_edges_mask)\n"
    new = (
        "    # TempoFound comparison protocol: use every chronological training edge.\n"
        "    # The original DyGLib code removes edges incident to a sampled 10% node set.\n"
        "    train_mask = node_interact_times <= val_time\n"
    )
    text = replace_once(text, old, new, "chronological training split")

    old_assert = "    assert len(train_node_set & new_test_node_set) == 0\n"
    new_assert = (
        "    # The transductive protocol intentionally keeps these nodes in training;\n"
        "    # therefore the upstream inductive-disjointness assertion is not applicable.\n"
    )
    text = replace_once(text, old_assert, new_assert, "inductive disjointness assertion")

    old_masks = (
        "    new_node_val_mask = np.logical_and(val_mask, edge_contains_new_node_mask)\n"
        "    new_node_test_mask = np.logical_and(test_mask, edge_contains_new_node_mask)\n"
    )
    new_masks = (
        "    # Keep these loaders non-empty because the upstream trainer always evaluates them.\n"
        "    # Their duplicated values are ignored; only the standard test metrics are reported.\n"
        "    new_node_val_mask = val_mask\n"
        "    new_node_test_mask = test_mask\n"
    )
    text = replace_once(text, old_masks, new_masks, "non-empty auxiliary loaders")
    path.write_text(text, encoding="utf-8")


def patch_negative_pools(path: Path) -> None:
    text = path.read_text(encoding="utf-8")
    replacements = {
        "NegativeEdgeSampler(src_node_ids=full_data.src_node_ids, dst_node_ids=full_data.dst_node_ids, seed=0)":
            "NegativeEdgeSampler(src_node_ids=train_data.src_node_ids, dst_node_ids=train_data.dst_node_ids, seed=0)",
        "NegativeEdgeSampler(src_node_ids=full_data.src_node_ids, dst_node_ids=full_data.dst_node_ids, seed=2)":
            "NegativeEdgeSampler(src_node_ids=train_data.src_node_ids, dst_node_ids=train_data.dst_node_ids, seed=2)",
    }
    for old, new in replacements.items():
        if new in text:
            continue
        if old not in text:
            raise RuntimeError(f"negative-pool pattern not found in {path}: {old}")
        text = text.replace(old, new)
    path.write_text(text, encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dyglib_dir", type=Path, required=True)
    args = parser.parse_args()
    root = args.dyglib_dir.resolve()

    patch_parser(root)
    patch_seeded_runs(root / "train_link_prediction.py")
    patch_seeded_runs(root / "evaluate_link_prediction.py")
    patch_seeded_runs(root / "evaluate_models_utils.py")
    patch_transductive_split(root)
    patch_negative_pools(root / "train_link_prediction.py")
    patch_negative_pools(root / "evaluate_link_prediction.py")
    print(f"Patched DyGLib comparison protocol in {root}")


if __name__ == "__main__":
    main()
