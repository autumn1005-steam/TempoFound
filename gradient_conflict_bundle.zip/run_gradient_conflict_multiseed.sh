#!/usr/bin/env bash
set -euo pipefail

PYTHON="${PYTHON:-python}"
GPU="${GPU:-0}"
SEEDS="${SEEDS:-0 1 2 42}"
DATASETS="${DATASETS:-wikipedia reddit uci enron}"
BATCH_SIZE="${BATCH_SIZE:-128}"
NUM_BATCHES="${NUM_BATCHES:-8}"
RUN_DIR="${RUN_DIR:-server_runs/gradient_conflict}"

mkdir -p "${RUN_DIR}" log

for seed in ${SEEDS}; do
    checkpoint="saved_models/causal_uniform_target_mooc_seed${seed}_pretrained.pth"
    output_dir="${RUN_DIR}/seed${seed}"
    log_path="${RUN_DIR}/seed${seed}.log"

    if [[ ! -s "${checkpoint}" ]]; then
        echo "Missing checkpoint: ${checkpoint}" >&2
        exit 1
    fi

    echo "===== GRADIENT CONFLICT seed=${seed} ====="
    "${PYTHON}" analyze_gradient_conflict.py \
        --checkpoint "${checkpoint}" \
        --datasets ${DATASETS} \
        --processed_dir ./processed \
        --output_dir "${output_dir}" \
        --seed "${seed}" \
        --gpu "${GPU}" \
        --batch_size "${BATCH_SIZE}" \
        --num_batches "${NUM_BATCHES}" \
        > "${log_path}" 2>&1
    echo "OK seed=${seed}: ${output_dir}"
done

"${PYTHON}" - <<'PY'
from pathlib import Path

import pandas as pd

root = Path("server_runs/gradient_conflict")
frames = []
for path in sorted(root.glob("seed*/domain_conflict_ranking.csv")):
    frame = pd.read_csv(path)
    frame.insert(0, "seed", int(path.parent.name.removeprefix("seed")))
    frames.append(frame)

if not frames:
    raise SystemExit("No gradient-conflict results found")

combined = pd.concat(frames, ignore_index=True)
combined.to_csv(root / "domain_conflict_all_seeds.csv", index=False)

summary = (
    combined.groupby("dataset")
    .agg(
        mean_alignment=("mean_alignment_to_other_sources", "mean"),
        std_alignment=("mean_alignment_to_other_sources", "std"),
        mean_minimum_alignment=("minimum_alignment", "mean"),
        mean_negative_pairs=("num_negative_source_pairs", "mean"),
        count=("seed", "count"),
    )
    .sort_values("mean_alignment")
)
summary.to_csv(root / "domain_conflict_summary.csv")

print("\n===== Cross-seed domain conflict summary =====")
print(summary.round(4).to_string())
print("\nLower alignment indicates stronger gradient conflict.")
PY

echo "Gradient-conflict analysis finished."
echo "Summary: ${RUN_DIR}/domain_conflict_summary.csv"
